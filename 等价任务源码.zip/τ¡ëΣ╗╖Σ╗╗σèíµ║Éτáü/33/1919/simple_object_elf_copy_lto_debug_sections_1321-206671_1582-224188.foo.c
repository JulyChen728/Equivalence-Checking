#include <dycfoo.h>
#include "../simple-object-elf.i.hd.c.h"
void __dyc_foo(void) 
{ struct simple_object_elf_write *eow ;
  unsigned char ei_class ;
  size_t shdr_size ;
  unsigned int shnum ;
  unsigned char *shdrs ;
  char const   *errmsg ;
  size_t name_size ;
  unsigned int i ;
  int *pfnret ;
  char const   **pfnname ;
  unsigned int new_i ;
  unsigned int *sh_map ;
  unsigned int *symtab_indices_shndx ;
  unsigned char *shdr___1 ;
  unsigned int sh_name___0 ;
  unsigned int sh_type___1 ;
  char const   *name___0 ;
  off_t offset___0 ;
  off_t length___0 ;
  simple_object_write_section *dest ;
  off_t flags ;
  unsigned char *buf___0 ;
  ulong_type tmp___47 ;
  ulong_type tmp___48 ;
  ulong_type tmp___51 ;
  ulong_type tmp___52 ;
  void *tmp___55 ;
  int tmp___56 ;
  unsigned int entsize___0 ;
  ulong_type tmp___59 ;
  size_t prevailing_name_idx ;
  unsigned char *ent___0 ;
  unsigned int *shndx_table ;
  unsigned char *sidxhdr ;
  off_t sidxoff ;
  ulong_type tmp___62 ;
  size_t sidxsz ;
  ulong_type tmp___65 ;
  unsigned int shndx_type ;
  unsigned int tmp___68 ;
  void *tmp___69 ;
  unsigned int st_shndx ;
  int tmp___72 ;
  unsigned short tmp___73 ;
  unsigned short tmp___74 ;
  unsigned char *st_info ;
  unsigned char *st_other ;
  unsigned int tmp___77 ;
  unsigned int tmp___78 ;
  unsigned int st_shndx___0 ;
  int tmp___81 ;
  unsigned short tmp___82 ;
  unsigned short tmp___83 ;
  unsigned int raw_st_shndx ;
  unsigned char *st_info___0 ;
  unsigned char *st_other___0 ;
  int discard ;
  int bind ;
  int other ;
  unsigned char *ent___1 ;
  unsigned char *dst ;
  unsigned int shndx ;
  unsigned int tmp___84 ;
  ulong_type tmp___87 ;
  ulong_type tmp___88 ;
  unsigned int sh_info___0 ;
  unsigned int sh_link___1 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___102 ;
  int tmp___107 ;
  int tmp___108 ;
  int tmp___109 ;
  int tmp___110 ;
  int *err ;
  ulong_type __dyc_funcallvar_38 ;
  ulong_type __dyc_funcallvar_39 ;
  ulong_type __dyc_funcallvar_40 ;
  ulong_type __dyc_funcallvar_41 ;
  unsigned int __dyc_funcallvar_42 ;
  unsigned int __dyc_funcallvar_43 ;
  simple_object_write_section *__dyc_funcallvar_44 ;
  void *__dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;
  ulong_type __dyc_funcallvar_47 ;
  ulong_type __dyc_funcallvar_48 ;
  ulong_type __dyc_funcallvar_49 ;
  ulong_type __dyc_funcallvar_50 ;
  ulong_type __dyc_funcallvar_51 ;
  ulong_type __dyc_funcallvar_52 ;
  unsigned int __dyc_funcallvar_53 ;
  unsigned int __dyc_funcallvar_54 ;
  void *__dyc_funcallvar_55 ;
  unsigned short __dyc_funcallvar_56 ;
  unsigned short __dyc_funcallvar_57 ;
  unsigned int __dyc_funcallvar_58 ;
  unsigned int __dyc_funcallvar_59 ;
  unsigned int __dyc_funcallvar_60 ;
  unsigned short __dyc_funcallvar_61 ;
  unsigned short __dyc_funcallvar_62 ;
  unsigned int __dyc_funcallvar_63 ;
  unsigned int __dyc_funcallvar_64 ;
  char const   *__dyc_funcallvar_65 ;
  ulong_type __dyc_funcallvar_66 ;
  ulong_type __dyc_funcallvar_67 ;
  unsigned int __dyc_funcallvar_68 ;
  unsigned int __dyc_funcallvar_69 ;
  unsigned int __dyc_funcallvar_70 ;
  unsigned int __dyc_funcallvar_71 ;
  int __dyc_funcallvar_72 ;
  int __dyc_funcallvar_73 ;
  int __dyc_funcallvar_74 ;
  int __dyc_funcallvar_75 ;
  int __dyc_funcallvar_76 ;

  {
  eow = __dyc_read_ptr__comp_62simple_object_elf_write();
  ei_class = (unsigned char )__dyc_readpre_byte();
  shdr_size = (size_t )__dyc_readpre_byte();
  shnum = (unsigned int )__dyc_readpre_byte();
  shdrs = (unsigned char *)__dyc_read_ptr__char();
  name_size = (size_t )__dyc_readpre_byte();
  i = (unsigned int )__dyc_readpre_byte();
  pfnret = __dyc_read_ptr__int();
  pfnname = (char const   **)__dyc_read_ptr__ptr__char();
  new_i = (unsigned int )__dyc_readpre_byte();
  sh_map = (unsigned int *)__dyc_read_ptr__int();
  symtab_indices_shndx = (unsigned int *)__dyc_read_ptr__int();
  sh_name___0 = (unsigned int )__dyc_readpre_byte();
  err = __dyc_read_ptr__int();
  __dyc_funcallvar_38 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_39 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_40 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_41 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_42 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_43 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_read_ptr__typdef_simple_object_write_section();
  __dyc_funcallvar_45 = __dyc_read_ptr__void();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_48 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_49 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_50 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_51 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_52 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_53 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_54 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_55 = __dyc_read_ptr__void();
  __dyc_funcallvar_56 = (unsigned short )__dyc_readpre_byte();
  __dyc_funcallvar_57 = (unsigned short )__dyc_readpre_byte();
  __dyc_funcallvar_58 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_59 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_60 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_61 = (unsigned short )__dyc_readpre_byte();
  __dyc_funcallvar_62 = (unsigned short )__dyc_readpre_byte();
  __dyc_funcallvar_63 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_64 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_65 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_66 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_67 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_68 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_69 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_70 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_71 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_72 = __dyc_readpre_byte();
  __dyc_funcallvar_73 = __dyc_readpre_byte();
  __dyc_funcallvar_74 = __dyc_readpre_byte();
  __dyc_funcallvar_75 = __dyc_readpre_byte();
  __dyc_funcallvar_76 = __dyc_readpre_byte();
  errmsg = 0;
  shdr___1 = 0;
  sh_type___1 = 0;
  name___0 = 0;
  offset___0 = 0;
  length___0 = 0;
  dest = 0;
  flags = 0;
  buf___0 = 0;
  tmp___47 = 0;
  tmp___48 = 0;
  tmp___51 = 0;
  tmp___52 = 0;
  tmp___55 = 0;
  tmp___56 = 0;
  entsize___0 = 0;
  tmp___59 = 0;
  prevailing_name_idx = 0;
  ent___0 = 0;
  shndx_table = 0;
  sidxhdr = 0;
  sidxoff = 0;
  tmp___62 = 0;
  sidxsz = 0;
  tmp___65 = 0;
  shndx_type = 0;
  tmp___68 = 0;
  tmp___69 = 0;
  st_shndx = 0;
  tmp___72 = 0;
  tmp___73 = 0;
  tmp___74 = 0;
  st_info = 0;
  st_other = 0;
  tmp___77 = 0;
  tmp___78 = 0;
  st_shndx___0 = 0;
  tmp___81 = 0;
  tmp___82 = 0;
  tmp___83 = 0;
  raw_st_shndx = 0;
  st_info___0 = 0;
  st_other___0 = 0;
  discard = 0;
  bind = 0;
  other = 0;
  ent___1 = 0;
  dst = 0;
  shndx = 0;
  tmp___84 = 0;
  tmp___87 = 0;
  tmp___88 = 0;
  sh_info___0 = 0;
  sh_link___1 = 0;
  __s1_len = 0;
  __s2_len = 0;
  tmp___102 = 0;
  tmp___107 = 0;
  tmp___108 = 0;
  tmp___109 = 0;
  tmp___110 = 0;
#line 1321
  if ((size_t )sh_name___0 >= name_size) {
    {
#line 1323
    *err = 0;



    }
    goto __dyc_dummy_label;
  }
#line 1330
  name___0 = *(pfnname + (i - 1U));
#line 1331
  if ((int )ei_class == 1) {
    {
#line 1331
    tmp___47 = __dyc_funcallvar_38;
#line 1331
    offset___0 = (long )tmp___47;
    }
  } else {
    {
#line 1331
    tmp___48 = __dyc_funcallvar_39;
#line 1331
    offset___0 = (long )tmp___48;
    }
  }
#line 1333
  if ((int )ei_class == 1) {
    {
#line 1333
    tmp___51 = __dyc_funcallvar_40;
#line 1333
    length___0 = (long )tmp___51;
    }
  } else {
    {
#line 1333
    tmp___52 = __dyc_funcallvar_41;
#line 1333
    length___0 = (long )tmp___52;
    }
  }
#line 1335
  if ((int )ei_class == 1) {
    {
#line 1335
    sh_type___1 = __dyc_funcallvar_42;
    }
  } else {
    {
#line 1335
    sh_type___1 = __dyc_funcallvar_43;
    }
  }
#line 1338
  dest = __dyc_funcallvar_44;
#line 1340
  if ((unsigned long )dest == (unsigned long )((void *)0)) {
    {



    }
    goto __dyc_dummy_label;
  }

#line 1350
  shdr___1 = eow->shdrs + (size_t )(new_i - 1U) * shdr_size;
#line 1357
  tmp___55 = __dyc_funcallvar_45;
#line 1357
  buf___0 = (unsigned char *)tmp___55;
#line 1358
  tmp___56 = __dyc_funcallvar_46;
#line 1358
  if (! tmp___56) {
    {




    }
    goto __dyc_dummy_label;
  }
#line 1371
  if (sh_type___1 == 2U) {
#line 1373
    if ((int )ei_class == 1) {
      {
#line 1373
      tmp___59 = __dyc_funcallvar_47;
      }
    } else {
      {
#line 1373
      tmp___59 = __dyc_funcallvar_48;
      }
    }
#line 1373
    entsize___0 = (unsigned int )tmp___59;
#line 1375
    prevailing_name_idx = (size_t )0;
#line 1377
    shndx_table = (unsigned int *)((void *)0);
#line 1379
    if (*(symtab_indices_shndx + (i - 1U)) != 0U) {
#line 1381
      sidxhdr = shdrs + (size_t )*(symtab_indices_shndx + (i - 1U)) * shdr_size;
#line 1382
      if ((int )ei_class == 1) {
        {
#line 1382
        tmp___62 = __dyc_funcallvar_49;
        }
      } else {
        {
#line 1382
        tmp___62 = __dyc_funcallvar_50;
        }
      }
#line 1382
      sidxoff = (off_t )tmp___62;
#line 1384
      if ((int )ei_class == 1) {
        {
#line 1384
        tmp___65 = __dyc_funcallvar_51;
        }
      } else {
        {
#line 1384
        tmp___65 = __dyc_funcallvar_52;
        }
      }
#line 1384
      sidxsz = tmp___65;
#line 1386
      if ((int )ei_class == 1) {
        {
#line 1386
        tmp___68 = __dyc_funcallvar_53;
        }
      } else {
        {
#line 1386
        tmp___68 = __dyc_funcallvar_54;
        }
      }
#line 1386
      shndx_type = tmp___68;
#line 1389
      if (shndx_type != 18U) {
        goto __dyc_dummy_label;
      }
      {
#line 1391
      tmp___69 = __dyc_funcallvar_55;
#line 1391
      shndx_table = (unsigned int *)((char *)tmp___69);

      }
    }
#line 1401
    ent___0 = buf___0;
    {
#line 1401
    while (1) {
      while_15_continue: /* CIL Label */ ;
#line 1401
      if (! ((unsigned long )ent___0 < (unsigned long )(buf___0 + length___0))) {
        goto while_15_break;
      }
#line 1403
      if ((int )ei_class == 1) {
        {
#line 1403
        tmp___73 = __dyc_funcallvar_56;
#line 1403
        tmp___72 = (int )tmp___73;
        }
      } else {
        {
#line 1403
        tmp___74 = __dyc_funcallvar_57;
#line 1403
        tmp___72 = (int )tmp___74;
        }
      }
#line 1403
      st_shndx = (unsigned int )tmp___72;
#line 1408
      if ((int )ei_class == 1) {
#line 1410
        st_info = & ((Elf32_External_Sym *)ent___0)->st_info;
#line 1411
        st_other = & ((Elf32_External_Sym *)ent___0)->st_other;
      } else {
#line 1415
        st_info = & ((Elf64_External_Sym *)ent___0)->st_info;
#line 1416
        st_other = & ((Elf64_External_Sym *)ent___0)->st_other;
      }
#line 1418
      if (st_shndx == 65535U) {
        {
#line 1419
        st_shndx = __dyc_funcallvar_58;
        }
      }
#line 1422
      if (st_shndx != 65522U) {
#line 1422
        if (st_shndx != 0U) {
#line 1422
          if (st_shndx < shnum) {
#line 1422
            if (! (*(pfnret + (st_shndx - 1U)) == -1)) {
              goto _L___1;
            }
          } else {
            goto _L___1;
          }
        } else {
          _L___1: /* CIL Label */ 
#line 1422
          if ((int )*st_info >> 4 == 2) {
#line 1422
            if ((int )*st_other == 2) {
#line 1429
              if ((int )ei_class == 1) {
                {
#line 1429
                tmp___77 = __dyc_funcallvar_59;
#line 1429
                prevailing_name_idx = (unsigned long )tmp___77;
                }
              } else {
                {
#line 1429
                tmp___78 = __dyc_funcallvar_60;
#line 1429
                prevailing_name_idx = (unsigned long )tmp___78;
                }
              }
              goto while_15_break;
            }
          }
        }
      }
#line 1401
      ent___0 += entsize___0;
    }
    while_15_break: /* CIL Label */ ;
    }
#line 1436
    ent___0 = buf___0;
    {
#line 1436
    while (1) {
      while_16_continue: /* CIL Label */ ;
#line 1436
      if (! ((unsigned long )ent___0 < (unsigned long )(buf___0 + length___0))) {
        goto while_16_break;
      }
#line 1438
      if ((int )ei_class == 1) {
        {
#line 1438
        tmp___82 = __dyc_funcallvar_61;
#line 1438
        tmp___81 = (int )tmp___82;
        }
      } else {
        {
#line 1438
        tmp___83 = __dyc_funcallvar_62;
#line 1438
        tmp___81 = (int )tmp___83;
        }
      }
#line 1438
      st_shndx___0 = (unsigned int )tmp___81;
#line 1441
      raw_st_shndx = st_shndx___0;
#line 1444
      discard = 0;
#line 1445
      if ((int )ei_class == 1) {
#line 1447
        st_info___0 = & ((Elf32_External_Sym *)ent___0)->st_info;
#line 1448
        st_other___0 = & ((Elf32_External_Sym *)ent___0)->st_other;
      } else {
#line 1452
        st_info___0 = & ((Elf64_External_Sym *)ent___0)->st_info;
#line 1453
        st_other___0 = & ((Elf64_External_Sym *)ent___0)->st_other;
      }
#line 1455
      if (st_shndx___0 == 65535U) {
        {
#line 1456
        st_shndx___0 = __dyc_funcallvar_63;
        }
      }
#line 1462
      if (st_shndx___0 == 65522U) {
#line 1463
        discard = 1;
      } else {
#line 1469
        if (st_shndx___0 != 0U) {
#line 1469
          if (st_shndx___0 < shnum) {
#line 1469
            if (*(pfnret + (st_shndx___0 - 1U)) == -1) {
#line 1472
              discard = 1;
            } else {
              goto _L___3;
            }
          } else {
            goto _L___3;
          }
        } else {
          _L___3: /* CIL Label */ 
#line 1475
          if (st_shndx___0 == 0U) {
#line 1475
            if ((int )*st_info___0 >> 4 == 1) {
#line 1477
              discard = 1;
            }
          }
        }
      }
#line 1479
      if (discard) {
#line 1483
        bind = (int )*st_info___0 >> 4;
#line 1484
        other = 0;
#line 1485
        if (bind == 0) {
#line 1489
          if ((int )ei_class == 1) {
            {

            }
          } else {
            {

            }
          }
#line 1491
          if ((int )ei_class == 1) {
            {

            }
          } else {
            {

            }
          }
        } else {
#line 1500
          bind = 2;
#line 1501
          other = 2;
#line 1502
          if ((int )ei_class == 1) {
            {

            }
          } else {
            {

            }
          }
#line 1505
          if ((int )ei_class == 1) {
            {

            }
          } else {
            {

            }
          }
        }
#line 1508
        *st_other___0 = (unsigned char )other;
#line 1509
        *st_info___0 = (unsigned char )(bind << 4);
#line 1510
        if ((int )ei_class == 1) {
          {

          }
        } else {
          {

          }
        }
#line 1512
        if ((int )ei_class == 1) {
          {

          }
        } else {
          {

          }
        }
      } else {
#line 1515
        if (raw_st_shndx < 65280U) {
          goto _L___4;
        } else {
#line 1515
          if (raw_st_shndx == 65535U) {
            _L___4: /* CIL Label */ 
#line 1518
            if ((int )ei_class == 1) {
              {

              }
            } else {
              {

              }
            }
          }
        }
      }
#line 1436
      ent___0 += entsize___0;
    }
    while_16_break: /* CIL Label */ ;
    }
    {

    }
  } else {
#line 1523
    if (sh_type___1 == 17U) {
#line 1527
      ent___1 = buf___0 + 4;
#line 1527
      dst = ent___1;
      {
#line 1527
      while (1) {
        while_17_continue: /* CIL Label */ ;
#line 1527
        if (! ((unsigned long )ent___1 < (unsigned long )(buf___0 + length___0))) {
          goto while_17_break;
        }
        {
#line 1529
        tmp___84 = __dyc_funcallvar_64;
#line 1529
        shndx = tmp___84;
        }
#line 1530
        if (! (*(pfnret + (shndx - 1U)) == -1)) {
          {

#line 1535
          dst += 4;
          }
        }
#line 1527
        ent___1 += 4;
      }
      while_17_break: /* CIL Label */ ;
      }
#line 1539
      length___0 = (long )(dst - buf___0);
    }
  }
#line 1542
  errmsg = __dyc_funcallvar_65;

#line 1545
  if (errmsg) {
    {



    }
    goto __dyc_dummy_label;
  }
#line 1553
  if ((int )ei_class == 1) {
    {
#line 1553
    tmp___87 = __dyc_funcallvar_66;
#line 1553
    flags = (long )tmp___87;
    }
  } else {
    {
#line 1553
    tmp___88 = __dyc_funcallvar_67;
#line 1553
    flags = (long )tmp___88;
    }
  }
#line 1558
  if (flags & 64L) {
    goto _L___5;
  } else {
#line 1558
    if (sh_type___1 == 9U) {
      goto _L___5;
    } else {
#line 1558
      if (sh_type___1 == 4U) {
        _L___5: /* CIL Label */ 
#line 1560
        if ((int )ei_class == 1) {
          {
#line 1560
          sh_info___0 = __dyc_funcallvar_68;
          }
        } else {
          {
#line 1560
          sh_info___0 = __dyc_funcallvar_69;
          }
        }
#line 1562
        if (sh_info___0 < 65280U) {
#line 1564
          sh_info___0 = *(sh_map + sh_info___0);
        } else {
#line 1562
          if (sh_info___0 > 65535U) {
#line 1564
            sh_info___0 = *(sh_map + sh_info___0);
          }
        }
#line 1565
        if ((int )ei_class == 1) {
          {

          }
        } else {
          {

          }
        }
      }
    }
  }
#line 1568
  if ((int )ei_class == 1) {
    {
#line 1568
    sh_link___1 = __dyc_funcallvar_70;
    }
  } else {
    {
#line 1568
    sh_link___1 = __dyc_funcallvar_71;
    }
  }
#line 1570
  if (sh_link___1 < 65280U) {
#line 1572
    sh_link___1 = *(sh_map + sh_link___1);
  } else {
#line 1570
    if (sh_link___1 > 65535U) {
#line 1572
      sh_link___1 = *(sh_map + sh_link___1);
    }
  }
#line 1573
  if ((int )ei_class == 1) {
    {

    }
  } else {
    {

    }
  }
#line 1579
  if (0) {
    {
#line 1579
    tmp___108 = __dyc_funcallvar_72;
#line 1579
    __s1_len = (unsigned long )tmp___108;
#line 1579
    tmp___109 = __dyc_funcallvar_73;
#line 1579
    __s2_len = (unsigned long )tmp___109;
    }
#line 1579
    if (! ((unsigned long )((void const   *)(name___0 + 1)) - (unsigned long )((void const   *)name___0) == 1UL)) {
      goto _L___7;
    } else {
#line 1579
      if (__s1_len >= 4UL) {
        _L___7: /* CIL Label */ 
#line 1579
        if (! ((unsigned long )((void const   *)(".note.GNU-stack" + 1)) - (unsigned long )((void const   *)".note.GNU-stack") == 1UL)) {
#line 1579
          tmp___110 = 1;
        } else {
#line 1579
          if (__s2_len >= 4UL) {
#line 1579
            tmp___110 = 1;
          } else {
#line 1579
            tmp___110 = 0;
          }
        }
      } else {
#line 1579
        tmp___110 = 0;
      }
    }
#line 1579
    if (tmp___110) {
      {
#line 1579
      tmp___102 = __dyc_funcallvar_74;
      }
    } else {
      {
#line 1579
      tmp___107 = __dyc_funcallvar_75;
#line 1579
      tmp___102 = tmp___107;
      }
    }
  } else {
    {
#line 1579
    tmp___107 = __dyc_funcallvar_76;
#line 1579
    tmp___102 = tmp___107;
    }
  }
#line 1579
  if (tmp___102 == 0) {
#line 1580
    flags &= -5L;
  }
#line 1582
  flags &= 2147483647L;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__char(shdr___1);
  __dyc_printpre_byte(sh_type___1);
  __dyc_print_ptr__char(name___0);
  __dyc_printpre_byte(offset___0);
  __dyc_printpre_byte(length___0);
  __dyc_printpre_byte(flags);
  __dyc_print_ptr__char(buf___0);
  __dyc_printpre_byte(entsize___0);
  __dyc_printpre_byte(prevailing_name_idx);
  __dyc_print_ptr__int(shndx_table);
  __dyc_print_ptr__char(sidxhdr);
  __dyc_printpre_byte(sidxoff);
  __dyc_printpre_byte(sidxsz);
  __dyc_print_ptr__char(st_info);
  __dyc_print_ptr__char(st_other);
  __dyc_printpre_byte(raw_st_shndx);
  __dyc_print_ptr__char(st_info___0);
  __dyc_print_ptr__char(st_other___0);
  __dyc_printpre_byte(sh_info___0);
  __dyc_printpre_byte(sh_link___1);
  __dyc_printpre_byte(__s1_len);
  __dyc_printpre_byte(__s2_len);
}
}
