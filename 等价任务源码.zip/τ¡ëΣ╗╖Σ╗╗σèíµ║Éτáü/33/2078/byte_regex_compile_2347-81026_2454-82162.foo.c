#include <dycfoo.h>
#include "../regex.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned char c ;
  unsigned char c1 ;
  char const   *p1 ;
  unsigned char *b ;
  compile_stack_type compile_stack ;
  char const   *p ;
  char const   *pend ;
  char *translate ;
  unsigned char *pending_exact ;
  unsigned char *laststart ;
  unsigned char *begalt ;
  unsigned char *fixup_alt_jump ;
  regnum_t regnum ;
  void *tmp ;
  void *tmp___0 ;
  void *tmp___1 ;
  char const   *tmp___2 ;
  unsigned char *old_buffer ;
  void *tmp___3 ;
  ptrdiff_t incr ;
  unsigned char *tmp___4 ;
  boolean tmp___5 ;
  unsigned char *old_buffer___0 ;
  void *tmp___6 ;
  ptrdiff_t incr___0 ;
  unsigned char *tmp___7 ;
  boolean tmp___8 ;
  boolean keep_string_p ;
  char zero_times_ok ;
  char many_times_ok ;
  char const   *tmp___9 ;
  char const   *tmp___10 ;
  unsigned char *old_buffer___1 ;
  void *tmp___11 ;
  ptrdiff_t incr___1 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  unsigned char *old_buffer___2 ;
  void *tmp___16 ;
  ptrdiff_t incr___2 ;
  int tmp___17 ;
  unsigned char *old_buffer___3 ;
  void *tmp___18 ;
  ptrdiff_t incr___3 ;
  unsigned char *old_buffer___4 ;
  void *tmp___19 ;
  ptrdiff_t incr___4 ;
  unsigned char *tmp___20 ;
  boolean had_char_class ;
  unsigned int range_start ;
  unsigned char *old_buffer___5 ;
  void *tmp___21 ;
  ptrdiff_t incr___5 ;
  unsigned char *old_buffer___6 ;
  void *tmp___22 ;
  ptrdiff_t incr___6 ;
  unsigned char *tmp___23 ;
  int tmp___24 ;
  unsigned char *old_buffer___7 ;
  void *tmp___25 ;
  ptrdiff_t incr___7 ;
  unsigned char *tmp___26 ;
  char const   *tmp___27 ;
  char const   *tmp___28 ;
  reg_errcode_t ret ;
  reg_errcode_t tmp___29 ;
  reg_errcode_t ret___0 ;
  char const   *tmp___30 ;
  char str[7] ;
  char const   *tmp___31 ;
  char const   *tmp___32 ;
  unsigned char tmp___33 ;
  int ch ;
  boolean is_alnum ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___43 ;
  int tmp___48 ;
  int tmp___49 ;
  int tmp___50 ;
  int tmp___51 ;
  boolean is_alpha ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___61 ;
  int tmp___66 ;
  int tmp___67 ;
  int tmp___68 ;
  int tmp___69 ;
  boolean is_blank ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___79 ;
  int tmp___84 ;
  int tmp___85 ;
  int tmp___86 ;
  int tmp___87 ;
  boolean is_cntrl ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___97 ;
  int tmp___102 ;
  int tmp___103 ;
  int tmp___104 ;
  int tmp___105 ;
  boolean is_digit ;
  size_t __s1_len___3 ;
  size_t __s2_len___3 ;
  int tmp___115 ;
  int tmp___120 ;
  int tmp___121 ;
  int tmp___122 ;
  int tmp___123 ;
  boolean is_graph ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___133 ;
  int tmp___138 ;
  int tmp___139 ;
  int tmp___140 ;
  int tmp___141 ;
  boolean is_lower ;
  size_t __s1_len___5 ;
  size_t __s2_len___5 ;
  int tmp___151 ;
  int tmp___156 ;
  int tmp___157 ;
  int tmp___158 ;
  int tmp___159 ;
  boolean is_print ;
  size_t __s1_len___6 ;
  size_t __s2_len___6 ;
  int tmp___169 ;
  int tmp___174 ;
  int tmp___175 ;
  int tmp___176 ;
  int tmp___177 ;
  boolean is_punct ;
  size_t __s1_len___7 ;
  size_t __s2_len___7 ;
  int tmp___187 ;
  int tmp___192 ;
  int tmp___193 ;
  int tmp___194 ;
  int tmp___195 ;
  boolean is_space ;
  size_t __s1_len___8 ;
  size_t __s2_len___8 ;
  int tmp___205 ;
  int tmp___210 ;
  int tmp___211 ;
  int tmp___212 ;
  int tmp___213 ;
  boolean is_upper ;
  size_t __s1_len___9 ;
  size_t __s2_len___9 ;
  int tmp___223 ;
  int tmp___228 ;
  int tmp___229 ;
  int tmp___230 ;
  int tmp___231 ;
  boolean is_xdigit ;
  size_t __s1_len___10 ;
  size_t __s2_len___10 ;
  int tmp___241 ;
  int tmp___246 ;
  int tmp___247 ;
  int tmp___248 ;
  int tmp___249 ;
  size_t __s1_len___11 ;
  size_t __s2_len___11 ;
  int tmp___259 ;
  int tmp___264 ;
  int tmp___265 ;
  int tmp___266 ;
  int tmp___267 ;
  size_t __s1_len___12 ;
  size_t __s2_len___12 ;
  int tmp___277 ;
  int tmp___282 ;
  int tmp___283 ;
  int tmp___284 ;
  int tmp___285 ;
  size_t __s1_len___13 ;
  size_t __s2_len___13 ;
  int tmp___295 ;
  int tmp___300 ;
  int tmp___301 ;
  int tmp___302 ;
  int tmp___303 ;
  size_t __s1_len___14 ;
  size_t __s2_len___14 ;
  int tmp___313 ;
  int tmp___318 ;
  int tmp___319 ;
  int tmp___320 ;
  int tmp___321 ;
  size_t __s1_len___15 ;
  size_t __s2_len___15 ;
  int tmp___331 ;
  int tmp___336 ;
  int tmp___337 ;
  int tmp___338 ;
  int tmp___339 ;
  size_t __s1_len___16 ;
  size_t __s2_len___16 ;
  int tmp___349 ;
  int tmp___354 ;
  int tmp___355 ;
  int tmp___356 ;
  int tmp___357 ;
  size_t __s1_len___17 ;
  size_t __s2_len___17 ;
  int tmp___367 ;
  int tmp___372 ;
  int tmp___373 ;
  int tmp___374 ;
  int tmp___375 ;
  size_t __s1_len___18 ;
  size_t __s2_len___18 ;
  int tmp___385 ;
  int tmp___390 ;
  int tmp___391 ;
  int tmp___392 ;
  int tmp___393 ;
  size_t __s1_len___19 ;
  size_t __s2_len___19 ;
  int tmp___403 ;
  int tmp___408 ;
  int tmp___409 ;
  int tmp___410 ;
  int tmp___411 ;
  size_t __s1_len___20 ;
  size_t __s2_len___20 ;
  int tmp___421 ;
  int tmp___426 ;
  int tmp___427 ;
  int tmp___428 ;
  int tmp___429 ;
  size_t __s1_len___21 ;
  size_t __s2_len___21 ;
  int tmp___439 ;
  int tmp___444 ;
  int tmp___445 ;
  int tmp___446 ;
  int tmp___447 ;
  size_t __s1_len___22 ;
  size_t __s2_len___22 ;
  int tmp___457 ;
  int tmp___462 ;
  int tmp___463 ;
  int tmp___464 ;
  int tmp___465 ;
  char const   *tmp___466 ;
  unsigned short const   **tmp___467 ;
  unsigned short const   **tmp___468 ;
  unsigned short const   **tmp___469 ;
  unsigned short const   **tmp___470 ;
  unsigned short const   **tmp___471 ;
  unsigned short const   **tmp___472 ;
  unsigned short const   **tmp___473 ;
  unsigned short const   **tmp___474 ;
  unsigned short const   **tmp___475 ;
  unsigned short const   **tmp___476 ;
  unsigned short const   **tmp___477 ;
  unsigned short const   **tmp___478 ;
  unsigned short const   **tmp___479 ;
  unsigned short const   **tmp___480 ;
  unsigned char tmp___481 ;
  unsigned char str___0[17] ;
  char const   *tmp___482 ;
  char const   *tmp___483 ;
  unsigned char tmp___484 ;
  char const   *tmp___485 ;
  unsigned char tmp___486 ;
  unsigned char str___1[128] ;
  char const   *tmp___487 ;
  char const   *tmp___488 ;
  unsigned char tmp___489 ;
  char const   *tmp___490 ;
  unsigned char tmp___491 ;
  char const   *tmp___492 ;
  void *tmp___493 ;
  unsigned char *old_buffer___8 ;
  void *tmp___494 ;
  ptrdiff_t incr___8 ;
  unsigned char *tmp___495 ;
  unsigned char *tmp___496 ;
  unsigned char *tmp___497 ;
  unsigned char *old_buffer___9 ;
  void *tmp___498 ;
  ptrdiff_t incr___9 ;
  unsigned char *tmp___499 ;
  regnum_t this_group_regnum ;
  unsigned char *inner_group_loc ;
  unsigned char *old_buffer___10 ;
  void *tmp___500 ;
  ptrdiff_t incr___10 ;
  unsigned char *tmp___501 ;
  unsigned char *tmp___502 ;
  unsigned char *tmp___503 ;
  unsigned char *old_buffer___11 ;
  void *tmp___504 ;
  ptrdiff_t incr___11 ;
  unsigned char *old_buffer___12 ;
  void *tmp___505 ;
  ptrdiff_t incr___12 ;
  int lower_bound ;
  int upper_bound ;
  char const   *beg_interval ;
  char const   *tmp___506 ;
  char const   *tmp___507 ;
  char const   *tmp___508 ;
  unsigned char *old_buffer___13 ;
  void *tmp___509 ;
  ptrdiff_t incr___13 ;
  unsigned int nbytes ;
  unsigned char *old_buffer___14 ;
  void *tmp___510 ;
  ptrdiff_t incr___14 ;
  int tmp___511 ;
  unsigned char *old_buffer___15 ;
  void *tmp___512 ;
  ptrdiff_t incr___15 ;
  unsigned char *tmp___513 ;
  unsigned char *old_buffer___16 ;
  void *tmp___514 ;
  ptrdiff_t incr___16 ;
  unsigned char *tmp___515 ;
  unsigned char *old_buffer___17 ;
  void *tmp___516 ;
  ptrdiff_t incr___17 ;
  unsigned char *tmp___517 ;
  unsigned char *old_buffer___18 ;
  void *tmp___518 ;
  ptrdiff_t incr___18 ;
  unsigned char *tmp___519 ;
  unsigned char *old_buffer___19 ;
  void *tmp___520 ;
  ptrdiff_t incr___19 ;
  unsigned char *tmp___521 ;
  unsigned char *old_buffer___20 ;
  void *tmp___522 ;
  ptrdiff_t incr___20 ;
  unsigned char *tmp___523 ;
  unsigned char *old_buffer___21 ;
  void *tmp___524 ;
  ptrdiff_t incr___21 ;
  unsigned char *tmp___525 ;
  unsigned char *old_buffer___22 ;
  void *tmp___526 ;
  ptrdiff_t incr___22 ;
  unsigned char *tmp___527 ;
  boolean tmp___528 ;
  unsigned char *old_buffer___23 ;
  void *tmp___529 ;
  ptrdiff_t incr___23 ;
  unsigned char *tmp___530 ;
  unsigned char *tmp___531 ;
  unsigned char *old_buffer___24 ;
  void *tmp___532 ;
  ptrdiff_t incr___24 ;
  unsigned char *tmp___533 ;
  unsigned char *tmp___534 ;
  int tmp___537 ;
  int tmp___538 ;
  int tmp___539 ;
  int tmp___541 ;
  int tmp___542 ;
  unsigned char *old_buffer___25 ;
  void *tmp___543 ;
  ptrdiff_t incr___25 ;
  unsigned char *tmp___544 ;
  char const   *pattern ;
  reg_syntax_t syntax ;
  struct re_pattern_buffer *bufp ;
  void *__dyc_funcallvar_1 ;
  void *__dyc_funcallvar_2 ;
  void *__dyc_funcallvar_3 ;
  boolean __dyc_funcallvar_4 ;
  void *__dyc_funcallvar_5 ;
  boolean __dyc_funcallvar_6 ;
  void *__dyc_funcallvar_7 ;
  void *__dyc_funcallvar_8 ;
  void *__dyc_funcallvar_9 ;
  void *__dyc_funcallvar_10 ;
  void *__dyc_funcallvar_11 ;
  void *__dyc_funcallvar_12 ;
  void *__dyc_funcallvar_13 ;
  void *__dyc_funcallvar_14 ;
  reg_errcode_t __dyc_funcallvar_15 ;
  reg_errcode_t __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;
  int __dyc_funcallvar_30 ;
  int __dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  int __dyc_funcallvar_33 ;
  int __dyc_funcallvar_34 ;
  int __dyc_funcallvar_35 ;
  int __dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  int __dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;
  int __dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  int __dyc_funcallvar_50 ;
  int __dyc_funcallvar_51 ;
  int __dyc_funcallvar_52 ;
  int __dyc_funcallvar_53 ;
  int __dyc_funcallvar_54 ;
  int __dyc_funcallvar_55 ;
  int __dyc_funcallvar_56 ;
  int __dyc_funcallvar_57 ;
  int __dyc_funcallvar_58 ;
  int __dyc_funcallvar_59 ;
  int __dyc_funcallvar_60 ;
  int __dyc_funcallvar_61 ;
  int __dyc_funcallvar_62 ;
  int __dyc_funcallvar_63 ;
  int __dyc_funcallvar_64 ;
  int __dyc_funcallvar_65 ;
  int __dyc_funcallvar_66 ;
  int __dyc_funcallvar_67 ;
  int __dyc_funcallvar_68 ;
  int __dyc_funcallvar_69 ;
  int __dyc_funcallvar_70 ;
  int __dyc_funcallvar_71 ;
  int __dyc_funcallvar_72 ;
  int __dyc_funcallvar_73 ;
  int __dyc_funcallvar_74 ;
  int __dyc_funcallvar_75 ;
  int __dyc_funcallvar_76 ;
  int __dyc_funcallvar_77 ;
  int __dyc_funcallvar_78 ;
  int __dyc_funcallvar_79 ;
  int __dyc_funcallvar_80 ;
  int __dyc_funcallvar_81 ;
  int __dyc_funcallvar_82 ;
  int __dyc_funcallvar_83 ;
  int __dyc_funcallvar_84 ;
  int __dyc_funcallvar_85 ;
  int __dyc_funcallvar_86 ;
  int __dyc_funcallvar_87 ;
  int __dyc_funcallvar_88 ;
  int __dyc_funcallvar_89 ;
  int __dyc_funcallvar_90 ;
  int __dyc_funcallvar_91 ;
  int __dyc_funcallvar_92 ;
  int __dyc_funcallvar_93 ;
  int __dyc_funcallvar_94 ;
  int __dyc_funcallvar_95 ;
  int __dyc_funcallvar_96 ;
  int __dyc_funcallvar_97 ;
  int __dyc_funcallvar_98 ;
  int __dyc_funcallvar_99 ;
  int __dyc_funcallvar_100 ;
  int __dyc_funcallvar_101 ;
  int __dyc_funcallvar_102 ;
  int __dyc_funcallvar_103 ;
  int __dyc_funcallvar_104 ;
  int __dyc_funcallvar_105 ;
  int __dyc_funcallvar_106 ;
  int __dyc_funcallvar_107 ;
  int __dyc_funcallvar_108 ;
  int __dyc_funcallvar_109 ;
  int __dyc_funcallvar_110 ;
  int __dyc_funcallvar_111 ;
  int __dyc_funcallvar_112 ;
  int __dyc_funcallvar_113 ;
  int __dyc_funcallvar_114 ;
  int __dyc_funcallvar_115 ;
  int __dyc_funcallvar_116 ;
  int __dyc_funcallvar_117 ;
  int __dyc_funcallvar_118 ;
  int __dyc_funcallvar_119 ;
  int __dyc_funcallvar_120 ;
  int __dyc_funcallvar_121 ;
  int __dyc_funcallvar_122 ;
  int __dyc_funcallvar_123 ;
  int __dyc_funcallvar_124 ;
  int __dyc_funcallvar_125 ;
  int __dyc_funcallvar_126 ;
  int __dyc_funcallvar_127 ;
  int __dyc_funcallvar_128 ;
  int __dyc_funcallvar_129 ;
  int __dyc_funcallvar_130 ;
  int __dyc_funcallvar_131 ;
  int __dyc_funcallvar_132 ;
  int __dyc_funcallvar_133 ;
  int __dyc_funcallvar_134 ;
  int __dyc_funcallvar_135 ;
  int __dyc_funcallvar_136 ;
  unsigned short const   **__dyc_funcallvar_137 ;
  unsigned short const   **__dyc_funcallvar_138 ;
  unsigned short const   **__dyc_funcallvar_139 ;
  unsigned short const   **__dyc_funcallvar_140 ;
  unsigned short const   **__dyc_funcallvar_141 ;
  unsigned short const   **__dyc_funcallvar_142 ;
  unsigned short const   **__dyc_funcallvar_143 ;
  unsigned short const   **__dyc_funcallvar_144 ;
  unsigned short const   **__dyc_funcallvar_145 ;
  unsigned short const   **__dyc_funcallvar_146 ;
  unsigned short const   **__dyc_funcallvar_147 ;
  unsigned short const   **__dyc_funcallvar_148 ;
  unsigned short const   **__dyc_funcallvar_149 ;
  unsigned short const   **__dyc_funcallvar_150 ;
  void *__dyc_funcallvar_151 ;
  void *__dyc_funcallvar_152 ;
  void *__dyc_funcallvar_153 ;
  void *__dyc_funcallvar_154 ;
  void *__dyc_funcallvar_155 ;
  void *__dyc_funcallvar_156 ;
  void *__dyc_funcallvar_157 ;
  void *__dyc_funcallvar_158 ;
  void *__dyc_funcallvar_159 ;
  void *__dyc_funcallvar_160 ;
  void *__dyc_funcallvar_161 ;
  void *__dyc_funcallvar_162 ;
  void *__dyc_funcallvar_163 ;
  void *__dyc_funcallvar_164 ;
  void *__dyc_funcallvar_165 ;
  void *__dyc_funcallvar_166 ;
  boolean __dyc_funcallvar_167 ;
  void *__dyc_funcallvar_168 ;
  void *__dyc_funcallvar_169 ;
  void *__dyc_funcallvar_170 ;

  {
  p = (char const   *)__dyc_read_ptr__char();
  pend = (char const   *)__dyc_read_ptr__char();
  translate = (char *)__dyc_read_ptr__char();
  pending_exact = __dyc_read_ptr__char();
  laststart = __dyc_read_ptr__char();
  fixup_alt_jump = __dyc_read_ptr__char();
  pattern = (char const   *)__dyc_read_ptr__char();
  syntax = (reg_syntax_t )__dyc_readpre_byte();
  bufp = __dyc_read_ptr__comp_30re_pattern_buffer();
  __dyc_funcallvar_1 = __dyc_read_ptr__void();
  __dyc_funcallvar_2 = __dyc_read_ptr__void();
  __dyc_funcallvar_3 = __dyc_read_ptr__void();
  __dyc_funcallvar_4 = (boolean )__dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_read_ptr__void();
  __dyc_funcallvar_6 = (boolean )__dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_read_ptr__void();
  __dyc_funcallvar_8 = __dyc_read_ptr__void();
  __dyc_funcallvar_9 = __dyc_read_ptr__void();
  __dyc_funcallvar_10 = __dyc_read_ptr__void();
  __dyc_funcallvar_11 = __dyc_read_ptr__void();
  __dyc_funcallvar_12 = __dyc_read_ptr__void();
  __dyc_funcallvar_13 = __dyc_read_ptr__void();
  __dyc_funcallvar_14 = __dyc_read_ptr__void();
  __dyc_funcallvar_15 = (reg_errcode_t )__dyc_readpre_byte();
  __dyc_funcallvar_16 = (reg_errcode_t )__dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  __dyc_funcallvar_31 = __dyc_readpre_byte();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_readpre_byte();
  __dyc_funcallvar_36 = __dyc_readpre_byte();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_readpre_byte();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = __dyc_readpre_byte();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_readpre_byte();
  __dyc_funcallvar_51 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  __dyc_funcallvar_53 = __dyc_readpre_byte();
  __dyc_funcallvar_54 = __dyc_readpre_byte();
  __dyc_funcallvar_55 = __dyc_readpre_byte();
  __dyc_funcallvar_56 = __dyc_readpre_byte();
  __dyc_funcallvar_57 = __dyc_readpre_byte();
  __dyc_funcallvar_58 = __dyc_readpre_byte();
  __dyc_funcallvar_59 = __dyc_readpre_byte();
  __dyc_funcallvar_60 = __dyc_readpre_byte();
  __dyc_funcallvar_61 = __dyc_readpre_byte();
  __dyc_funcallvar_62 = __dyc_readpre_byte();
  __dyc_funcallvar_63 = __dyc_readpre_byte();
  __dyc_funcallvar_64 = __dyc_readpre_byte();
  __dyc_funcallvar_65 = __dyc_readpre_byte();
  __dyc_funcallvar_66 = __dyc_readpre_byte();
  __dyc_funcallvar_67 = __dyc_readpre_byte();
  __dyc_funcallvar_68 = __dyc_readpre_byte();
  __dyc_funcallvar_69 = __dyc_readpre_byte();
  __dyc_funcallvar_70 = __dyc_readpre_byte();
  __dyc_funcallvar_71 = __dyc_readpre_byte();
  __dyc_funcallvar_72 = __dyc_readpre_byte();
  __dyc_funcallvar_73 = __dyc_readpre_byte();
  __dyc_funcallvar_74 = __dyc_readpre_byte();
  __dyc_funcallvar_75 = __dyc_readpre_byte();
  __dyc_funcallvar_76 = __dyc_readpre_byte();
  __dyc_funcallvar_77 = __dyc_readpre_byte();
  __dyc_funcallvar_78 = __dyc_readpre_byte();
  __dyc_funcallvar_79 = __dyc_readpre_byte();
  __dyc_funcallvar_80 = __dyc_readpre_byte();
  __dyc_funcallvar_81 = __dyc_readpre_byte();
  __dyc_funcallvar_82 = __dyc_readpre_byte();
  __dyc_funcallvar_83 = __dyc_readpre_byte();
  __dyc_funcallvar_84 = __dyc_readpre_byte();
  __dyc_funcallvar_85 = __dyc_readpre_byte();
  __dyc_funcallvar_86 = __dyc_readpre_byte();
  __dyc_funcallvar_87 = __dyc_readpre_byte();
  __dyc_funcallvar_88 = __dyc_readpre_byte();
  __dyc_funcallvar_89 = __dyc_readpre_byte();
  __dyc_funcallvar_90 = __dyc_readpre_byte();
  __dyc_funcallvar_91 = __dyc_readpre_byte();
  __dyc_funcallvar_92 = __dyc_readpre_byte();
  __dyc_funcallvar_93 = __dyc_readpre_byte();
  __dyc_funcallvar_94 = __dyc_readpre_byte();
  __dyc_funcallvar_95 = __dyc_readpre_byte();
  __dyc_funcallvar_96 = __dyc_readpre_byte();
  __dyc_funcallvar_97 = __dyc_readpre_byte();
  __dyc_funcallvar_98 = __dyc_readpre_byte();
  __dyc_funcallvar_99 = __dyc_readpre_byte();
  __dyc_funcallvar_100 = __dyc_readpre_byte();
  __dyc_funcallvar_101 = __dyc_readpre_byte();
  __dyc_funcallvar_102 = __dyc_readpre_byte();
  __dyc_funcallvar_103 = __dyc_readpre_byte();
  __dyc_funcallvar_104 = __dyc_readpre_byte();
  __dyc_funcallvar_105 = __dyc_readpre_byte();
  __dyc_funcallvar_106 = __dyc_readpre_byte();
  __dyc_funcallvar_107 = __dyc_readpre_byte();
  __dyc_funcallvar_108 = __dyc_readpre_byte();
  __dyc_funcallvar_109 = __dyc_readpre_byte();
  __dyc_funcallvar_110 = __dyc_readpre_byte();
  __dyc_funcallvar_111 = __dyc_readpre_byte();
  __dyc_funcallvar_112 = __dyc_readpre_byte();
  __dyc_funcallvar_113 = __dyc_readpre_byte();
  __dyc_funcallvar_114 = __dyc_readpre_byte();
  __dyc_funcallvar_115 = __dyc_readpre_byte();
  __dyc_funcallvar_116 = __dyc_readpre_byte();
  __dyc_funcallvar_117 = __dyc_readpre_byte();
  __dyc_funcallvar_118 = __dyc_readpre_byte();
  __dyc_funcallvar_119 = __dyc_readpre_byte();
  __dyc_funcallvar_120 = __dyc_readpre_byte();
  __dyc_funcallvar_121 = __dyc_readpre_byte();
  __dyc_funcallvar_122 = __dyc_readpre_byte();
  __dyc_funcallvar_123 = __dyc_readpre_byte();
  __dyc_funcallvar_124 = __dyc_readpre_byte();
  __dyc_funcallvar_125 = __dyc_readpre_byte();
  __dyc_funcallvar_126 = __dyc_readpre_byte();
  __dyc_funcallvar_127 = __dyc_readpre_byte();
  __dyc_funcallvar_128 = __dyc_readpre_byte();
  __dyc_funcallvar_129 = __dyc_readpre_byte();
  __dyc_funcallvar_130 = __dyc_readpre_byte();
  __dyc_funcallvar_131 = __dyc_readpre_byte();
  __dyc_funcallvar_132 = __dyc_readpre_byte();
  __dyc_funcallvar_133 = __dyc_readpre_byte();
  __dyc_funcallvar_134 = __dyc_readpre_byte();
  __dyc_funcallvar_135 = __dyc_readpre_byte();
  __dyc_funcallvar_136 = __dyc_readpre_byte();
  __dyc_funcallvar_137 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_138 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_139 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_140 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_141 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_142 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_143 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_144 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_145 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_146 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_147 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_148 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_149 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_150 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_151 = __dyc_read_ptr__void();
  __dyc_funcallvar_152 = __dyc_read_ptr__void();
  __dyc_funcallvar_153 = __dyc_read_ptr__void();
  __dyc_funcallvar_154 = __dyc_read_ptr__void();
  __dyc_funcallvar_155 = __dyc_read_ptr__void();
  __dyc_funcallvar_156 = __dyc_read_ptr__void();
  __dyc_funcallvar_157 = __dyc_read_ptr__void();
  __dyc_funcallvar_158 = __dyc_read_ptr__void();
  __dyc_funcallvar_159 = __dyc_read_ptr__void();
  __dyc_funcallvar_160 = __dyc_read_ptr__void();
  __dyc_funcallvar_161 = __dyc_read_ptr__void();
  __dyc_funcallvar_162 = __dyc_read_ptr__void();
  __dyc_funcallvar_163 = __dyc_read_ptr__void();
  __dyc_funcallvar_164 = __dyc_read_ptr__void();
  __dyc_funcallvar_165 = __dyc_read_ptr__void();
  __dyc_funcallvar_166 = __dyc_read_ptr__void();
  __dyc_funcallvar_167 = (boolean )__dyc_readpre_byte();
  __dyc_funcallvar_168 = __dyc_read_ptr__void();
  __dyc_funcallvar_169 = __dyc_read_ptr__void();
  __dyc_funcallvar_170 = __dyc_read_ptr__void();
  c = 0;
  c1 = 0;
  p1 = 0;
  b = 0;
  memset(& compile_stack, 0, sizeof(compile_stack_type ));
  begalt = 0;
  regnum = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  old_buffer = 0;
  tmp___3 = 0;
  incr = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  old_buffer___0 = 0;
  tmp___6 = 0;
  incr___0 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  keep_string_p = 0;
  zero_times_ok = 0;
  many_times_ok = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  old_buffer___1 = 0;
  tmp___11 = 0;
  incr___1 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  old_buffer___2 = 0;
  tmp___16 = 0;
  incr___2 = 0;
  tmp___17 = 0;
  old_buffer___3 = 0;
  tmp___18 = 0;
  incr___3 = 0;
  old_buffer___4 = 0;
  tmp___19 = 0;
  incr___4 = 0;
  tmp___20 = 0;
  had_char_class = 0;
  range_start = 0;
  old_buffer___5 = 0;
  tmp___21 = 0;
  incr___5 = 0;
  old_buffer___6 = 0;
  tmp___22 = 0;
  incr___6 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  old_buffer___7 = 0;
  tmp___25 = 0;
  incr___7 = 0;
  tmp___26 = 0;
  tmp___27 = 0;
  tmp___28 = 0;
  ret = 0;
  tmp___29 = 0;
  ret___0 = 0;
  tmp___30 = 0;
  tmp___31 = 0;
  tmp___32 = 0;
  tmp___33 = 0;
  ch = 0;
  is_alnum = 0;
  __s1_len = 0;
  __s2_len = 0;
  tmp___43 = 0;
  tmp___48 = 0;
  tmp___49 = 0;
  tmp___50 = 0;
  tmp___51 = 0;
  is_alpha = 0;
  __s1_len___0 = 0;
  __s2_len___0 = 0;
  tmp___61 = 0;
  tmp___66 = 0;
  tmp___67 = 0;
  tmp___68 = 0;
  tmp___69 = 0;
  is_blank = 0;
  __s1_len___1 = 0;
  __s2_len___1 = 0;
  tmp___79 = 0;
  tmp___84 = 0;
  tmp___85 = 0;
  tmp___86 = 0;
  tmp___87 = 0;
  is_cntrl = 0;
  __s1_len___2 = 0;
  __s2_len___2 = 0;
  tmp___97 = 0;
  tmp___102 = 0;
  tmp___103 = 0;
  tmp___104 = 0;
  tmp___105 = 0;
  is_digit = 0;
  __s1_len___3 = 0;
  __s2_len___3 = 0;
  tmp___115 = 0;
  tmp___120 = 0;
  tmp___121 = 0;
  tmp___122 = 0;
  tmp___123 = 0;
  is_graph = 0;
  __s1_len___4 = 0;
  __s2_len___4 = 0;
  tmp___133 = 0;
  tmp___138 = 0;
  tmp___139 = 0;
  tmp___140 = 0;
  tmp___141 = 0;
  is_lower = 0;
  __s1_len___5 = 0;
  __s2_len___5 = 0;
  tmp___151 = 0;
  tmp___156 = 0;
  tmp___157 = 0;
  tmp___158 = 0;
  tmp___159 = 0;
  is_print = 0;
  __s1_len___6 = 0;
  __s2_len___6 = 0;
  tmp___169 = 0;
  tmp___174 = 0;
  tmp___175 = 0;
  tmp___176 = 0;
  tmp___177 = 0;
  is_punct = 0;
  __s1_len___7 = 0;
  __s2_len___7 = 0;
  tmp___187 = 0;
  tmp___192 = 0;
  tmp___193 = 0;
  tmp___194 = 0;
  tmp___195 = 0;
  is_space = 0;
  __s1_len___8 = 0;
  __s2_len___8 = 0;
  tmp___205 = 0;
  tmp___210 = 0;
  tmp___211 = 0;
  tmp___212 = 0;
  tmp___213 = 0;
  is_upper = 0;
  __s1_len___9 = 0;
  __s2_len___9 = 0;
  tmp___223 = 0;
  tmp___228 = 0;
  tmp___229 = 0;
  tmp___230 = 0;
  tmp___231 = 0;
  is_xdigit = 0;
  __s1_len___10 = 0;
  __s2_len___10 = 0;
  tmp___241 = 0;
  tmp___246 = 0;
  tmp___247 = 0;
  tmp___248 = 0;
  tmp___249 = 0;
  __s1_len___11 = 0;
  __s2_len___11 = 0;
  tmp___259 = 0;
  tmp___264 = 0;
  tmp___265 = 0;
  tmp___266 = 0;
  tmp___267 = 0;
  __s1_len___12 = 0;
  __s2_len___12 = 0;
  tmp___277 = 0;
  tmp___282 = 0;
  tmp___283 = 0;
  tmp___284 = 0;
  tmp___285 = 0;
  __s1_len___13 = 0;
  __s2_len___13 = 0;
  tmp___295 = 0;
  tmp___300 = 0;
  tmp___301 = 0;
  tmp___302 = 0;
  tmp___303 = 0;
  __s1_len___14 = 0;
  __s2_len___14 = 0;
  tmp___313 = 0;
  tmp___318 = 0;
  tmp___319 = 0;
  tmp___320 = 0;
  tmp___321 = 0;
  __s1_len___15 = 0;
  __s2_len___15 = 0;
  tmp___331 = 0;
  tmp___336 = 0;
  tmp___337 = 0;
  tmp___338 = 0;
  tmp___339 = 0;
  __s1_len___16 = 0;
  __s2_len___16 = 0;
  tmp___349 = 0;
  tmp___354 = 0;
  tmp___355 = 0;
  tmp___356 = 0;
  tmp___357 = 0;
  __s1_len___17 = 0;
  __s2_len___17 = 0;
  tmp___367 = 0;
  tmp___372 = 0;
  tmp___373 = 0;
  tmp___374 = 0;
  tmp___375 = 0;
  __s1_len___18 = 0;
  __s2_len___18 = 0;
  tmp___385 = 0;
  tmp___390 = 0;
  tmp___391 = 0;
  tmp___392 = 0;
  tmp___393 = 0;
  __s1_len___19 = 0;
  __s2_len___19 = 0;
  tmp___403 = 0;
  tmp___408 = 0;
  tmp___409 = 0;
  tmp___410 = 0;
  tmp___411 = 0;
  __s1_len___20 = 0;
  __s2_len___20 = 0;
  tmp___421 = 0;
  tmp___426 = 0;
  tmp___427 = 0;
  tmp___428 = 0;
  tmp___429 = 0;
  __s1_len___21 = 0;
  __s2_len___21 = 0;
  tmp___439 = 0;
  tmp___444 = 0;
  tmp___445 = 0;
  tmp___446 = 0;
  tmp___447 = 0;
  __s1_len___22 = 0;
  __s2_len___22 = 0;
  tmp___457 = 0;
  tmp___462 = 0;
  tmp___463 = 0;
  tmp___464 = 0;
  tmp___465 = 0;
  tmp___466 = 0;
  tmp___467 = 0;
  tmp___468 = 0;
  tmp___469 = 0;
  tmp___470 = 0;
  tmp___471 = 0;
  tmp___472 = 0;
  tmp___473 = 0;
  tmp___474 = 0;
  tmp___475 = 0;
  tmp___476 = 0;
  tmp___477 = 0;
  tmp___478 = 0;
  tmp___479 = 0;
  tmp___480 = 0;
  tmp___481 = 0;
  tmp___482 = 0;
  tmp___483 = 0;
  tmp___484 = 0;
  tmp___485 = 0;
  tmp___486 = 0;
  tmp___487 = 0;
  tmp___488 = 0;
  tmp___489 = 0;
  tmp___490 = 0;
  tmp___491 = 0;
  tmp___492 = 0;
  tmp___493 = 0;
  old_buffer___8 = 0;
  tmp___494 = 0;
  incr___8 = 0;
  tmp___495 = 0;
  tmp___496 = 0;
  tmp___497 = 0;
  old_buffer___9 = 0;
  tmp___498 = 0;
  incr___9 = 0;
  tmp___499 = 0;
  this_group_regnum = 0;
  inner_group_loc = 0;
  old_buffer___10 = 0;
  tmp___500 = 0;
  incr___10 = 0;
  tmp___501 = 0;
  tmp___502 = 0;
  tmp___503 = 0;
  old_buffer___11 = 0;
  tmp___504 = 0;
  incr___11 = 0;
  old_buffer___12 = 0;
  tmp___505 = 0;
  incr___12 = 0;
  lower_bound = 0;
  upper_bound = 0;
  beg_interval = 0;
  tmp___506 = 0;
  tmp___507 = 0;
  tmp___508 = 0;
  old_buffer___13 = 0;
  tmp___509 = 0;
  incr___13 = 0;
  nbytes = 0;
  old_buffer___14 = 0;
  tmp___510 = 0;
  incr___14 = 0;
  tmp___511 = 0;
  old_buffer___15 = 0;
  tmp___512 = 0;
  incr___15 = 0;
  tmp___513 = 0;
  old_buffer___16 = 0;
  tmp___514 = 0;
  incr___16 = 0;
  tmp___515 = 0;
  old_buffer___17 = 0;
  tmp___516 = 0;
  incr___17 = 0;
  tmp___517 = 0;
  old_buffer___18 = 0;
  tmp___518 = 0;
  incr___18 = 0;
  tmp___519 = 0;
  old_buffer___19 = 0;
  tmp___520 = 0;
  incr___19 = 0;
  tmp___521 = 0;
  old_buffer___20 = 0;
  tmp___522 = 0;
  incr___20 = 0;
  tmp___523 = 0;
  old_buffer___21 = 0;
  tmp___524 = 0;
  incr___21 = 0;
  tmp___525 = 0;
  old_buffer___22 = 0;
  tmp___526 = 0;
  incr___22 = 0;
  tmp___527 = 0;
  tmp___528 = 0;
  old_buffer___23 = 0;
  tmp___529 = 0;
  incr___23 = 0;
  tmp___530 = 0;
  tmp___531 = 0;
  old_buffer___24 = 0;
  tmp___532 = 0;
  incr___24 = 0;
  tmp___533 = 0;
  tmp___534 = 0;
  tmp___537 = 0;
  tmp___538 = 0;
  tmp___539 = 0;
  tmp___541 = 0;
  tmp___542 = 0;
  old_buffer___25 = 0;
  tmp___543 = 0;
  incr___25 = 0;
  tmp___544 = 0;
#line 2347
  regnum = (regnum_t )0;
#line 2386
  tmp = __dyc_funcallvar_1;
#line 2386
  compile_stack.stack = (compile_stack_elt_t *)tmp;
#line 2387
  if ((unsigned long )compile_stack.stack == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }
#line 2397
  compile_stack.size = 32U;
#line 2398
  compile_stack.avail = 0U;
#line 2401
  bufp->syntax = syntax;
#line 2402
  bufp->fastmap_accurate = 0U;
#line 2403
  bufp->not_eol = 0U;
#line 2403
  bufp->not_bol = bufp->not_eol;
#line 2408
  bufp->used = 0UL;
#line 2411
  bufp->re_nsub = 0UL;

#line 2418
  if (bufp->allocated == 0UL) {
#line 2420
    if (bufp->buffer) {
      {
#line 2431
      tmp___0 = __dyc_funcallvar_2;
#line 2431
      bufp->buffer = (unsigned char *)tmp___0;
      }
    } else {
      {
#line 2436
      tmp___1 = __dyc_funcallvar_3;
#line 2436
      bufp->buffer = (unsigned char *)tmp___1;
      }
    }
#line 2440
    if (! bufp->buffer) {
      {

      }
      goto __dyc_dummy_label;
    }
#line 2444
    bufp->allocated = 32UL * sizeof(unsigned char );
  }
#line 2451
  b = bufp->buffer;
#line 2451
  begalt = b;
#line 2454
  while (1) {
    while_1_continue: /* CIL Label */ ;
#line 2454
    if (! ((unsigned long )p != (unsigned long )pend)) {
      goto __dyc_dummy_label;
    }
    {
#line 2456
    while (1) {
      while_2_continue: /* CIL Label */ ;
#line 2456
      if ((unsigned long )p == (unsigned long )pend) {
        goto __dyc_dummy_label;
      }
#line 2456
      tmp___2 = p;
#line 2456
      p ++;
#line 2456
      c = (unsigned char )*tmp___2;
#line 2456
      if (translate) {
#line 2456
        c = (unsigned char )*(translate + c);
      }
      goto while_2_break;
    }
    while_2_break: /* CIL Label */ ;
    }
#line 2460
    if ((int )c == 94) {
      goto switch_3_94;
    } else {
#line 2475
      if ((int )c == 36) {
        goto switch_3_36;
      } else {
#line 2490
        if ((int )c == 43) {
          goto switch_3_43;
        } else {
#line 2491
          if ((int )c == 63) {
            goto switch_3_43;
          } else {
#line 2497
            if ((int )c == 42) {
              goto handle_plus;
            } else {
#line 2628
              if ((int )c == 46) {
                goto switch_3_46;
              } else {
#line 2634
                if ((int )c == 91) {
                  goto switch_3_91;
                } else {
#line 3609
                  if ((int )c == 40) {
                    goto switch_3_40;
                  } else {
#line 3616
                    if ((int )c == 41) {
                      goto switch_3_41;
                    } else {
#line 3623
                      if ((int )c == 10) {
                        goto switch_3_10;
                      } else {
#line 3630
                        if ((int )c == 124) {
                          goto switch_3_124;
                        } else {
#line 3637
                          if ((int )c == 123) {
                            goto switch_3_123;
                          } else {
#line 3644
                            if ((int )c == 92) {
                              goto switch_3_92;
                            } else {
                              {
                              goto switch_3_default;
#line 2458
                              if (0) {
                                switch_3_94: /* CIL Label */ 
#line 2462
                                if ((unsigned long )p == (unsigned long )(pattern + 1)) {
                                  goto _L;
                                } else {
#line 2462
                                  if (syntax & (((1UL << 1) << 1) << 1)) {
                                    goto _L;
                                  } else {
                                    {
#line 2462
                                    tmp___5 = __dyc_funcallvar_4;
                                    }
#line 2462
                                    if (tmp___5) {
                                      _L: /* CIL Label */ 
                                      {
#line 2468
                                      while (1) {
                                        while_4_continue: /* CIL Label */ ;
                                        {
#line 2468
                                        while (1) {
                                          while_5_continue: /* CIL Label */ ;
#line 2468
                                          if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                            goto while_5_break;
                                          }
                                          {
#line 2468
                                          while (1) {
                                            while_6_continue: /* CIL Label */ ;
#line 2468
                                            old_buffer = bufp->buffer;
#line 2468
                                            if (bufp->allocated == (unsigned long )(1L << 16)) {
                                              goto __dyc_dummy_label;
                                            }
#line 2468
                                            bufp->allocated <<= 1;
#line 2468
                                            if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 2468
                                              bufp->allocated = (unsigned long )(1L << 16);
                                            }
                                            {
#line 2468
                                            tmp___3 = __dyc_funcallvar_5;
#line 2468
                                            bufp->buffer = (unsigned char *)tmp___3;
                                            }
#line 2468
                                            if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                              goto __dyc_dummy_label;
                                            }
#line 2468
                                            if ((unsigned long )old_buffer != (unsigned long )bufp->buffer) {
#line 2468
                                              incr = (ptrdiff_t )(bufp->buffer - old_buffer);
#line 2468
                                              b += incr;
#line 2468
                                              begalt += incr;
#line 2468
                                              if (fixup_alt_jump) {
#line 2468
                                                fixup_alt_jump += incr;
                                              }
#line 2468
                                              if (laststart) {
#line 2468
                                                laststart += incr;
                                              }
#line 2468
                                              if (pending_exact) {
#line 2468
                                                pending_exact += incr;
                                              }
                                            }
                                            goto while_6_break;
                                          }
                                          while_6_break: /* CIL Label */ ;
                                          }
                                        }
                                        while_5_break: /* CIL Label */ ;
                                        }
#line 2468
                                        tmp___4 = b;
#line 2468
                                        b ++;
#line 2468
                                        *tmp___4 = (unsigned char)9;
                                        goto while_4_break;
                                      }
                                      while_4_break: /* CIL Label */ ;
                                      }
                                    } else {
                                      goto normal_char;
                                    }
                                  }
                                }
                                goto switch_3_break;
                                switch_3_36: /* CIL Label */ 
#line 2477
                                if ((unsigned long )p == (unsigned long )pend) {
                                  goto _L___0;
                                } else {
#line 2477
                                  if (syntax & (((1UL << 1) << 1) << 1)) {
                                    goto _L___0;
                                  } else {
                                    {
#line 2477
                                    tmp___8 = __dyc_funcallvar_6;
                                    }
#line 2477
                                    if (tmp___8) {
                                      _L___0: /* CIL Label */ 
                                      {
#line 2483
                                      while (1) {
                                        while_7_continue: /* CIL Label */ ;
                                        {
#line 2483
                                        while (1) {
                                          while_8_continue: /* CIL Label */ ;
#line 2483
                                          if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                            goto while_8_break;
                                          }
                                          {
#line 2483
                                          while (1) {
                                            while_9_continue: /* CIL Label */ ;
#line 2483
                                            old_buffer___0 = bufp->buffer;
#line 2483
                                            if (bufp->allocated == (unsigned long )(1L << 16)) {
                                              goto __dyc_dummy_label;
                                            }
#line 2483
                                            bufp->allocated <<= 1;
#line 2483
                                            if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 2483
                                              bufp->allocated = (unsigned long )(1L << 16);
                                            }
                                            {
#line 2483
                                            tmp___6 = __dyc_funcallvar_7;
#line 2483
                                            bufp->buffer = (unsigned char *)tmp___6;
                                            }
#line 2483
                                            if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                              goto __dyc_dummy_label;
                                            }
#line 2483
                                            if ((unsigned long )old_buffer___0 != (unsigned long )bufp->buffer) {
#line 2483
                                              incr___0 = (ptrdiff_t )(bufp->buffer - old_buffer___0);
#line 2483
                                              b += incr___0;
#line 2483
                                              begalt += incr___0;
#line 2483
                                              if (fixup_alt_jump) {
#line 2483
                                                fixup_alt_jump += incr___0;
                                              }
#line 2483
                                              if (laststart) {
#line 2483
                                                laststart += incr___0;
                                              }
#line 2483
                                              if (pending_exact) {
#line 2483
                                                pending_exact += incr___0;
                                              }
                                            }
                                            goto while_9_break;
                                          }
                                          while_9_break: /* CIL Label */ ;
                                          }
                                        }
                                        while_8_break: /* CIL Label */ ;
                                        }
#line 2483
                                        tmp___7 = b;
#line 2483
                                        b ++;
#line 2483
                                        *tmp___7 = (unsigned char)10;
                                        goto while_7_break;
                                      }
                                      while_7_break: /* CIL Label */ ;
                                      }
                                    } else {
                                      goto normal_char;
                                    }
                                  }
                                }
                                goto switch_3_break;
                                switch_3_43: /* CIL Label */ 
                                switch_3_63: /* CIL Label */ 
#line 2492
                                if (syntax & (1UL << 1)) {
                                  goto normal_char;
                                } else {
#line 2492
                                  if (syntax & ((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                    goto normal_char;
                                  }
                                }
                                handle_plus: 
                                switch_3_42: /* CIL Label */ 
#line 2499
                                if (! laststart) {
#line 2501
                                  if (syntax & (((((1UL << 1) << 1) << 1) << 1) << 1)) {
                                    {

                                    }
                                    goto __dyc_dummy_label;
                                  } else {
#line 2503
                                    if (! (syntax & ((((1UL << 1) << 1) << 1) << 1))) {
                                      goto normal_char;
                                    }
                                  }
                                }
#line 2509
                                keep_string_p = (boolean )0;
#line 2512
                                zero_times_ok = (char)0;
#line 2512
                                many_times_ok = (char)0;
                                {
#line 2519
                                while (1) {
                                  while_10_continue: /* CIL Label */ ;
#line 2521
                                  zero_times_ok = (char )((int )zero_times_ok | ((int )c != 43));
#line 2522
                                  many_times_ok = (char )((int )many_times_ok | ((int )c != 63));
#line 2524
                                  if ((unsigned long )p == (unsigned long )pend) {
                                    goto while_10_break;
                                  }
                                  {
#line 2527
                                  while (1) {
                                    while_11_continue: /* CIL Label */ ;
#line 2527
                                    if ((unsigned long )p == (unsigned long )pend) {
                                      goto __dyc_dummy_label;
                                    }
#line 2527
                                    tmp___9 = p;
#line 2527
                                    p ++;
#line 2527
                                    c = (unsigned char )*tmp___9;
#line 2527
                                    if (translate) {
#line 2527
                                      c = (unsigned char )*(translate + c);
                                    }
                                    goto while_11_break;
                                  }
                                  while_11_break: /* CIL Label */ ;
                                  }
#line 2529
                                  if (! ((int )c == 42)) {
#line 2529
                                    if (! (syntax & (1UL << 1))) {
#line 2529
                                      if (! ((int )c == 43)) {
#line 2529
                                        if (! ((int )c == 63)) {
                                          goto _L___1;
                                        }
                                      }
                                    } else {
                                      _L___1: /* CIL Label */ 
#line 2533
                                      if (syntax & (1UL << 1)) {
#line 2533
                                        if ((int )c == 92) {
#line 2535
                                          if ((unsigned long )p == (unsigned long )pend) {
                                            {

                                            }
                                            goto __dyc_dummy_label;
                                          }
                                          {
#line 2537
                                          while (1) {
                                            while_12_continue: /* CIL Label */ ;
#line 2537
                                            if ((unsigned long )p == (unsigned long )pend) {
                                              goto __dyc_dummy_label;
                                            }
#line 2537
                                            tmp___10 = p;
#line 2537
                                            p ++;
#line 2537
                                            c1 = (unsigned char )*tmp___10;
#line 2537
                                            if (translate) {
#line 2537
                                              c1 = (unsigned char )*(translate + c1);
                                            }
                                            goto while_12_break;
                                          }
                                          while_12_break: /* CIL Label */ ;
                                          }
#line 2538
                                          if (! ((int )c1 == 43)) {
#line 2538
                                            if (! ((int )c1 == 63)) {
#line 2540
                                              p --;
#line 2541
                                              p --;
                                              goto while_10_break;
                                            }
                                          }
#line 2545
                                          c = c1;
                                        } else {
#line 2549
                                          p --;
                                          goto while_10_break;
                                        }
                                      } else {
#line 2549
                                        p --;
                                        goto while_10_break;
                                      }
                                    }
                                  }
                                }
                                while_10_break: /* CIL Label */ ;
                                }
#line 2558
                                if (! laststart) {
                                  goto switch_3_break;
                                }
#line 2563
                                if (many_times_ok) {
                                  {
#line 2577
                                  while (1) {
                                    while_13_continue: /* CIL Label */ ;
#line 2577
                                    if (! ((unsigned long )((b - bufp->buffer) + 3) > bufp->allocated)) {
                                      goto while_13_break;
                                    }
                                    {
#line 2577
                                    while (1) {
                                      while_14_continue: /* CIL Label */ ;
#line 2577
                                      old_buffer___1 = bufp->buffer;
#line 2577
                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                        goto __dyc_dummy_label;
                                      }
#line 2577
                                      bufp->allocated <<= 1;
#line 2577
                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 2577
                                        bufp->allocated = (unsigned long )(1L << 16);
                                      }
                                      {
#line 2577
                                      tmp___11 = __dyc_funcallvar_8;
#line 2577
                                      bufp->buffer = (unsigned char *)tmp___11;
                                      }
#line 2577
                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                        goto __dyc_dummy_label;
                                      }
#line 2577
                                      if ((unsigned long )old_buffer___1 != (unsigned long )bufp->buffer) {
#line 2577
                                        incr___1 = (ptrdiff_t )(bufp->buffer - old_buffer___1);
#line 2577
                                        b += incr___1;
#line 2577
                                        begalt += incr___1;
#line 2577
                                        if (fixup_alt_jump) {
#line 2577
                                          fixup_alt_jump += incr___1;
                                        }
#line 2577
                                        if (laststart) {
#line 2577
                                          laststart += incr___1;
                                        }
#line 2577
                                        if (pending_exact) {
#line 2577
                                          pending_exact += incr___1;
                                        }
                                      }
                                      goto while_14_break;
                                    }
                                    while_14_break: /* CIL Label */ ;
                                    }
                                  }
                                  while_13_break: /* CIL Label */ ;
                                  }
#line 2584
                                  if (translate) {
#line 2584
                                    tmp___12 = (int )*(translate + (unsigned char )*(p - 2));
                                  } else {
#line 2584
                                    tmp___12 = (int )((char )*(p - 2));
                                  }
#line 2584
                                  if (translate) {
#line 2584
                                    tmp___13 = (int )*(translate + (unsigned char )'.');
                                  } else {
#line 2584
                                    tmp___13 = (int )((char )'.');
                                  }
#line 2584
                                  if (tmp___12 == tmp___13) {
#line 2584
                                    if (zero_times_ok) {
#line 2584
                                      if ((unsigned long )p < (unsigned long )pend) {
#line 2584
                                        if (translate) {
#line 2584
                                          tmp___14 = (int )*(translate + (unsigned char )*p);
                                        } else {
#line 2584
                                          tmp___14 = (int )((char )*p);
                                        }
#line 2584
                                        if (translate) {
#line 2584
                                          tmp___15 = (int )*(translate + (unsigned char )'\n');
                                        } else {
#line 2584
                                          tmp___15 = (int )((char )'\n');
                                        }
#line 2584
                                        if (tmp___14 == tmp___15) {
#line 2584
                                          if (! (syntax & ((((((1UL << 1) << 1) << 1) << 1) << 1) << 1))) {
                                            {

#line 2590
                                            keep_string_p = (char)1;
                                            }
                                          } else {
                                            {

                                            }
                                          }
                                        } else {
                                          {

                                          }
                                        }
                                      } else {
                                        {

                                        }
                                      }
                                    } else {
                                      {

                                      }
                                    }
                                  } else {
                                    {

                                    }
                                  }
#line 2598
                                  b += 3;
                                }
                                {
#line 2605
                                while (1) {
                                  while_15_continue: /* CIL Label */ ;
#line 2605
                                  if (! ((unsigned long )((b - bufp->buffer) + 3) > bufp->allocated)) {
                                    goto while_15_break;
                                  }
                                  {
#line 2605
                                  while (1) {
                                    while_16_continue: /* CIL Label */ ;
#line 2605
                                    old_buffer___2 = bufp->buffer;
#line 2605
                                    if (bufp->allocated == (unsigned long )(1L << 16)) {
                                      goto __dyc_dummy_label;
                                    }
#line 2605
                                    bufp->allocated <<= 1;
#line 2605
                                    if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 2605
                                      bufp->allocated = (unsigned long )(1L << 16);
                                    }
                                    {
#line 2605
                                    tmp___16 = __dyc_funcallvar_9;
#line 2605
                                    bufp->buffer = (unsigned char *)tmp___16;
                                    }
#line 2605
                                    if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                      goto __dyc_dummy_label;
                                    }
#line 2605
                                    if ((unsigned long )old_buffer___2 != (unsigned long )bufp->buffer) {
#line 2605
                                      incr___2 = (ptrdiff_t )(bufp->buffer - old_buffer___2);
#line 2605
                                      b += incr___2;
#line 2605
                                      begalt += incr___2;
#line 2605
                                      if (fixup_alt_jump) {
#line 2605
                                        fixup_alt_jump += incr___2;
                                      }
#line 2605
                                      if (laststart) {
#line 2605
                                        laststart += incr___2;
                                      }
#line 2605
                                      if (pending_exact) {
#line 2605
                                        pending_exact += incr___2;
                                      }
                                    }
                                    goto while_16_break;
                                  }
                                  while_16_break: /* CIL Label */ ;
                                  }
                                }
                                while_15_break: /* CIL Label */ ;
                                }
#line 2608
                                if (keep_string_p) {
#line 2608
                                  tmp___17 = 16;
                                } else {
#line 2608
                                  tmp___17 = 15;
                                }
                                {

#line 2609
                                pending_exact = (unsigned char *)0;
#line 2610
                                b += 3;
                                }
#line 2612
                                if (! zero_times_ok) {
                                  {
#line 2619
                                  while (1) {
                                    while_17_continue: /* CIL Label */ ;
#line 2619
                                    if (! ((unsigned long )((b - bufp->buffer) + 3) > bufp->allocated)) {
                                      goto while_17_break;
                                    }
                                    {
#line 2619
                                    while (1) {
                                      while_18_continue: /* CIL Label */ ;
#line 2619
                                      old_buffer___3 = bufp->buffer;
#line 2619
                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                        goto __dyc_dummy_label;
                                      }
#line 2619
                                      bufp->allocated <<= 1;
#line 2619
                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 2619
                                        bufp->allocated = (unsigned long )(1L << 16);
                                      }
                                      {
#line 2619
                                      tmp___18 = __dyc_funcallvar_10;
#line 2619
                                      bufp->buffer = (unsigned char *)tmp___18;
                                      }
#line 2619
                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                        goto __dyc_dummy_label;
                                      }
#line 2619
                                      if ((unsigned long )old_buffer___3 != (unsigned long )bufp->buffer) {
#line 2619
                                        incr___3 = (ptrdiff_t )(bufp->buffer - old_buffer___3);
#line 2619
                                        b += incr___3;
#line 2619
                                        begalt += incr___3;
#line 2619
                                        if (fixup_alt_jump) {
#line 2619
                                          fixup_alt_jump += incr___3;
                                        }
#line 2619
                                        if (laststart) {
#line 2619
                                          laststart += incr___3;
                                        }
#line 2619
                                        if (pending_exact) {
#line 2619
                                          pending_exact += incr___3;
                                        }
                                      }
                                      goto while_18_break;
                                    }
                                    while_18_break: /* CIL Label */ ;
                                    }
                                  }
                                  while_17_break: /* CIL Label */ ;
                                  }
                                  {

#line 2622
                                  b += 3;
                                  }
                                }
                                goto switch_3_break;
                                switch_3_46: /* CIL Label */ 
#line 2629
                                laststart = b;
                                {
#line 2630
                                while (1) {
                                  while_19_continue: /* CIL Label */ ;
                                  {
#line 2630
                                  while (1) {
                                    while_20_continue: /* CIL Label */ ;
#line 2630
                                    if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                      goto while_20_break;
                                    }
                                    {
#line 2630
                                    while (1) {
                                      while_21_continue: /* CIL Label */ ;
#line 2630
                                      old_buffer___4 = bufp->buffer;
#line 2630
                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                        goto __dyc_dummy_label;
                                      }
#line 2630
                                      bufp->allocated <<= 1;
#line 2630
                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 2630
                                        bufp->allocated = (unsigned long )(1L << 16);
                                      }
                                      {
#line 2630
                                      tmp___19 = __dyc_funcallvar_11;
#line 2630
                                      bufp->buffer = (unsigned char *)tmp___19;
                                      }
#line 2630
                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                        goto __dyc_dummy_label;
                                      }
#line 2630
                                      if ((unsigned long )old_buffer___4 != (unsigned long )bufp->buffer) {
#line 2630
                                        incr___4 = (ptrdiff_t )(bufp->buffer - old_buffer___4);
#line 2630
                                        b += incr___4;
#line 2630
                                        begalt += incr___4;
#line 2630
                                        if (fixup_alt_jump) {
#line 2630
                                          fixup_alt_jump += incr___4;
                                        }
#line 2630
                                        if (laststart) {
#line 2630
                                          laststart += incr___4;
                                        }
#line 2630
                                        if (pending_exact) {
#line 2630
                                          pending_exact += incr___4;
                                        }
                                      }
                                      goto while_21_break;
                                    }
                                    while_21_break: /* CIL Label */ ;
                                    }
                                  }
                                  while_20_break: /* CIL Label */ ;
                                  }
#line 2630
                                  tmp___20 = b;
#line 2630
                                  b ++;
#line 2630
                                  *tmp___20 = (unsigned char)3;
                                  goto while_19_break;
                                }
                                while_19_break: /* CIL Label */ ;
                                }
                                goto switch_3_break;
                                switch_3_91: /* CIL Label */ 
#line 2636
                                had_char_class = (boolean )0;
#line 2640
                                range_start = 4294967295U;
#line 2642
                                if ((unsigned long )p == (unsigned long )pend) {
                                  {

                                  }
                                  goto __dyc_dummy_label;
                                }
                                {
#line 3109
                                while (1) {
                                  while_22_continue: /* CIL Label */ ;
#line 3109
                                  if (! ((unsigned long )((b - bufp->buffer) + 34) > bufp->allocated)) {
                                    goto while_22_break;
                                  }
                                  {
#line 3109
                                  while (1) {
                                    while_23_continue: /* CIL Label */ ;
#line 3109
                                    old_buffer___5 = bufp->buffer;
#line 3109
                                    if (bufp->allocated == (unsigned long )(1L << 16)) {
                                      goto __dyc_dummy_label;
                                    }
#line 3109
                                    bufp->allocated <<= 1;
#line 3109
                                    if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 3109
                                      bufp->allocated = (unsigned long )(1L << 16);
                                    }
                                    {
#line 3109
                                    tmp___21 = __dyc_funcallvar_12;
#line 3109
                                    bufp->buffer = (unsigned char *)tmp___21;
                                    }
#line 3109
                                    if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                      goto __dyc_dummy_label;
                                    }
#line 3109
                                    if ((unsigned long )old_buffer___5 != (unsigned long )bufp->buffer) {
#line 3109
                                      incr___5 = (ptrdiff_t )(bufp->buffer - old_buffer___5);
#line 3109
                                      b += incr___5;
#line 3109
                                      begalt += incr___5;
#line 3109
                                      if (fixup_alt_jump) {
#line 3109
                                        fixup_alt_jump += incr___5;
                                      }
#line 3109
                                      if (laststart) {
#line 3109
                                        laststart += incr___5;
                                      }
#line 3109
                                      if (pending_exact) {
#line 3109
                                        pending_exact += incr___5;
                                      }
                                    }
                                    goto while_23_break;
                                  }
                                  while_23_break: /* CIL Label */ ;
                                  }
                                }
                                while_22_break: /* CIL Label */ ;
                                }
#line 3111
                                laststart = b;
                                {
#line 3115
                                while (1) {
                                  while_24_continue: /* CIL Label */ ;
                                  {
#line 3115
                                  while (1) {
                                    while_25_continue: /* CIL Label */ ;
#line 3115
                                    if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                      goto while_25_break;
                                    }
                                    {
#line 3115
                                    while (1) {
                                      while_26_continue: /* CIL Label */ ;
#line 3115
                                      old_buffer___6 = bufp->buffer;
#line 3115
                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                        goto __dyc_dummy_label;
                                      }
#line 3115
                                      bufp->allocated <<= 1;
#line 3115
                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 3115
                                        bufp->allocated = (unsigned long )(1L << 16);
                                      }
                                      {
#line 3115
                                      tmp___22 = __dyc_funcallvar_13;
#line 3115
                                      bufp->buffer = (unsigned char *)tmp___22;
                                      }
#line 3115
                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                        goto __dyc_dummy_label;
                                      }
#line 3115
                                      if ((unsigned long )old_buffer___6 != (unsigned long )bufp->buffer) {
#line 3115
                                        incr___6 = (ptrdiff_t )(bufp->buffer - old_buffer___6);
#line 3115
                                        b += incr___6;
#line 3115
                                        begalt += incr___6;
#line 3115
                                        if (fixup_alt_jump) {
#line 3115
                                          fixup_alt_jump += incr___6;
                                        }
#line 3115
                                        if (laststart) {
#line 3115
                                          laststart += incr___6;
                                        }
#line 3115
                                        if (pending_exact) {
#line 3115
                                          pending_exact += incr___6;
                                        }
                                      }
                                      goto while_26_break;
                                    }
                                    while_26_break: /* CIL Label */ ;
                                    }
                                  }
                                  while_25_break: /* CIL Label */ ;
                                  }
#line 3115
                                  tmp___23 = b;
#line 3115
                                  b ++;
#line 3115
                                  if ((int const   )*p == 94) {
#line 3115
                                    tmp___24 = 5;
                                  } else {
#line 3115
                                    tmp___24 = 4;
                                  }
#line 3115
                                  *tmp___23 = (unsigned char )tmp___24;
                                  goto while_24_break;
                                }
                                while_24_break: /* CIL Label */ ;
                                }
#line 3116
                                if ((int const   )*p == 94) {
#line 3117
                                  p ++;
                                }
#line 3120
                                p1 = p;
                                {
#line 3123
                                while (1) {
                                  while_27_continue: /* CIL Label */ ;
                                  {
#line 3123
                                  while (1) {
                                    while_28_continue: /* CIL Label */ ;
#line 3123
                                    if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                      goto while_28_break;
                                    }
                                    {
#line 3123
                                    while (1) {
                                      while_29_continue: /* CIL Label */ ;
#line 3123
                                      old_buffer___7 = bufp->buffer;
#line 3123
                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                        goto __dyc_dummy_label;
                                      }
#line 3123
                                      bufp->allocated <<= 1;
#line 3123
                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 3123
                                        bufp->allocated = (unsigned long )(1L << 16);
                                      }
                                      {
#line 3123
                                      tmp___25 = __dyc_funcallvar_14;
#line 3123
                                      bufp->buffer = (unsigned char *)tmp___25;
                                      }
#line 3123
                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                        goto __dyc_dummy_label;
                                      }
#line 3123
                                      if ((unsigned long )old_buffer___7 != (unsigned long )bufp->buffer) {
#line 3123
                                        incr___7 = (ptrdiff_t )(bufp->buffer - old_buffer___7);
#line 3123
                                        b += incr___7;
#line 3123
                                        begalt += incr___7;
#line 3123
                                        if (fixup_alt_jump) {
#line 3123
                                          fixup_alt_jump += incr___7;
                                        }
#line 3123
                                        if (laststart) {
#line 3123
                                          laststart += incr___7;
                                        }
#line 3123
                                        if (pending_exact) {
#line 3123
                                          pending_exact += incr___7;
                                        }
                                      }
                                      goto while_29_break;
                                    }
                                    while_29_break: /* CIL Label */ ;
                                    }
                                  }
                                  while_28_break: /* CIL Label */ ;
                                  }
#line 3123
                                  tmp___26 = b;
#line 3123
                                  b ++;
#line 3123
                                  *tmp___26 = (unsigned char )((1 << 8) / 8);
                                  goto while_27_break;
                                }
                                while_27_break: /* CIL Label */ ;
                                }
                                {

                                }
#line 3129
                                if ((int )((enum __anonenum_re_opcode_t_24 )*(b + -2)) == 5) {
#line 3129
                                  if (syntax & ((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
#line 3131
                                    *(b + 1) = (unsigned char )((int )*(b + 1) | (1 << 2));
                                  }
                                }
                                {
#line 3134
                                while (1) {
                                  while_30_continue: /* CIL Label */ ;
#line 3136
                                  if ((unsigned long )p == (unsigned long )pend) {
                                    {

                                    }
                                    goto __dyc_dummy_label;
                                  }
                                  {
#line 3138
                                  while (1) {
                                    while_31_continue: /* CIL Label */ ;
#line 3138
                                    if ((unsigned long )p == (unsigned long )pend) {
                                      goto __dyc_dummy_label;
                                    }
#line 3138
                                    tmp___27 = p;
#line 3138
                                    p ++;
#line 3138
                                    c = (unsigned char )*tmp___27;
#line 3138
                                    if (translate) {
#line 3138
                                      c = (unsigned char )*(translate + c);
                                    }
                                    goto while_31_break;
                                  }
                                  while_31_break: /* CIL Label */ ;
                                  }
#line 3141
                                  if (syntax & 1UL) {
#line 3141
                                    if ((int )c == 92) {
#line 3143
                                      if ((unsigned long )p == (unsigned long )pend) {
                                        {

                                        }
                                        goto __dyc_dummy_label;
                                      }
                                      {
#line 3145
                                      while (1) {
                                        while_32_continue: /* CIL Label */ ;
#line 3145
                                        if ((unsigned long )p == (unsigned long )pend) {
                                          goto __dyc_dummy_label;
                                        }
#line 3145
                                        tmp___28 = p;
#line 3145
                                        p ++;
#line 3145
                                        c1 = (unsigned char )*tmp___28;
#line 3145
                                        if (translate) {
#line 3145
                                          c1 = (unsigned char )*(translate + c1);
                                        }
                                        goto while_32_break;
                                      }
                                      while_32_break: /* CIL Label */ ;
                                      }
#line 3146
                                      *(b + (int )c1 / 8) = (unsigned char )((int )*(b + (int )c1 / 8) | (1 << (int )c1 % 8));
#line 3147
                                      range_start = (unsigned int )c1;
                                      goto __Cont;
                                    }
                                  }
#line 3154
                                  if ((int )c == 93) {
#line 3154
                                    if ((unsigned long )p != (unsigned long )(p1 + 1)) {
                                      goto while_30_break;
                                    }
                                  }
#line 3159
                                  if (had_char_class) {
#line 3159
                                    if ((int )c == 45) {
#line 3159
                                      if ((int const   )*p != 93) {
                                        {

                                        }
                                        goto __dyc_dummy_label;
                                      }
                                    }
                                  }
#line 3166
                                  if ((int )c == 45) {
#line 3166
                                    if ((unsigned long )(p - 2) >= (unsigned long )pattern) {
#line 3166
                                      if ((int const   )*(p + -2) == 91) {
                                        goto _L___77;
                                      } else {
                                        goto _L___78;
                                      }
                                    } else {
                                      _L___78: /* CIL Label */ 
#line 3166
                                      if ((unsigned long )(p - 3) >= (unsigned long )pattern) {
#line 3166
                                        if ((int const   )*(p + -3) == 91) {
#line 3166
                                          if ((int const   )*(p + -2) == 94) {
                                            goto _L___77;
                                          } else {
                                            goto _L___76;
                                          }
                                        } else {
                                          goto _L___76;
                                        }
                                      } else {
                                        _L___76: /* CIL Label */ 
#line 3166
                                        if ((int const   )*p != 93) {
                                          {
#line 3171
                                          tmp___29 = __dyc_funcallvar_15;
#line 3171
                                          ret = tmp___29;
                                          }
#line 3174
                                          if ((int )ret != 0) {
                                            {

                                            }
                                            goto __dyc_dummy_label;
                                          }
#line 3175
                                          range_start = 4294967295U;
                                        } else {
                                          goto _L___77;
                                        }
                                      }
                                    }
                                  } else {
                                    _L___77: /* CIL Label */ 
#line 3178
                                    if ((int const   )*(p + 0) == 45) {
#line 3178
                                      if ((int const   )*(p + 1) != 93) {
                                        {
#line 3183
                                        while (1) {
                                          while_33_continue: /* CIL Label */ ;
#line 3183
                                          if ((unsigned long )p == (unsigned long )pend) {
                                            goto __dyc_dummy_label;
                                          }
#line 3183
                                          tmp___30 = p;
#line 3183
                                          p ++;
#line 3183
                                          c1 = (unsigned char )*tmp___30;
#line 3183
                                          if (translate) {
#line 3183
                                            c1 = (unsigned char )*(translate + c1);
                                          }
                                          goto while_33_break;
                                        }
                                        while_33_break: /* CIL Label */ ;
                                        }
                                        {
#line 3185
                                        ret___0 = __dyc_funcallvar_16;
                                        }
#line 3186
                                        if ((int )ret___0 != 0) {
                                          {

                                          }
                                          goto __dyc_dummy_label;
                                        }
#line 3187
                                        range_start = 4294967295U;
                                      } else {
                                        goto _L___72;
                                      }
                                    } else {
                                      _L___72: /* CIL Label */ 
#line 3193
                                      if (syntax & ((1UL << 1) << 1)) {
#line 3193
                                        if ((int )c == 91) {
#line 3193
                                          if ((int const   )*p == 58) {
                                            {
#line 3197
                                            while (1) {
                                              while_34_continue: /* CIL Label */ ;
#line 3197
                                              if ((unsigned long )p == (unsigned long )pend) {
                                                goto __dyc_dummy_label;
                                              }
#line 3197
                                              tmp___31 = p;
#line 3197
                                              p ++;
#line 3197
                                              c = (unsigned char )*tmp___31;
#line 3197
                                              if (translate) {
#line 3197
                                                c = (unsigned char )*(translate + c);
                                              }
                                              goto while_34_break;
                                            }
                                            while_34_break: /* CIL Label */ ;
                                            }
#line 3198
                                            c1 = (unsigned char)0;
#line 3201
                                            if ((unsigned long )p == (unsigned long )pend) {
                                              {

                                              }
                                              goto __dyc_dummy_label;
                                            }
                                            {
#line 3203
                                            while (1) {
                                              while_35_continue: /* CIL Label */ ;
                                              {
#line 3205
                                              while (1) {
                                                while_36_continue: /* CIL Label */ ;
#line 3205
                                                if ((unsigned long )p == (unsigned long )pend) {
                                                  goto __dyc_dummy_label;
                                                }
#line 3205
                                                tmp___32 = p;
#line 3205
                                                p ++;
#line 3205
                                                c = (unsigned char )*tmp___32;
#line 3205
                                                if (translate) {
#line 3205
                                                  c = (unsigned char )*(translate + c);
                                                }
                                                goto while_36_break;
                                              }
                                              while_36_break: /* CIL Label */ ;
                                              }
#line 3206
                                              if ((int )c == 58) {
#line 3206
                                                if ((int const   )*p == 93) {
                                                  goto while_35_break;
                                                } else {
                                                  goto _L___2;
                                                }
                                              } else {
                                                _L___2: /* CIL Label */ 
#line 3206
                                                if ((unsigned long )p == (unsigned long )pend) {
                                                  goto while_35_break;
                                                }
                                              }
#line 3208
                                              if ((int )c1 < 6) {
#line 3209
                                                tmp___33 = c1;
#line 3209
                                                c1 = (unsigned char )((int )c1 + 1);
#line 3209
                                                str[tmp___33] = (char )c;
                                              } else {
#line 3212
                                                str[0] = (char )'\000';
                                              }
                                            }
                                            while_35_break: /* CIL Label */ ;
                                            }
#line 3214
                                            str[c1] = (char )'\000';
#line 3219
                                            if ((int )c == 58) {
#line 3219
                                              if ((int const   )*p == 93) {
#line 3255
                                                if (0) {
                                                  {
#line 3255
                                                  tmp___49 = __dyc_funcallvar_17;
#line 3255
                                                  __s1_len = (unsigned long )tmp___49;
#line 3255
                                                  tmp___50 = __dyc_funcallvar_18;
#line 3255
                                                  __s2_len = (unsigned long )tmp___50;
                                                  }
#line 3255
                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                    goto _L___4;
                                                  } else {
#line 3255
                                                    if (__s1_len >= 4UL) {
                                                      _L___4: /* CIL Label */ 
#line 3255
                                                      if (! ((unsigned long )((void const   *)("alnum" + 1)) - (unsigned long )((void const   *)"alnum") == 1UL)) {
#line 3255
                                                        tmp___51 = 1;
                                                      } else {
#line 3255
                                                        if (__s2_len >= 4UL) {
#line 3255
                                                          tmp___51 = 1;
                                                        } else {
#line 3255
                                                          tmp___51 = 0;
                                                        }
                                                      }
                                                    } else {
#line 3255
                                                      tmp___51 = 0;
                                                    }
                                                  }
#line 3255
                                                  if (tmp___51) {
                                                    {
#line 3255
                                                    tmp___43 = __dyc_funcallvar_19;
                                                    }
                                                  } else {
                                                    {
#line 3255
                                                    tmp___48 = __dyc_funcallvar_20;
#line 3255
                                                    tmp___43 = tmp___48;
                                                    }
                                                  }
                                                } else {
                                                  {
#line 3255
                                                  tmp___48 = __dyc_funcallvar_21;
#line 3255
                                                  tmp___43 = tmp___48;
                                                  }
                                                }
#line 3255
                                                is_alnum = (boolean )(tmp___43 == 0);
#line 3256
                                                if (0) {
                                                  {
#line 3256
                                                  tmp___67 = __dyc_funcallvar_22;
#line 3256
                                                  __s1_len___0 = (unsigned long )tmp___67;
#line 3256
                                                  tmp___68 = __dyc_funcallvar_23;
#line 3256
                                                  __s2_len___0 = (unsigned long )tmp___68;
                                                  }
#line 3256
                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                    goto _L___6;
                                                  } else {
#line 3256
                                                    if (__s1_len___0 >= 4UL) {
                                                      _L___6: /* CIL Label */ 
#line 3256
                                                      if (! ((unsigned long )((void const   *)("alpha" + 1)) - (unsigned long )((void const   *)"alpha") == 1UL)) {
#line 3256
                                                        tmp___69 = 1;
                                                      } else {
#line 3256
                                                        if (__s2_len___0 >= 4UL) {
#line 3256
                                                          tmp___69 = 1;
                                                        } else {
#line 3256
                                                          tmp___69 = 0;
                                                        }
                                                      }
                                                    } else {
#line 3256
                                                      tmp___69 = 0;
                                                    }
                                                  }
#line 3256
                                                  if (tmp___69) {
                                                    {
#line 3256
                                                    tmp___61 = __dyc_funcallvar_24;
                                                    }
                                                  } else {
                                                    {
#line 3256
                                                    tmp___66 = __dyc_funcallvar_25;
#line 3256
                                                    tmp___61 = tmp___66;
                                                    }
                                                  }
                                                } else {
                                                  {
#line 3256
                                                  tmp___66 = __dyc_funcallvar_26;
#line 3256
                                                  tmp___61 = tmp___66;
                                                  }
                                                }
#line 3256
                                                is_alpha = (boolean )(tmp___61 == 0);
#line 3257
                                                if (0) {
                                                  {
#line 3257
                                                  tmp___85 = __dyc_funcallvar_27;
#line 3257
                                                  __s1_len___1 = (unsigned long )tmp___85;
#line 3257
                                                  tmp___86 = __dyc_funcallvar_28;
#line 3257
                                                  __s2_len___1 = (unsigned long )tmp___86;
                                                  }
#line 3257
                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                    goto _L___8;
                                                  } else {
#line 3257
                                                    if (__s1_len___1 >= 4UL) {
                                                      _L___8: /* CIL Label */ 
#line 3257
                                                      if (! ((unsigned long )((void const   *)("blank" + 1)) - (unsigned long )((void const   *)"blank") == 1UL)) {
#line 3257
                                                        tmp___87 = 1;
                                                      } else {
#line 3257
                                                        if (__s2_len___1 >= 4UL) {
#line 3257
                                                          tmp___87 = 1;
                                                        } else {
#line 3257
                                                          tmp___87 = 0;
                                                        }
                                                      }
                                                    } else {
#line 3257
                                                      tmp___87 = 0;
                                                    }
                                                  }
#line 3257
                                                  if (tmp___87) {
                                                    {
#line 3257
                                                    tmp___79 = __dyc_funcallvar_29;
                                                    }
                                                  } else {
                                                    {
#line 3257
                                                    tmp___84 = __dyc_funcallvar_30;
#line 3257
                                                    tmp___79 = tmp___84;
                                                    }
                                                  }
                                                } else {
                                                  {
#line 3257
                                                  tmp___84 = __dyc_funcallvar_31;
#line 3257
                                                  tmp___79 = tmp___84;
                                                  }
                                                }
#line 3257
                                                is_blank = (boolean )(tmp___79 == 0);
#line 3258
                                                if (0) {
                                                  {
#line 3258
                                                  tmp___103 = __dyc_funcallvar_32;
#line 3258
                                                  __s1_len___2 = (unsigned long )tmp___103;
#line 3258
                                                  tmp___104 = __dyc_funcallvar_33;
#line 3258
                                                  __s2_len___2 = (unsigned long )tmp___104;
                                                  }
#line 3258
                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                    goto _L___10;
                                                  } else {
#line 3258
                                                    if (__s1_len___2 >= 4UL) {
                                                      _L___10: /* CIL Label */ 
#line 3258
                                                      if (! ((unsigned long )((void const   *)("cntrl" + 1)) - (unsigned long )((void const   *)"cntrl") == 1UL)) {
#line 3258
                                                        tmp___105 = 1;
                                                      } else {
#line 3258
                                                        if (__s2_len___2 >= 4UL) {
#line 3258
                                                          tmp___105 = 1;
                                                        } else {
#line 3258
                                                          tmp___105 = 0;
                                                        }
                                                      }
                                                    } else {
#line 3258
                                                      tmp___105 = 0;
                                                    }
                                                  }
#line 3258
                                                  if (tmp___105) {
                                                    {
#line 3258
                                                    tmp___97 = __dyc_funcallvar_34;
                                                    }
                                                  } else {
                                                    {
#line 3258
                                                    tmp___102 = __dyc_funcallvar_35;
#line 3258
                                                    tmp___97 = tmp___102;
                                                    }
                                                  }
                                                } else {
                                                  {
#line 3258
                                                  tmp___102 = __dyc_funcallvar_36;
#line 3258
                                                  tmp___97 = tmp___102;
                                                  }
                                                }
#line 3258
                                                is_cntrl = (boolean )(tmp___97 == 0);
#line 3259
                                                if (0) {
                                                  {
#line 3259
                                                  tmp___121 = __dyc_funcallvar_37;
#line 3259
                                                  __s1_len___3 = (unsigned long )tmp___121;
#line 3259
                                                  tmp___122 = __dyc_funcallvar_38;
#line 3259
                                                  __s2_len___3 = (unsigned long )tmp___122;
                                                  }
#line 3259
                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                    goto _L___12;
                                                  } else {
#line 3259
                                                    if (__s1_len___3 >= 4UL) {
                                                      _L___12: /* CIL Label */ 
#line 3259
                                                      if (! ((unsigned long )((void const   *)("digit" + 1)) - (unsigned long )((void const   *)"digit") == 1UL)) {
#line 3259
                                                        tmp___123 = 1;
                                                      } else {
#line 3259
                                                        if (__s2_len___3 >= 4UL) {
#line 3259
                                                          tmp___123 = 1;
                                                        } else {
#line 3259
                                                          tmp___123 = 0;
                                                        }
                                                      }
                                                    } else {
#line 3259
                                                      tmp___123 = 0;
                                                    }
                                                  }
#line 3259
                                                  if (tmp___123) {
                                                    {
#line 3259
                                                    tmp___115 = __dyc_funcallvar_39;
                                                    }
                                                  } else {
                                                    {
#line 3259
                                                    tmp___120 = __dyc_funcallvar_40;
#line 3259
                                                    tmp___115 = tmp___120;
                                                    }
                                                  }
                                                } else {
                                                  {
#line 3259
                                                  tmp___120 = __dyc_funcallvar_41;
#line 3259
                                                  tmp___115 = tmp___120;
                                                  }
                                                }
#line 3259
                                                is_digit = (boolean )(tmp___115 == 0);
#line 3260
                                                if (0) {
                                                  {
#line 3260
                                                  tmp___139 = __dyc_funcallvar_42;
#line 3260
                                                  __s1_len___4 = (unsigned long )tmp___139;
#line 3260
                                                  tmp___140 = __dyc_funcallvar_43;
#line 3260
                                                  __s2_len___4 = (unsigned long )tmp___140;
                                                  }
#line 3260
                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                    goto _L___14;
                                                  } else {
#line 3260
                                                    if (__s1_len___4 >= 4UL) {
                                                      _L___14: /* CIL Label */ 
#line 3260
                                                      if (! ((unsigned long )((void const   *)("graph" + 1)) - (unsigned long )((void const   *)"graph") == 1UL)) {
#line 3260
                                                        tmp___141 = 1;
                                                      } else {
#line 3260
                                                        if (__s2_len___4 >= 4UL) {
#line 3260
                                                          tmp___141 = 1;
                                                        } else {
#line 3260
                                                          tmp___141 = 0;
                                                        }
                                                      }
                                                    } else {
#line 3260
                                                      tmp___141 = 0;
                                                    }
                                                  }
#line 3260
                                                  if (tmp___141) {
                                                    {
#line 3260
                                                    tmp___133 = __dyc_funcallvar_44;
                                                    }
                                                  } else {
                                                    {
#line 3260
                                                    tmp___138 = __dyc_funcallvar_45;
#line 3260
                                                    tmp___133 = tmp___138;
                                                    }
                                                  }
                                                } else {
                                                  {
#line 3260
                                                  tmp___138 = __dyc_funcallvar_46;
#line 3260
                                                  tmp___133 = tmp___138;
                                                  }
                                                }
#line 3260
                                                is_graph = (boolean )(tmp___133 == 0);
#line 3261
                                                if (0) {
                                                  {
#line 3261
                                                  tmp___157 = __dyc_funcallvar_47;
#line 3261
                                                  __s1_len___5 = (unsigned long )tmp___157;
#line 3261
                                                  tmp___158 = __dyc_funcallvar_48;
#line 3261
                                                  __s2_len___5 = (unsigned long )tmp___158;
                                                  }
#line 3261
                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                    goto _L___16;
                                                  } else {
#line 3261
                                                    if (__s1_len___5 >= 4UL) {
                                                      _L___16: /* CIL Label */ 
#line 3261
                                                      if (! ((unsigned long )((void const   *)("lower" + 1)) - (unsigned long )((void const   *)"lower") == 1UL)) {
#line 3261
                                                        tmp___159 = 1;
                                                      } else {
#line 3261
                                                        if (__s2_len___5 >= 4UL) {
#line 3261
                                                          tmp___159 = 1;
                                                        } else {
#line 3261
                                                          tmp___159 = 0;
                                                        }
                                                      }
                                                    } else {
#line 3261
                                                      tmp___159 = 0;
                                                    }
                                                  }
#line 3261
                                                  if (tmp___159) {
                                                    {
#line 3261
                                                    tmp___151 = __dyc_funcallvar_49;
                                                    }
                                                  } else {
                                                    {
#line 3261
                                                    tmp___156 = __dyc_funcallvar_50;
#line 3261
                                                    tmp___151 = tmp___156;
                                                    }
                                                  }
                                                } else {
                                                  {
#line 3261
                                                  tmp___156 = __dyc_funcallvar_51;
#line 3261
                                                  tmp___151 = tmp___156;
                                                  }
                                                }
#line 3261
                                                is_lower = (boolean )(tmp___151 == 0);
#line 3262
                                                if (0) {
                                                  {
#line 3262
                                                  tmp___175 = __dyc_funcallvar_52;
#line 3262
                                                  __s1_len___6 = (unsigned long )tmp___175;
#line 3262
                                                  tmp___176 = __dyc_funcallvar_53;
#line 3262
                                                  __s2_len___6 = (unsigned long )tmp___176;
                                                  }
#line 3262
                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                    goto _L___18;
                                                  } else {
#line 3262
                                                    if (__s1_len___6 >= 4UL) {
                                                      _L___18: /* CIL Label */ 
#line 3262
                                                      if (! ((unsigned long )((void const   *)("print" + 1)) - (unsigned long )((void const   *)"print") == 1UL)) {
#line 3262
                                                        tmp___177 = 1;
                                                      } else {
#line 3262
                                                        if (__s2_len___6 >= 4UL) {
#line 3262
                                                          tmp___177 = 1;
                                                        } else {
#line 3262
                                                          tmp___177 = 0;
                                                        }
                                                      }
                                                    } else {
#line 3262
                                                      tmp___177 = 0;
                                                    }
                                                  }
#line 3262
                                                  if (tmp___177) {
                                                    {
#line 3262
                                                    tmp___169 = __dyc_funcallvar_54;
                                                    }
                                                  } else {
                                                    {
#line 3262
                                                    tmp___174 = __dyc_funcallvar_55;
#line 3262
                                                    tmp___169 = tmp___174;
                                                    }
                                                  }
                                                } else {
                                                  {
#line 3262
                                                  tmp___174 = __dyc_funcallvar_56;
#line 3262
                                                  tmp___169 = tmp___174;
                                                  }
                                                }
#line 3262
                                                is_print = (boolean )(tmp___169 == 0);
#line 3263
                                                if (0) {
                                                  {
#line 3263
                                                  tmp___193 = __dyc_funcallvar_57;
#line 3263
                                                  __s1_len___7 = (unsigned long )tmp___193;
#line 3263
                                                  tmp___194 = __dyc_funcallvar_58;
#line 3263
                                                  __s2_len___7 = (unsigned long )tmp___194;
                                                  }
#line 3263
                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                    goto _L___20;
                                                  } else {
#line 3263
                                                    if (__s1_len___7 >= 4UL) {
                                                      _L___20: /* CIL Label */ 
#line 3263
                                                      if (! ((unsigned long )((void const   *)("punct" + 1)) - (unsigned long )((void const   *)"punct") == 1UL)) {
#line 3263
                                                        tmp___195 = 1;
                                                      } else {
#line 3263
                                                        if (__s2_len___7 >= 4UL) {
#line 3263
                                                          tmp___195 = 1;
                                                        } else {
#line 3263
                                                          tmp___195 = 0;
                                                        }
                                                      }
                                                    } else {
#line 3263
                                                      tmp___195 = 0;
                                                    }
                                                  }
#line 3263
                                                  if (tmp___195) {
                                                    {
#line 3263
                                                    tmp___187 = __dyc_funcallvar_59;
                                                    }
                                                  } else {
                                                    {
#line 3263
                                                    tmp___192 = __dyc_funcallvar_60;
#line 3263
                                                    tmp___187 = tmp___192;
                                                    }
                                                  }
                                                } else {
                                                  {
#line 3263
                                                  tmp___192 = __dyc_funcallvar_61;
#line 3263
                                                  tmp___187 = tmp___192;
                                                  }
                                                }
#line 3263
                                                is_punct = (boolean )(tmp___187 == 0);
#line 3264
                                                if (0) {
                                                  {
#line 3264
                                                  tmp___211 = __dyc_funcallvar_62;
#line 3264
                                                  __s1_len___8 = (unsigned long )tmp___211;
#line 3264
                                                  tmp___212 = __dyc_funcallvar_63;
#line 3264
                                                  __s2_len___8 = (unsigned long )tmp___212;
                                                  }
#line 3264
                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                    goto _L___22;
                                                  } else {
#line 3264
                                                    if (__s1_len___8 >= 4UL) {
                                                      _L___22: /* CIL Label */ 
#line 3264
                                                      if (! ((unsigned long )((void const   *)("space" + 1)) - (unsigned long )((void const   *)"space") == 1UL)) {
#line 3264
                                                        tmp___213 = 1;
                                                      } else {
#line 3264
                                                        if (__s2_len___8 >= 4UL) {
#line 3264
                                                          tmp___213 = 1;
                                                        } else {
#line 3264
                                                          tmp___213 = 0;
                                                        }
                                                      }
                                                    } else {
#line 3264
                                                      tmp___213 = 0;
                                                    }
                                                  }
#line 3264
                                                  if (tmp___213) {
                                                    {
#line 3264
                                                    tmp___205 = __dyc_funcallvar_64;
                                                    }
                                                  } else {
                                                    {
#line 3264
                                                    tmp___210 = __dyc_funcallvar_65;
#line 3264
                                                    tmp___205 = tmp___210;
                                                    }
                                                  }
                                                } else {
                                                  {
#line 3264
                                                  tmp___210 = __dyc_funcallvar_66;
#line 3264
                                                  tmp___205 = tmp___210;
                                                  }
                                                }
#line 3264
                                                is_space = (boolean )(tmp___205 == 0);
#line 3265
                                                if (0) {
                                                  {
#line 3265
                                                  tmp___229 = __dyc_funcallvar_67;
#line 3265
                                                  __s1_len___9 = (unsigned long )tmp___229;
#line 3265
                                                  tmp___230 = __dyc_funcallvar_68;
#line 3265
                                                  __s2_len___9 = (unsigned long )tmp___230;
                                                  }
#line 3265
                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                    goto _L___24;
                                                  } else {
#line 3265
                                                    if (__s1_len___9 >= 4UL) {
                                                      _L___24: /* CIL Label */ 
#line 3265
                                                      if (! ((unsigned long )((void const   *)("upper" + 1)) - (unsigned long )((void const   *)"upper") == 1UL)) {
#line 3265
                                                        tmp___231 = 1;
                                                      } else {
#line 3265
                                                        if (__s2_len___9 >= 4UL) {
#line 3265
                                                          tmp___231 = 1;
                                                        } else {
#line 3265
                                                          tmp___231 = 0;
                                                        }
                                                      }
                                                    } else {
#line 3265
                                                      tmp___231 = 0;
                                                    }
                                                  }
#line 3265
                                                  if (tmp___231) {
                                                    {
#line 3265
                                                    tmp___223 = __dyc_funcallvar_69;
                                                    }
                                                  } else {
                                                    {
#line 3265
                                                    tmp___228 = __dyc_funcallvar_70;
#line 3265
                                                    tmp___223 = tmp___228;
                                                    }
                                                  }
                                                } else {
                                                  {
#line 3265
                                                  tmp___228 = __dyc_funcallvar_71;
#line 3265
                                                  tmp___223 = tmp___228;
                                                  }
                                                }
#line 3265
                                                is_upper = (boolean )(tmp___223 == 0);
#line 3266
                                                if (0) {
                                                  {
#line 3266
                                                  tmp___247 = __dyc_funcallvar_72;
#line 3266
                                                  __s1_len___10 = (unsigned long )tmp___247;
#line 3266
                                                  tmp___248 = __dyc_funcallvar_73;
#line 3266
                                                  __s2_len___10 = (unsigned long )tmp___248;
                                                  }
#line 3266
                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                    goto _L___26;
                                                  } else {
#line 3266
                                                    if (__s1_len___10 >= 4UL) {
                                                      _L___26: /* CIL Label */ 
#line 3266
                                                      if (! ((unsigned long )((void const   *)("xdigit" + 1)) - (unsigned long )((void const   *)"xdigit") == 1UL)) {
#line 3266
                                                        tmp___249 = 1;
                                                      } else {
#line 3266
                                                        if (__s2_len___10 >= 4UL) {
#line 3266
                                                          tmp___249 = 1;
                                                        } else {
#line 3266
                                                          tmp___249 = 0;
                                                        }
                                                      }
                                                    } else {
#line 3266
                                                      tmp___249 = 0;
                                                    }
                                                  }
#line 3266
                                                  if (tmp___249) {
                                                    {
#line 3266
                                                    tmp___241 = __dyc_funcallvar_74;
                                                    }
                                                  } else {
                                                    {
#line 3266
                                                    tmp___246 = __dyc_funcallvar_75;
#line 3266
                                                    tmp___241 = tmp___246;
                                                    }
                                                  }
                                                } else {
                                                  {
#line 3266
                                                  tmp___246 = __dyc_funcallvar_76;
#line 3266
                                                  tmp___241 = tmp___246;
                                                  }
                                                }
#line 3266
                                                is_xdigit = (boolean )(tmp___241 == 0);
#line 3268
                                                if (0) {
                                                  {
#line 3268
                                                  tmp___265 = __dyc_funcallvar_77;
#line 3268
                                                  __s1_len___11 = (unsigned long )tmp___265;
#line 3268
                                                  tmp___266 = __dyc_funcallvar_78;
#line 3268
                                                  __s2_len___11 = (unsigned long )tmp___266;
                                                  }
#line 3268
                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                    goto _L___28;
                                                  } else {
#line 3268
                                                    if (__s1_len___11 >= 4UL) {
                                                      _L___28: /* CIL Label */ 
#line 3268
                                                      if (! ((unsigned long )((void const   *)("alpha" + 1)) - (unsigned long )((void const   *)"alpha") == 1UL)) {
#line 3268
                                                        tmp___267 = 1;
                                                      } else {
#line 3268
                                                        if (__s2_len___11 >= 4UL) {
#line 3268
                                                          tmp___267 = 1;
                                                        } else {
#line 3268
                                                          tmp___267 = 0;
                                                        }
                                                      }
                                                    } else {
#line 3268
                                                      tmp___267 = 0;
                                                    }
                                                  }
#line 3268
                                                  if (tmp___267) {
                                                    {
#line 3268
                                                    tmp___259 = __dyc_funcallvar_79;
                                                    }
                                                  } else {
                                                    {
#line 3268
                                                    tmp___264 = __dyc_funcallvar_80;
#line 3268
                                                    tmp___259 = tmp___264;
                                                    }
                                                  }
                                                } else {
                                                  {
#line 3268
                                                  tmp___264 = __dyc_funcallvar_81;
#line 3268
                                                  tmp___259 = tmp___264;
                                                  }
                                                }
#line 3268
                                                if (! (tmp___259 == 0)) {
#line 3268
                                                  if (0) {
                                                    {
#line 3268
                                                    tmp___283 = __dyc_funcallvar_82;
#line 3268
                                                    __s1_len___12 = (unsigned long )tmp___283;
#line 3268
                                                    tmp___284 = __dyc_funcallvar_83;
#line 3268
                                                    __s2_len___12 = (unsigned long )tmp___284;
                                                    }
#line 3268
                                                    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                      goto _L___30;
                                                    } else {
#line 3268
                                                      if (__s1_len___12 >= 4UL) {
                                                        _L___30: /* CIL Label */ 
#line 3268
                                                        if (! ((unsigned long )((void const   *)("upper" + 1)) - (unsigned long )((void const   *)"upper") == 1UL)) {
#line 3268
                                                          tmp___285 = 1;
                                                        } else {
#line 3268
                                                          if (__s2_len___12 >= 4UL) {
#line 3268
                                                            tmp___285 = 1;
                                                          } else {
#line 3268
                                                            tmp___285 = 0;
                                                          }
                                                        }
                                                      } else {
#line 3268
                                                        tmp___285 = 0;
                                                      }
                                                    }
#line 3268
                                                    if (tmp___285) {
                                                      {
#line 3268
                                                      tmp___277 = __dyc_funcallvar_84;
                                                      }
                                                    } else {
                                                      {
#line 3268
                                                      tmp___282 = __dyc_funcallvar_85;
#line 3268
                                                      tmp___277 = tmp___282;
                                                      }
                                                    }
                                                  } else {
                                                    {
#line 3268
                                                    tmp___282 = __dyc_funcallvar_86;
#line 3268
                                                    tmp___277 = tmp___282;
                                                    }
                                                  }
#line 3268
                                                  if (! (tmp___277 == 0)) {
#line 3268
                                                    if (0) {
                                                      {
#line 3268
                                                      tmp___301 = __dyc_funcallvar_87;
#line 3268
                                                      __s1_len___13 = (unsigned long )tmp___301;
#line 3268
                                                      tmp___302 = __dyc_funcallvar_88;
#line 3268
                                                      __s2_len___13 = (unsigned long )tmp___302;
                                                      }
#line 3268
                                                      if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                        goto _L___32;
                                                      } else {
#line 3268
                                                        if (__s1_len___13 >= 4UL) {
                                                          _L___32: /* CIL Label */ 
#line 3268
                                                          if (! ((unsigned long )((void const   *)("lower" + 1)) - (unsigned long )((void const   *)"lower") == 1UL)) {
#line 3268
                                                            tmp___303 = 1;
                                                          } else {
#line 3268
                                                            if (__s2_len___13 >= 4UL) {
#line 3268
                                                              tmp___303 = 1;
                                                            } else {
#line 3268
                                                              tmp___303 = 0;
                                                            }
                                                          }
                                                        } else {
#line 3268
                                                          tmp___303 = 0;
                                                        }
                                                      }
#line 3268
                                                      if (tmp___303) {
                                                        {
#line 3268
                                                        tmp___295 = __dyc_funcallvar_89;
                                                        }
                                                      } else {
                                                        {
#line 3268
                                                        tmp___300 = __dyc_funcallvar_90;
#line 3268
                                                        tmp___295 = tmp___300;
                                                        }
                                                      }
                                                    } else {
                                                      {
#line 3268
                                                      tmp___300 = __dyc_funcallvar_91;
#line 3268
                                                      tmp___295 = tmp___300;
                                                      }
                                                    }
#line 3268
                                                    if (! (tmp___295 == 0)) {
#line 3268
                                                      if (0) {
                                                        {
#line 3268
                                                        tmp___319 = __dyc_funcallvar_92;
#line 3268
                                                        __s1_len___14 = (unsigned long )tmp___319;
#line 3268
                                                        tmp___320 = __dyc_funcallvar_93;
#line 3268
                                                        __s2_len___14 = (unsigned long )tmp___320;
                                                        }
#line 3268
                                                        if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                          goto _L___34;
                                                        } else {
#line 3268
                                                          if (__s1_len___14 >= 4UL) {
                                                            _L___34: /* CIL Label */ 
#line 3268
                                                            if (! ((unsigned long )((void const   *)("digit" + 1)) - (unsigned long )((void const   *)"digit") == 1UL)) {
#line 3268
                                                              tmp___321 = 1;
                                                            } else {
#line 3268
                                                              if (__s2_len___14 >= 4UL) {
#line 3268
                                                                tmp___321 = 1;
                                                              } else {
#line 3268
                                                                tmp___321 = 0;
                                                              }
                                                            }
                                                          } else {
#line 3268
                                                            tmp___321 = 0;
                                                          }
                                                        }
#line 3268
                                                        if (tmp___321) {
                                                          {
#line 3268
                                                          tmp___313 = __dyc_funcallvar_94;
                                                          }
                                                        } else {
                                                          {
#line 3268
                                                          tmp___318 = __dyc_funcallvar_95;
#line 3268
                                                          tmp___313 = tmp___318;
                                                          }
                                                        }
                                                      } else {
                                                        {
#line 3268
                                                        tmp___318 = __dyc_funcallvar_96;
#line 3268
                                                        tmp___313 = tmp___318;
                                                        }
                                                      }
#line 3268
                                                      if (! (tmp___313 == 0)) {
#line 3268
                                                        if (0) {
                                                          {
#line 3268
                                                          tmp___337 = __dyc_funcallvar_97;
#line 3268
                                                          __s1_len___15 = (unsigned long )tmp___337;
#line 3268
                                                          tmp___338 = __dyc_funcallvar_98;
#line 3268
                                                          __s2_len___15 = (unsigned long )tmp___338;
                                                          }
#line 3268
                                                          if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                            goto _L___36;
                                                          } else {
#line 3268
                                                            if (__s1_len___15 >= 4UL) {
                                                              _L___36: /* CIL Label */ 
#line 3268
                                                              if (! ((unsigned long )((void const   *)("alnum" + 1)) - (unsigned long )((void const   *)"alnum") == 1UL)) {
#line 3268
                                                                tmp___339 = 1;
                                                              } else {
#line 3268
                                                                if (__s2_len___15 >= 4UL) {
#line 3268
                                                                  tmp___339 = 1;
                                                                } else {
#line 3268
                                                                  tmp___339 = 0;
                                                                }
                                                              }
                                                            } else {
#line 3268
                                                              tmp___339 = 0;
                                                            }
                                                          }
#line 3268
                                                          if (tmp___339) {
                                                            {
#line 3268
                                                            tmp___331 = __dyc_funcallvar_99;
                                                            }
                                                          } else {
                                                            {
#line 3268
                                                            tmp___336 = __dyc_funcallvar_100;
#line 3268
                                                            tmp___331 = tmp___336;
                                                            }
                                                          }
                                                        } else {
                                                          {
#line 3268
                                                          tmp___336 = __dyc_funcallvar_101;
#line 3268
                                                          tmp___331 = tmp___336;
                                                          }
                                                        }
#line 3268
                                                        if (! (tmp___331 == 0)) {
#line 3268
                                                          if (0) {
                                                            {
#line 3268
                                                            tmp___355 = __dyc_funcallvar_102;
#line 3268
                                                            __s1_len___16 = (unsigned long )tmp___355;
#line 3268
                                                            tmp___356 = __dyc_funcallvar_103;
#line 3268
                                                            __s2_len___16 = (unsigned long )tmp___356;
                                                            }
#line 3268
                                                            if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                              goto _L___38;
                                                            } else {
#line 3268
                                                              if (__s1_len___16 >= 4UL) {
                                                                _L___38: /* CIL Label */ 
#line 3268
                                                                if (! ((unsigned long )((void const   *)("xdigit" + 1)) - (unsigned long )((void const   *)"xdigit") == 1UL)) {
#line 3268
                                                                  tmp___357 = 1;
                                                                } else {
#line 3268
                                                                  if (__s2_len___16 >= 4UL) {
#line 3268
                                                                    tmp___357 = 1;
                                                                  } else {
#line 3268
                                                                    tmp___357 = 0;
                                                                  }
                                                                }
                                                              } else {
#line 3268
                                                                tmp___357 = 0;
                                                              }
                                                            }
#line 3268
                                                            if (tmp___357) {
                                                              {
#line 3268
                                                              tmp___349 = __dyc_funcallvar_104;
                                                              }
                                                            } else {
                                                              {
#line 3268
                                                              tmp___354 = __dyc_funcallvar_105;
#line 3268
                                                              tmp___349 = tmp___354;
                                                              }
                                                            }
                                                          } else {
                                                            {
#line 3268
                                                            tmp___354 = __dyc_funcallvar_106;
#line 3268
                                                            tmp___349 = tmp___354;
                                                            }
                                                          }
#line 3268
                                                          if (! (tmp___349 == 0)) {
#line 3268
                                                            if (0) {
                                                              {
#line 3268
                                                              tmp___373 = __dyc_funcallvar_107;
#line 3268
                                                              __s1_len___17 = (unsigned long )tmp___373;
#line 3268
                                                              tmp___374 = __dyc_funcallvar_108;
#line 3268
                                                              __s2_len___17 = (unsigned long )tmp___374;
                                                              }
#line 3268
                                                              if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                                goto _L___40;
                                                              } else {
#line 3268
                                                                if (__s1_len___17 >= 4UL) {
                                                                  _L___40: /* CIL Label */ 
#line 3268
                                                                  if (! ((unsigned long )((void const   *)("space" + 1)) - (unsigned long )((void const   *)"space") == 1UL)) {
#line 3268
                                                                    tmp___375 = 1;
                                                                  } else {
#line 3268
                                                                    if (__s2_len___17 >= 4UL) {
#line 3268
                                                                      tmp___375 = 1;
                                                                    } else {
#line 3268
                                                                      tmp___375 = 0;
                                                                    }
                                                                  }
                                                                } else {
#line 3268
                                                                  tmp___375 = 0;
                                                                }
                                                              }
#line 3268
                                                              if (tmp___375) {
                                                                {
#line 3268
                                                                tmp___367 = __dyc_funcallvar_109;
                                                                }
                                                              } else {
                                                                {
#line 3268
                                                                tmp___372 = __dyc_funcallvar_110;
#line 3268
                                                                tmp___367 = tmp___372;
                                                                }
                                                              }
                                                            } else {
                                                              {
#line 3268
                                                              tmp___372 = __dyc_funcallvar_111;
#line 3268
                                                              tmp___367 = tmp___372;
                                                              }
                                                            }
#line 3268
                                                            if (! (tmp___367 == 0)) {
#line 3268
                                                              if (0) {
                                                                {
#line 3268
                                                                tmp___391 = __dyc_funcallvar_112;
#line 3268
                                                                __s1_len___18 = (unsigned long )tmp___391;
#line 3268
                                                                tmp___392 = __dyc_funcallvar_113;
#line 3268
                                                                __s2_len___18 = (unsigned long )tmp___392;
                                                                }
#line 3268
                                                                if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                                  goto _L___42;
                                                                } else {
#line 3268
                                                                  if (__s1_len___18 >= 4UL) {
                                                                    _L___42: /* CIL Label */ 
#line 3268
                                                                    if (! ((unsigned long )((void const   *)("print" + 1)) - (unsigned long )((void const   *)"print") == 1UL)) {
#line 3268
                                                                      tmp___393 = 1;
                                                                    } else {
#line 3268
                                                                      if (__s2_len___18 >= 4UL) {
#line 3268
                                                                        tmp___393 = 1;
                                                                      } else {
#line 3268
                                                                        tmp___393 = 0;
                                                                      }
                                                                    }
                                                                  } else {
#line 3268
                                                                    tmp___393 = 0;
                                                                  }
                                                                }
#line 3268
                                                                if (tmp___393) {
                                                                  {
#line 3268
                                                                  tmp___385 = __dyc_funcallvar_114;
                                                                  }
                                                                } else {
                                                                  {
#line 3268
                                                                  tmp___390 = __dyc_funcallvar_115;
#line 3268
                                                                  tmp___385 = tmp___390;
                                                                  }
                                                                }
                                                              } else {
                                                                {
#line 3268
                                                                tmp___390 = __dyc_funcallvar_116;
#line 3268
                                                                tmp___385 = tmp___390;
                                                                }
                                                              }
#line 3268
                                                              if (! (tmp___385 == 0)) {
#line 3268
                                                                if (0) {
                                                                  {
#line 3268
                                                                  tmp___409 = __dyc_funcallvar_117;
#line 3268
                                                                  __s1_len___19 = (unsigned long )tmp___409;
#line 3268
                                                                  tmp___410 = __dyc_funcallvar_118;
#line 3268
                                                                  __s2_len___19 = (unsigned long )tmp___410;
                                                                  }
#line 3268
                                                                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                                    goto _L___44;
                                                                  } else {
#line 3268
                                                                    if (__s1_len___19 >= 4UL) {
                                                                      _L___44: /* CIL Label */ 
#line 3268
                                                                      if (! ((unsigned long )((void const   *)("punct" + 1)) - (unsigned long )((void const   *)"punct") == 1UL)) {
#line 3268
                                                                        tmp___411 = 1;
                                                                      } else {
#line 3268
                                                                        if (__s2_len___19 >= 4UL) {
#line 3268
                                                                          tmp___411 = 1;
                                                                        } else {
#line 3268
                                                                          tmp___411 = 0;
                                                                        }
                                                                      }
                                                                    } else {
#line 3268
                                                                      tmp___411 = 0;
                                                                    }
                                                                  }
#line 3268
                                                                  if (tmp___411) {
                                                                    {
#line 3268
                                                                    tmp___403 = __dyc_funcallvar_119;
                                                                    }
                                                                  } else {
                                                                    {
#line 3268
                                                                    tmp___408 = __dyc_funcallvar_120;
#line 3268
                                                                    tmp___403 = tmp___408;
                                                                    }
                                                                  }
                                                                } else {
                                                                  {
#line 3268
                                                                  tmp___408 = __dyc_funcallvar_121;
#line 3268
                                                                  tmp___403 = tmp___408;
                                                                  }
                                                                }
#line 3268
                                                                if (! (tmp___403 == 0)) {
#line 3268
                                                                  if (0) {
                                                                    {
#line 3268
                                                                    tmp___427 = __dyc_funcallvar_122;
#line 3268
                                                                    __s1_len___20 = (unsigned long )tmp___427;
#line 3268
                                                                    tmp___428 = __dyc_funcallvar_123;
#line 3268
                                                                    __s2_len___20 = (unsigned long )tmp___428;
                                                                    }
#line 3268
                                                                    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                                      goto _L___46;
                                                                    } else {
#line 3268
                                                                      if (__s1_len___20 >= 4UL) {
                                                                        _L___46: /* CIL Label */ 
#line 3268
                                                                        if (! ((unsigned long )((void const   *)("graph" + 1)) - (unsigned long )((void const   *)"graph") == 1UL)) {
#line 3268
                                                                          tmp___429 = 1;
                                                                        } else {
#line 3268
                                                                          if (__s2_len___20 >= 4UL) {
#line 3268
                                                                            tmp___429 = 1;
                                                                          } else {
#line 3268
                                                                            tmp___429 = 0;
                                                                          }
                                                                        }
                                                                      } else {
#line 3268
                                                                        tmp___429 = 0;
                                                                      }
                                                                    }
#line 3268
                                                                    if (tmp___429) {
                                                                      {
#line 3268
                                                                      tmp___421 = __dyc_funcallvar_124;
                                                                      }
                                                                    } else {
                                                                      {
#line 3268
                                                                      tmp___426 = __dyc_funcallvar_125;
#line 3268
                                                                      tmp___421 = tmp___426;
                                                                      }
                                                                    }
                                                                  } else {
                                                                    {
#line 3268
                                                                    tmp___426 = __dyc_funcallvar_126;
#line 3268
                                                                    tmp___421 = tmp___426;
                                                                    }
                                                                  }
#line 3268
                                                                  if (! (tmp___421 == 0)) {
#line 3268
                                                                    if (0) {
                                                                      {
#line 3268
                                                                      tmp___445 = __dyc_funcallvar_127;
#line 3268
                                                                      __s1_len___21 = (unsigned long )tmp___445;
#line 3268
                                                                      tmp___446 = __dyc_funcallvar_128;
#line 3268
                                                                      __s2_len___21 = (unsigned long )tmp___446;
                                                                      }
#line 3268
                                                                      if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                                        goto _L___48;
                                                                      } else {
#line 3268
                                                                        if (__s1_len___21 >= 4UL) {
                                                                          _L___48: /* CIL Label */ 
#line 3268
                                                                          if (! ((unsigned long )((void const   *)("cntrl" + 1)) - (unsigned long )((void const   *)"cntrl") == 1UL)) {
#line 3268
                                                                            tmp___447 = 1;
                                                                          } else {
#line 3268
                                                                            if (__s2_len___21 >= 4UL) {
#line 3268
                                                                              tmp___447 = 1;
                                                                            } else {
#line 3268
                                                                              tmp___447 = 0;
                                                                            }
                                                                          }
                                                                        } else {
#line 3268
                                                                          tmp___447 = 0;
                                                                        }
                                                                      }
#line 3268
                                                                      if (tmp___447) {
                                                                        {
#line 3268
                                                                        tmp___439 = __dyc_funcallvar_129;
                                                                        }
                                                                      } else {
                                                                        {
#line 3268
                                                                        tmp___444 = __dyc_funcallvar_130;
#line 3268
                                                                        tmp___439 = tmp___444;
                                                                        }
                                                                      }
                                                                    } else {
                                                                      {
#line 3268
                                                                      tmp___444 = __dyc_funcallvar_131;
#line 3268
                                                                      tmp___439 = tmp___444;
                                                                      }
                                                                    }
#line 3268
                                                                    if (! (tmp___439 == 0)) {
#line 3268
                                                                      if (0) {
                                                                        {
#line 3268
                                                                        tmp___463 = __dyc_funcallvar_132;
#line 3268
                                                                        __s1_len___22 = (unsigned long )tmp___463;
#line 3268
                                                                        tmp___464 = __dyc_funcallvar_133;
#line 3268
                                                                        __s2_len___22 = (unsigned long )tmp___464;
                                                                        }
#line 3268
                                                                        if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                                                                          goto _L___50;
                                                                        } else {
#line 3268
                                                                          if (__s1_len___22 >= 4UL) {
                                                                            _L___50: /* CIL Label */ 
#line 3268
                                                                            if (! ((unsigned long )((void const   *)("blank" + 1)) - (unsigned long )((void const   *)"blank") == 1UL)) {
#line 3268
                                                                              tmp___465 = 1;
                                                                            } else {
#line 3268
                                                                              if (__s2_len___22 >= 4UL) {
#line 3268
                                                                                tmp___465 = 1;
                                                                              } else {
#line 3268
                                                                                tmp___465 = 0;
                                                                              }
                                                                            }
                                                                          } else {
#line 3268
                                                                            tmp___465 = 0;
                                                                          }
                                                                        }
#line 3268
                                                                        if (tmp___465) {
                                                                          {
#line 3268
                                                                          tmp___457 = __dyc_funcallvar_134;
                                                                          }
                                                                        } else {
                                                                          {
#line 3268
                                                                          tmp___462 = __dyc_funcallvar_135;
#line 3268
                                                                          tmp___457 = tmp___462;
                                                                          }
                                                                        }
                                                                      } else {
                                                                        {
#line 3268
                                                                        tmp___462 = __dyc_funcallvar_136;
#line 3268
                                                                        tmp___457 = tmp___462;
                                                                        }
                                                                      }
#line 3268
                                                                      if (! (tmp___457 == 0)) {
                                                                        {

                                                                        }
                                                                        goto __dyc_dummy_label;
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                                {
#line 3273
                                                while (1) {
                                                  while_37_continue: /* CIL Label */ ;
#line 3273
                                                  if ((unsigned long )p == (unsigned long )pend) {
                                                    goto __dyc_dummy_label;
                                                  }
#line 3273
                                                  tmp___466 = p;
#line 3273
                                                  p ++;
#line 3273
                                                  c = (unsigned char )*tmp___466;
#line 3273
                                                  if (translate) {
#line 3273
                                                    c = (unsigned char )*(translate + c);
                                                  }
                                                  goto while_37_break;
                                                }
                                                while_37_break: /* CIL Label */ ;
                                                }
#line 3275
                                                if ((unsigned long )p == (unsigned long )pend) {
                                                  {

                                                  }
                                                  goto __dyc_dummy_label;
                                                }
#line 3277
                                                ch = 0;
                                                {
#line 3277
                                                while (1) {
                                                  while_38_continue: /* CIL Label */ ;
#line 3277
                                                  if (! (ch < 1 << 8)) {
                                                    goto while_38_break;
                                                  }
#line 3281
                                                  if (is_alnum) {
                                                    {
#line 3281
                                                    tmp___467 = __dyc_funcallvar_137;
                                                    }
#line 3281
                                                    if ((int const   )*(*tmp___467 + ch) & 8) {
#line 3285
                                                      *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                    } else {
                                                      goto _L___53;
                                                    }
                                                  } else {
                                                    _L___53: /* CIL Label */ 
#line 3281
                                                    if (is_alpha) {
                                                      {
#line 3281
                                                      tmp___468 = __dyc_funcallvar_138;
                                                      }
#line 3281
                                                      if ((int const   )*(*tmp___468 + ch) & 1024) {
#line 3285
                                                        *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                      } else {
                                                        goto _L___52;
                                                      }
                                                    } else {
                                                      _L___52: /* CIL Label */ 
#line 3281
                                                      if (is_blank) {
                                                        {
#line 3281
                                                        tmp___469 = __dyc_funcallvar_139;
                                                        }
#line 3281
                                                        if ((int const   )*(*tmp___469 + ch) & 1) {
#line 3285
                                                          *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                        } else {
                                                          goto _L___51;
                                                        }
                                                      } else {
                                                        _L___51: /* CIL Label */ 
#line 3281
                                                        if (is_cntrl) {
                                                          {
#line 3281
                                                          tmp___470 = __dyc_funcallvar_140;
                                                          }
#line 3281
                                                          if ((int const   )*(*tmp___470 + ch) & 2) {
#line 3285
                                                            *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
#line 3286
                                                  if (is_digit) {
                                                    {
#line 3286
                                                    tmp___471 = __dyc_funcallvar_141;
                                                    }
#line 3286
                                                    if ((int const   )*(*tmp___471 + ch) & 2048) {
#line 3290
                                                      *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                    } else {
                                                      goto _L___56;
                                                    }
                                                  } else {
                                                    _L___56: /* CIL Label */ 
#line 3286
                                                    if (is_graph) {
                                                      {
#line 3286
                                                      tmp___472 = __dyc_funcallvar_142;
                                                      }
#line 3286
                                                      if ((int const   )*(*tmp___472 + ch) & 32768) {
#line 3290
                                                        *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                      } else {
                                                        goto _L___55;
                                                      }
                                                    } else {
                                                      _L___55: /* CIL Label */ 
#line 3286
                                                      if (is_lower) {
                                                        {
#line 3286
                                                        tmp___473 = __dyc_funcallvar_143;
                                                        }
#line 3286
                                                        if ((int const   )*(*tmp___473 + ch) & 512) {
#line 3290
                                                          *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                        } else {
                                                          goto _L___54;
                                                        }
                                                      } else {
                                                        _L___54: /* CIL Label */ 
#line 3286
                                                        if (is_print) {
                                                          {
#line 3286
                                                          tmp___474 = __dyc_funcallvar_144;
                                                          }
#line 3286
                                                          if ((int const   )*(*tmp___474 + ch) & 16384) {
#line 3290
                                                            *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
#line 3291
                                                  if (is_punct) {
                                                    {
#line 3291
                                                    tmp___475 = __dyc_funcallvar_145;
                                                    }
#line 3291
                                                    if ((int const   )*(*tmp___475 + ch) & 4) {
#line 3295
                                                      *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                    } else {
                                                      goto _L___59;
                                                    }
                                                  } else {
                                                    _L___59: /* CIL Label */ 
#line 3291
                                                    if (is_space) {
                                                      {
#line 3291
                                                      tmp___476 = __dyc_funcallvar_146;
                                                      }
#line 3291
                                                      if ((int const   )*(*tmp___476 + ch) & 8192) {
#line 3295
                                                        *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                      } else {
                                                        goto _L___58;
                                                      }
                                                    } else {
                                                      _L___58: /* CIL Label */ 
#line 3291
                                                      if (is_upper) {
                                                        {
#line 3291
                                                        tmp___477 = __dyc_funcallvar_147;
                                                        }
#line 3291
                                                        if ((int const   )*(*tmp___477 + ch) & 256) {
#line 3295
                                                          *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                        } else {
                                                          goto _L___57;
                                                        }
                                                      } else {
                                                        _L___57: /* CIL Label */ 
#line 3291
                                                        if (is_xdigit) {
                                                          {
#line 3291
                                                          tmp___478 = __dyc_funcallvar_148;
                                                          }
#line 3291
                                                          if ((int const   )*(*tmp___478 + ch) & 4096) {
#line 3295
                                                            *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
#line 3296
                                                  if (translate) {
#line 3296
                                                    if (is_upper) {
                                                      goto _L___60;
                                                    } else {
#line 3296
                                                      if (is_lower) {
                                                        _L___60: /* CIL Label */ 
                                                        {
#line 3296
                                                        tmp___479 = __dyc_funcallvar_149;
                                                        }
#line 3296
                                                        if ((int const   )*(*tmp___479 + ch) & 256) {
#line 3298
                                                          *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                        } else {
                                                          {
#line 3296
                                                          tmp___480 = __dyc_funcallvar_150;
                                                          }
#line 3296
                                                          if ((int const   )*(*tmp___480 + ch) & 512) {
#line 3298
                                                            *(b + (int )((unsigned char )ch) / 8) = (unsigned char )((int )*(b + (int )((unsigned char )ch) / 8) | (1 << (int )((unsigned char )ch) % 8));
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
#line 3277
                                                  ch ++;
                                                }
                                                while_38_break: /* CIL Label */ ;
                                                }
#line 3300
                                                had_char_class = (char)1;
                                              } else {
                                                goto _L___61;
                                              }
                                            } else {
                                              _L___61: /* CIL Label */ 
#line 3305
                                              c1 = (unsigned char )((int )c1 + 1);
                                              {
#line 3306
                                              while (1) {
                                                while_39_continue: /* CIL Label */ ;
#line 3306
                                                tmp___481 = c1;
#line 3306
                                                c1 = (unsigned char )((int )c1 - 1);
#line 3306
                                                if (! tmp___481) {
                                                  goto while_39_break;
                                                }
#line 3307
                                                p --;
                                              }
                                              while_39_break: /* CIL Label */ ;
                                              }
#line 3308
                                              *(b + 11) = (unsigned char )((int )*(b + 11) | (1 << 3));
#line 3309
                                              *(b + 7) = (unsigned char )((int )*(b + 7) | (1 << 2));
#line 3310
                                              range_start = (unsigned int )':';
#line 3311
                                              had_char_class = (char)0;
                                            }
                                          } else {
                                            goto _L___71;
                                          }
                                        } else {
                                          goto _L___71;
                                        }
                                      } else {
                                        _L___71: /* CIL Label */ 
#line 3314
                                        if (syntax & ((1UL << 1) << 1)) {
#line 3314
                                          if ((int )c == 91) {
#line 3314
                                            if ((int const   )*p == 61) {
                                              {
#line 3322
                                              while (1) {
                                                while_40_continue: /* CIL Label */ ;
#line 3322
                                                if ((unsigned long )p == (unsigned long )pend) {
                                                  goto __dyc_dummy_label;
                                                }
#line 3322
                                                tmp___482 = p;
#line 3322
                                                p ++;
#line 3322
                                                c = (unsigned char )*tmp___482;
#line 3322
                                                if (translate) {
#line 3322
                                                  c = (unsigned char )*(translate + c);
                                                }
                                                goto while_40_break;
                                              }
                                              while_40_break: /* CIL Label */ ;
                                              }
#line 3323
                                              c1 = (unsigned char)0;
#line 3326
                                              if ((unsigned long )p == (unsigned long )pend) {
                                                {

                                                }
                                                goto __dyc_dummy_label;
                                              }
                                              {
#line 3328
                                              while (1) {
                                                while_41_continue: /* CIL Label */ ;
                                                {
#line 3330
                                                while (1) {
                                                  while_42_continue: /* CIL Label */ ;
#line 3330
                                                  if ((unsigned long )p == (unsigned long )pend) {
                                                    goto __dyc_dummy_label;
                                                  }
#line 3330
                                                  tmp___483 = p;
#line 3330
                                                  p ++;
#line 3330
                                                  c = (unsigned char )*tmp___483;
#line 3330
                                                  if (translate) {
#line 3330
                                                    c = (unsigned char )*(translate + c);
                                                  }
                                                  goto while_42_break;
                                                }
                                                while_42_break: /* CIL Label */ ;
                                                }
#line 3331
                                                if ((int )c == 61) {
#line 3331
                                                  if ((int const   )*p == 93) {
                                                    goto while_41_break;
                                                  } else {
                                                    goto _L___62;
                                                  }
                                                } else {
                                                  _L___62: /* CIL Label */ 
#line 3331
                                                  if ((unsigned long )p == (unsigned long )pend) {
                                                    goto while_41_break;
                                                  }
                                                }
#line 3333
                                                if ((int )c1 < 16) {
#line 3334
                                                  tmp___484 = c1;
#line 3334
                                                  c1 = (unsigned char )((int )c1 + 1);
#line 3334
                                                  str___0[tmp___484] = c;
                                                } else {
#line 3337
                                                  str___0[0] = (unsigned char )'\000';
                                                }
                                              }
                                              while_41_break: /* CIL Label */ ;
                                              }
#line 3339
                                              str___0[c1] = (unsigned char )'\000';
#line 3341
                                              if ((int )c == 61) {
#line 3341
                                                if ((int const   )*p == 93) {
#line 3341
                                                  if ((int )str___0[0] != 0) {
#line 3353
                                                    if ((int )c1 != 1) {
                                                      {

                                                      }
                                                      goto __dyc_dummy_label;
                                                    }
                                                    {
#line 3358
                                                    while (1) {
                                                      while_43_continue: /* CIL Label */ ;
#line 3358
                                                      if ((unsigned long )p == (unsigned long )pend) {
                                                        goto __dyc_dummy_label;
                                                      }
#line 3358
                                                      tmp___485 = p;
#line 3358
                                                      p ++;
#line 3358
                                                      c = (unsigned char )*tmp___485;
#line 3358
                                                      if (translate) {
#line 3358
                                                        c = (unsigned char )*(translate + c);
                                                      }
                                                      goto while_43_break;
                                                    }
                                                    while_43_break: /* CIL Label */ ;
                                                    }
#line 3361
                                                    *(b + (int )str___0[0] / 8) = (unsigned char )((int )*(b + (int )str___0[0] / 8) | (1 << (int )str___0[0] % 8));
#line 3435
                                                    had_char_class = (char)1;
                                                  } else {
                                                    goto _L___64;
                                                  }
                                                } else {
                                                  goto _L___64;
                                                }
                                              } else {
                                                _L___64: /* CIL Label */ 
#line 3439
                                                c1 = (unsigned char )((int )c1 + 1);
                                                {
#line 3440
                                                while (1) {
                                                  while_44_continue: /* CIL Label */ ;
#line 3440
                                                  tmp___486 = c1;
#line 3440
                                                  c1 = (unsigned char )((int )c1 - 1);
#line 3440
                                                  if (! tmp___486) {
                                                    goto while_44_break;
                                                  }
#line 3441
                                                  p --;
                                                }
                                                while_44_break: /* CIL Label */ ;
                                                }
#line 3442
                                                *(b + 11) = (unsigned char )((int )*(b + 11) | (1 << 3));
#line 3443
                                                *(b + 7) = (unsigned char )((int )*(b + 7) | (1 << 5));
#line 3444
                                                range_start = (unsigned int )'=';
#line 3445
                                                had_char_class = (char)0;
                                              }
                                            } else {
                                              goto _L___69;
                                            }
                                          } else {
                                            goto _L___69;
                                          }
                                        } else {
                                          _L___69: /* CIL Label */ 
#line 3448
                                          if (syntax & ((1UL << 1) << 1)) {
#line 3448
                                            if ((int )c == 91) {
#line 3448
                                              if ((int const   )*p == 46) {
                                                {
#line 3456
                                                while (1) {
                                                  while_45_continue: /* CIL Label */ ;
#line 3456
                                                  if ((unsigned long )p == (unsigned long )pend) {
                                                    goto __dyc_dummy_label;
                                                  }
#line 3456
                                                  tmp___487 = p;
#line 3456
                                                  p ++;
#line 3456
                                                  c = (unsigned char )*tmp___487;
#line 3456
                                                  if (translate) {
#line 3456
                                                    c = (unsigned char )*(translate + c);
                                                  }
                                                  goto while_45_break;
                                                }
                                                while_45_break: /* CIL Label */ ;
                                                }
#line 3457
                                                c1 = (unsigned char)0;
#line 3460
                                                if ((unsigned long )p == (unsigned long )pend) {
                                                  {

                                                  }
                                                  goto __dyc_dummy_label;
                                                }
                                                {
#line 3462
                                                while (1) {
                                                  while_46_continue: /* CIL Label */ ;
                                                  {
#line 3464
                                                  while (1) {
                                                    while_47_continue: /* CIL Label */ ;
#line 3464
                                                    if ((unsigned long )p == (unsigned long )pend) {
                                                      goto __dyc_dummy_label;
                                                    }
#line 3464
                                                    tmp___488 = p;
#line 3464
                                                    p ++;
#line 3464
                                                    c = (unsigned char )*tmp___488;
#line 3464
                                                    if (translate) {
#line 3464
                                                      c = (unsigned char )*(translate + c);
                                                    }
                                                    goto while_47_break;
                                                  }
                                                  while_47_break: /* CIL Label */ ;
                                                  }
#line 3465
                                                  if ((int )c == 46) {
#line 3465
                                                    if ((int const   )*p == 93) {
                                                      goto while_46_break;
                                                    } else {
                                                      goto _L___65;
                                                    }
                                                  } else {
                                                    _L___65: /* CIL Label */ 
#line 3465
                                                    if ((unsigned long )p == (unsigned long )pend) {
                                                      goto while_46_break;
                                                    }
                                                  }
#line 3467
                                                  if ((unsigned long )c1 < sizeof(unsigned char [128])) {
#line 3468
                                                    tmp___489 = c1;
#line 3468
                                                    c1 = (unsigned char )((int )c1 + 1);
#line 3468
                                                    str___1[tmp___489] = c;
                                                  } else {
#line 3471
                                                    str___1[0] = (unsigned char )'\000';
                                                  }
                                                }
                                                while_46_break: /* CIL Label */ ;
                                                }
#line 3473
                                                str___1[c1] = (unsigned char )'\000';
#line 3475
                                                if ((int )c == 46) {
#line 3475
                                                  if ((int const   )*p == 93) {
#line 3475
                                                    if ((int )str___1[0] != 0) {
#line 3488
                                                      if ((int )c1 != 1) {
                                                        {

                                                        }
                                                        goto __dyc_dummy_label;
                                                      }
                                                      {
#line 3493
                                                      while (1) {
                                                        while_48_continue: /* CIL Label */ ;
#line 3493
                                                        if ((unsigned long )p == (unsigned long )pend) {
                                                          goto __dyc_dummy_label;
                                                        }
#line 3493
                                                        tmp___490 = p;
#line 3493
                                                        p ++;
#line 3493
                                                        c = (unsigned char )*tmp___490;
#line 3493
                                                        if (translate) {
#line 3493
                                                          c = (unsigned char )*(translate + c);
                                                        }
                                                        goto while_48_break;
                                                      }
                                                      while_48_break: /* CIL Label */ ;
                                                      }
#line 3496
                                                      *(b + (int )str___1[0] / 8) = (unsigned char )((int )*(b + (int )str___1[0] / 8) | (1 << (int )str___1[0] % 8));
#line 3497
                                                      range_start = (unsigned int )*((unsigned char const   *)(str___1) + 0);
#line 3578
                                                      had_char_class = (char)0;
                                                    } else {
                                                      goto _L___67;
                                                    }
                                                  } else {
                                                    goto _L___67;
                                                  }
                                                } else {
                                                  _L___67: /* CIL Label */ 
#line 3582
                                                  c1 = (unsigned char )((int )c1 + 1);
                                                  {
#line 3583
                                                  while (1) {
                                                    while_49_continue: /* CIL Label */ ;
#line 3583
                                                    tmp___491 = c1;
#line 3583
                                                    c1 = (unsigned char )((int )c1 - 1);
#line 3583
                                                    if (! tmp___491) {
                                                      goto while_49_break;
                                                    }
#line 3584
                                                    p --;
                                                  }
                                                  while_49_break: /* CIL Label */ ;
                                                  }
#line 3585
                                                  *(b + 11) = (unsigned char )((int )*(b + 11) | (1 << 3));
#line 3586
                                                  *(b + 5) = (unsigned char )((int )*(b + 5) | (1 << 6));
#line 3587
                                                  range_start = (unsigned int )'.';
#line 3588
                                                  had_char_class = (char)0;
                                                }
                                              } else {
#line 3593
                                                had_char_class = (char)0;
#line 3594
                                                *(b + (int )c / 8) = (unsigned char )((int )*(b + (int )c / 8) | (1 << (int )c % 8));
#line 3595
                                                range_start = (unsigned int )c;
                                              }
                                            } else {
#line 3593
                                              had_char_class = (char)0;
#line 3594
                                              *(b + (int )c / 8) = (unsigned char )((int )*(b + (int )c / 8) | (1 << (int )c % 8));
#line 3595
                                              range_start = (unsigned int )c;
                                            }
                                          } else {
#line 3593
                                            had_char_class = (char)0;
#line 3594
                                            *(b + (int )c / 8) = (unsigned char )((int )*(b + (int )c / 8) | (1 << (int )c % 8));
#line 3595
                                            range_start = (unsigned int )c;
                                          }
                                        }
                                      }
                                    }
                                  }
                                  __Cont: /* CIL Label */ ;
                                }
                                while_30_break: /* CIL Label */ ;
                                }
                                {
#line 3601
                                while (1) {
                                  while_50_continue: /* CIL Label */ ;
#line 3601
                                  if ((int )*(b + -1) > 0) {
#line 3601
                                    if (! ((int )*(b + ((int )*(b + -1) - 1)) == 0)) {
                                      goto while_50_break;
                                    }
                                  } else {
                                    goto while_50_break;
                                  }
#line 3602
                                  *(b + -1) = (unsigned char )((int )*(b + -1) - 1);
                                }
                                while_50_break: /* CIL Label */ ;
                                }
#line 3603
                                b += (int )*(b + -1);
                                goto switch_3_break;
                                switch_3_40: /* CIL Label */ 
#line 3610
                                if (syntax & (((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                  goto handle_open;
                                } else {
                                  goto normal_char;
                                }
                                switch_3_41: /* CIL Label */ 
#line 3617
                                if (syntax & (((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                  goto handle_close;
                                } else {
                                  goto normal_char;
                                }
                                switch_3_10: /* CIL Label */ 
#line 3624
                                if (syntax & (((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                  goto handle_alt;
                                } else {
                                  goto normal_char;
                                }
                                switch_3_124: /* CIL Label */ 
#line 3631
                                if (syntax & (((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                  goto handle_alt;
                                } else {
                                  goto normal_char;
                                }
                                switch_3_123: /* CIL Label */ 
#line 3638
                                if (syntax & (((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
#line 3638
                                  if (syntax & ((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                    goto handle_interval;
                                  } else {
                                    goto normal_char;
                                  }
                                } else {
                                  goto normal_char;
                                }
                                switch_3_92: /* CIL Label */ 
#line 3645
                                if ((unsigned long )p == (unsigned long )pend) {
                                  {

                                  }
                                  goto __dyc_dummy_label;
                                }
                                {
#line 3650
                                while (1) {
                                  while_51_continue: /* CIL Label */ ;
#line 3650
                                  if ((unsigned long )p == (unsigned long )pend) {
                                    goto __dyc_dummy_label;
                                  }
#line 3650
                                  tmp___492 = p;
#line 3650
                                  p ++;
#line 3650
                                  c = (unsigned char )*tmp___492;
                                  goto while_51_break;
                                }
                                while_51_break: /* CIL Label */ ;
                                }
#line 3654
                                if ((int )c == 40) {
                                  goto switch_52_40;
                                } else {
#line 3704
                                  if ((int )c == 41) {
                                    goto switch_52_41;
                                  } else {
#line 3774
                                    if ((int )c == 124) {
                                      goto switch_52_124;
                                    } else {
#line 3820
                                      if ((int )c == 123) {
                                        goto switch_52_123;
                                      } else {
#line 4006
                                        if ((int )c == 119) {
                                          goto switch_52_119;
                                        } else {
#line 4014
                                          if ((int )c == 87) {
                                            goto switch_52_87;
                                          } else {
#line 4022
                                            if ((int )c == 60) {
                                              goto switch_52_60;
                                            } else {
#line 4028
                                              if ((int )c == 62) {
                                                goto switch_52_62;
                                              } else {
#line 4034
                                                if ((int )c == 98) {
                                                  goto switch_52_98;
                                                } else {
#line 4040
                                                  if ((int )c == 66) {
                                                    goto switch_52_66;
                                                  } else {
#line 4046
                                                    if ((int )c == 96) {
                                                      goto switch_52_96;
                                                    } else {
#line 4052
                                                      if ((int )c == 39) {
                                                        goto switch_52_39;
                                                      } else {
#line 4058
                                                        if ((int )c == 49) {
                                                          goto switch_52_49;
                                                        } else {
#line 4058
                                                          if ((int )c == 50) {
                                                            goto switch_52_49;
                                                          } else {
#line 4058
                                                            if ((int )c == 51) {
                                                              goto switch_52_49;
                                                            } else {
#line 4058
                                                              if ((int )c == 52) {
                                                                goto switch_52_49;
                                                              } else {
#line 4058
                                                                if ((int )c == 53) {
                                                                  goto switch_52_49;
                                                                } else {
#line 4059
                                                                  if ((int )c == 54) {
                                                                    goto switch_52_49;
                                                                  } else {
#line 4059
                                                                    if ((int )c == 55) {
                                                                      goto switch_52_49;
                                                                    } else {
#line 4059
                                                                      if ((int )c == 56) {
                                                                        goto switch_52_49;
                                                                      } else {
#line 4059
                                                                        if ((int )c == 57) {
                                                                          goto switch_52_49;
                                                                        } else {
#line 4077
                                                                          if ((int )c == 43) {
                                                                            goto switch_52_43;
                                                                          } else {
#line 4078
                                                                            if ((int )c == 63) {
                                                                              goto switch_52_43;
                                                                            } else {
                                                                              {
                                                                              goto switch_52_default;
#line 3652
                                                                              if (0) {
                                                                                switch_52_40: /* CIL Label */ 
#line 3655
                                                                                if (syntax & (((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_backslash;
                                                                                }
                                                                                handle_open: 
#line 3659
                                                                                (bufp->re_nsub) ++;
#line 3660
                                                                                regnum ++;
#line 3662
                                                                                if (compile_stack.avail == compile_stack.size) {
                                                                                  {
#line 3664
                                                                                  tmp___493 = __dyc_funcallvar_151;
#line 3664
                                                                                  compile_stack.stack = (compile_stack_elt_t *)tmp___493;
                                                                                  }
#line 3666
                                                                                  if ((unsigned long )compile_stack.stack == (unsigned long )((void *)0)) {
                                                                                    goto __dyc_dummy_label;
                                                                                  }
#line 3668
                                                                                  compile_stack.size <<= 1;
                                                                                }
#line 3675
                                                                                (compile_stack.stack + compile_stack.avail)->begalt_offset = (long )(begalt - bufp->buffer);
#line 3676
                                                                                if (fixup_alt_jump) {
#line 3676
                                                                                  (compile_stack.stack + compile_stack.avail)->fixup_alt_jump = (long )((fixup_alt_jump - bufp->buffer) + 1);
                                                                                } else {
#line 3676
                                                                                  (compile_stack.stack + compile_stack.avail)->fixup_alt_jump = 0L;
                                                                                }
#line 3678
                                                                                (compile_stack.stack + compile_stack.avail)->laststart_offset = (long )(b - bufp->buffer);
#line 3679
                                                                                (compile_stack.stack + compile_stack.avail)->regnum = regnum;
#line 3685
                                                                                if (regnum <= 255U) {
#line 3687
                                                                                  (compile_stack.stack + compile_stack.avail)->inner_group_offset = (long )((b - bufp->buffer) + 2);
                                                                                  {
#line 3689
                                                                                  while (1) {
                                                                                    while_53_continue: /* CIL Label */ ;
                                                                                    {
#line 3689
                                                                                    while (1) {
                                                                                      while_54_continue: /* CIL Label */ ;
#line 3689
                                                                                      if (! ((unsigned long )((b - bufp->buffer) + 3) > bufp->allocated)) {
                                                                                        goto while_54_break;
                                                                                      }
                                                                                      {
#line 3689
                                                                                      while (1) {
                                                                                        while_55_continue: /* CIL Label */ ;
#line 3689
                                                                                        old_buffer___8 = bufp->buffer;
#line 3689
                                                                                        if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                          goto __dyc_dummy_label;
                                                                                        }
#line 3689
                                                                                        bufp->allocated <<= 1;
#line 3689
                                                                                        if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 3689
                                                                                          bufp->allocated = (unsigned long )(1L << 16);
                                                                                        }
                                                                                        {
#line 3689
                                                                                        tmp___494 = __dyc_funcallvar_152;
#line 3689
                                                                                        bufp->buffer = (unsigned char *)tmp___494;
                                                                                        }
#line 3689
                                                                                        if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                          goto __dyc_dummy_label;
                                                                                        }
#line 3689
                                                                                        if ((unsigned long )old_buffer___8 != (unsigned long )bufp->buffer) {
#line 3689
                                                                                          incr___8 = (ptrdiff_t )(bufp->buffer - old_buffer___8);
#line 3689
                                                                                          b += incr___8;
#line 3689
                                                                                          begalt += incr___8;
#line 3689
                                                                                          if (fixup_alt_jump) {
#line 3689
                                                                                            fixup_alt_jump += incr___8;
                                                                                          }
#line 3689
                                                                                          if (laststart) {
#line 3689
                                                                                            laststart += incr___8;
                                                                                          }
#line 3689
                                                                                          if (pending_exact) {
#line 3689
                                                                                            pending_exact += incr___8;
                                                                                          }
                                                                                        }
                                                                                        goto while_55_break;
                                                                                      }
                                                                                      while_55_break: /* CIL Label */ ;
                                                                                      }
                                                                                    }
                                                                                    while_54_break: /* CIL Label */ ;
                                                                                    }
#line 3689
                                                                                    tmp___495 = b;
#line 3689
                                                                                    b ++;
#line 3689
                                                                                    *tmp___495 = (unsigned char)6;
#line 3689
                                                                                    tmp___496 = b;
#line 3689
                                                                                    b ++;
#line 3689
                                                                                    *tmp___496 = (unsigned char )regnum;
#line 3689
                                                                                    tmp___497 = b;
#line 3689
                                                                                    b ++;
#line 3689
                                                                                    *tmp___497 = (unsigned char)0;
                                                                                    goto while_53_break;
                                                                                  }
                                                                                  while_53_break: /* CIL Label */ ;
                                                                                  }
                                                                                }
#line 3692
                                                                                (compile_stack.avail) ++;
#line 3694
                                                                                fixup_alt_jump = (unsigned char *)0;
#line 3695
                                                                                laststart = (unsigned char *)0;
#line 3696
                                                                                begalt = b;
#line 3700
                                                                                pending_exact = (unsigned char *)0;
                                                                                goto switch_52_break;
                                                                                switch_52_41: /* CIL Label */ 
#line 3705
                                                                                if (syntax & (((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_backslash;
                                                                                }
#line 3707
                                                                                if (compile_stack.avail == 0U) {
#line 3709
                                                                                  if (syntax & (((((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                    goto normal_backslash;
                                                                                  } else {
                                                                                    {

                                                                                    }
                                                                                    goto __dyc_dummy_label;
                                                                                  }
                                                                                }
                                                                                handle_close: 
#line 3716
                                                                                if (fixup_alt_jump) {
                                                                                  {
#line 3721
                                                                                  while (1) {
                                                                                    while_56_continue: /* CIL Label */ ;
                                                                                    {
#line 3721
                                                                                    while (1) {
                                                                                      while_57_continue: /* CIL Label */ ;
#line 3721
                                                                                      if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                                                                        goto while_57_break;
                                                                                      }
                                                                                      {
#line 3721
                                                                                      while (1) {
                                                                                        while_58_continue: /* CIL Label */ ;
#line 3721
                                                                                        old_buffer___9 = bufp->buffer;
#line 3721
                                                                                        if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                          goto __dyc_dummy_label;
                                                                                        }
#line 3721
                                                                                        bufp->allocated <<= 1;
#line 3721
                                                                                        if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 3721
                                                                                          bufp->allocated = (unsigned long )(1L << 16);
                                                                                        }
                                                                                        {
#line 3721
                                                                                        tmp___498 = __dyc_funcallvar_153;
#line 3721
                                                                                        bufp->buffer = (unsigned char *)tmp___498;
                                                                                        }
#line 3721
                                                                                        if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                          goto __dyc_dummy_label;
                                                                                        }
#line 3721
                                                                                        if ((unsigned long )old_buffer___9 != (unsigned long )bufp->buffer) {
#line 3721
                                                                                          incr___9 = (ptrdiff_t )(bufp->buffer - old_buffer___9);
#line 3721
                                                                                          b += incr___9;
#line 3721
                                                                                          begalt += incr___9;
#line 3721
                                                                                          if (fixup_alt_jump) {
#line 3721
                                                                                            fixup_alt_jump += incr___9;
                                                                                          }
#line 3721
                                                                                          if (laststart) {
#line 3721
                                                                                            laststart += incr___9;
                                                                                          }
#line 3721
                                                                                          if (pending_exact) {
#line 3721
                                                                                            pending_exact += incr___9;
                                                                                          }
                                                                                        }
                                                                                        goto while_58_break;
                                                                                      }
                                                                                      while_58_break: /* CIL Label */ ;
                                                                                      }
                                                                                    }
                                                                                    while_57_break: /* CIL Label */ ;
                                                                                    }
#line 3721
                                                                                    tmp___499 = b;
#line 3721
                                                                                    b ++;
#line 3721
                                                                                    *tmp___499 = (unsigned char)20;
                                                                                    goto while_56_break;
                                                                                  }
                                                                                  while_56_break: /* CIL Label */ ;
                                                                                  }
                                                                                  {

                                                                                  }
                                                                                }
#line 3729
                                                                                if (compile_stack.avail == 0U) {
#line 3731
                                                                                  if (syntax & (((((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                    goto normal_char;
                                                                                  } else {
                                                                                    {

                                                                                    }
                                                                                    goto __dyc_dummy_label;
                                                                                  }
                                                                                }
#line 3746
                                                                                (compile_stack.avail) --;
#line 3747
                                                                                begalt = bufp->buffer + (compile_stack.stack + compile_stack.avail)->begalt_offset;
#line 3748
                                                                                if ((compile_stack.stack + compile_stack.avail)->fixup_alt_jump) {
#line 3748
                                                                                  fixup_alt_jump = (bufp->buffer + (compile_stack.stack + compile_stack.avail)->fixup_alt_jump) - 1;
                                                                                } else {
#line 3748
                                                                                  fixup_alt_jump = (unsigned char *)0;
                                                                                }
#line 3752
                                                                                laststart = bufp->buffer + (compile_stack.stack + compile_stack.avail)->laststart_offset;
#line 3753
                                                                                this_group_regnum = (compile_stack.stack + compile_stack.avail)->regnum;
#line 3757
                                                                                pending_exact = (unsigned char *)0;
#line 3761
                                                                                if (this_group_regnum <= 255U) {
#line 3763
                                                                                  inner_group_loc = bufp->buffer + (compile_stack.stack + compile_stack.avail)->inner_group_offset;
#line 3766
                                                                                  *inner_group_loc = (unsigned char )(regnum - this_group_regnum);
                                                                                  {
#line 3767
                                                                                  while (1) {
                                                                                    while_59_continue: /* CIL Label */ ;
                                                                                    {
#line 3767
                                                                                    while (1) {
                                                                                      while_60_continue: /* CIL Label */ ;
#line 3767
                                                                                      if (! ((unsigned long )((b - bufp->buffer) + 3) > bufp->allocated)) {
                                                                                        goto while_60_break;
                                                                                      }
                                                                                      {
#line 3767
                                                                                      while (1) {
                                                                                        while_61_continue: /* CIL Label */ ;
#line 3767
                                                                                        old_buffer___10 = bufp->buffer;
#line 3767
                                                                                        if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                          goto __dyc_dummy_label;
                                                                                        }
#line 3767
                                                                                        bufp->allocated <<= 1;
#line 3767
                                                                                        if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 3767
                                                                                          bufp->allocated = (unsigned long )(1L << 16);
                                                                                        }
                                                                                        {
#line 3767
                                                                                        tmp___500 = __dyc_funcallvar_154;
#line 3767
                                                                                        bufp->buffer = (unsigned char *)tmp___500;
                                                                                        }
#line 3767
                                                                                        if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                          goto __dyc_dummy_label;
                                                                                        }
#line 3767
                                                                                        if ((unsigned long )old_buffer___10 != (unsigned long )bufp->buffer) {
#line 3767
                                                                                          incr___10 = (ptrdiff_t )(bufp->buffer - old_buffer___10);
#line 3767
                                                                                          b += incr___10;
#line 3767
                                                                                          begalt += incr___10;
#line 3767
                                                                                          if (fixup_alt_jump) {
#line 3767
                                                                                            fixup_alt_jump += incr___10;
                                                                                          }
#line 3767
                                                                                          if (laststart) {
#line 3767
                                                                                            laststart += incr___10;
                                                                                          }
#line 3767
                                                                                          if (pending_exact) {
#line 3767
                                                                                            pending_exact += incr___10;
                                                                                          }
                                                                                        }
                                                                                        goto while_61_break;
                                                                                      }
                                                                                      while_61_break: /* CIL Label */ ;
                                                                                      }
                                                                                    }
                                                                                    while_60_break: /* CIL Label */ ;
                                                                                    }
#line 3767
                                                                                    tmp___501 = b;
#line 3767
                                                                                    b ++;
#line 3767
                                                                                    *tmp___501 = (unsigned char)7;
#line 3767
                                                                                    tmp___502 = b;
#line 3767
                                                                                    b ++;
#line 3767
                                                                                    *tmp___502 = (unsigned char )this_group_regnum;
#line 3767
                                                                                    tmp___503 = b;
#line 3767
                                                                                    b ++;
#line 3767
                                                                                    *tmp___503 = (unsigned char )(regnum - this_group_regnum);
                                                                                    goto while_59_break;
                                                                                  }
                                                                                  while_59_break: /* CIL Label */ ;
                                                                                  }
                                                                                }
                                                                                goto switch_52_break;
                                                                                switch_52_124: /* CIL Label */ 
#line 3775
                                                                                if (syntax & ((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_backslash;
                                                                                } else {
#line 3775
                                                                                  if (syntax & (((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                    goto normal_backslash;
                                                                                  }
                                                                                }
                                                                                handle_alt: 
#line 3778
                                                                                if (syntax & ((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_char;
                                                                                }
                                                                                {
#line 3783
                                                                                while (1) {
                                                                                  while_62_continue: /* CIL Label */ ;
#line 3783
                                                                                  if (! ((unsigned long )((b - bufp->buffer) + 3) > bufp->allocated)) {
                                                                                    goto while_62_break;
                                                                                  }
                                                                                  {
#line 3783
                                                                                  while (1) {
                                                                                    while_63_continue: /* CIL Label */ ;
#line 3783
                                                                                    old_buffer___11 = bufp->buffer;
#line 3783
                                                                                    if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                      goto __dyc_dummy_label;
                                                                                    }
#line 3783
                                                                                    bufp->allocated <<= 1;
#line 3783
                                                                                    if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 3783
                                                                                      bufp->allocated = (unsigned long )(1L << 16);
                                                                                    }
                                                                                    {
#line 3783
                                                                                    tmp___504 = __dyc_funcallvar_155;
#line 3783
                                                                                    bufp->buffer = (unsigned char *)tmp___504;
                                                                                    }
#line 3783
                                                                                    if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                      goto __dyc_dummy_label;
                                                                                    }
#line 3783
                                                                                    if ((unsigned long )old_buffer___11 != (unsigned long )bufp->buffer) {
#line 3783
                                                                                      incr___11 = (ptrdiff_t )(bufp->buffer - old_buffer___11);
#line 3783
                                                                                      b += incr___11;
#line 3783
                                                                                      begalt += incr___11;
#line 3783
                                                                                      if (fixup_alt_jump) {
#line 3783
                                                                                        fixup_alt_jump += incr___11;
                                                                                      }
#line 3783
                                                                                      if (laststart) {
#line 3783
                                                                                        laststart += incr___11;
                                                                                      }
#line 3783
                                                                                      if (pending_exact) {
#line 3783
                                                                                        pending_exact += incr___11;
                                                                                      }
                                                                                    }
                                                                                    goto while_63_break;
                                                                                  }
                                                                                  while_63_break: /* CIL Label */ ;
                                                                                  }
                                                                                }
                                                                                while_62_break: /* CIL Label */ ;
                                                                                }
                                                                                {

#line 3786
                                                                                pending_exact = (unsigned char *)0;
#line 3787
                                                                                b += 3;
                                                                                }
#line 3805
                                                                                if (fixup_alt_jump) {
                                                                                  {

                                                                                  }
                                                                                }
#line 3811
                                                                                fixup_alt_jump = b;
                                                                                {
#line 3812
                                                                                while (1) {
                                                                                  while_64_continue: /* CIL Label */ ;
#line 3812
                                                                                  if (! ((unsigned long )((b - bufp->buffer) + 3) > bufp->allocated)) {
                                                                                    goto while_64_break;
                                                                                  }
                                                                                  {
#line 3812
                                                                                  while (1) {
                                                                                    while_65_continue: /* CIL Label */ ;
#line 3812
                                                                                    old_buffer___12 = bufp->buffer;
#line 3812
                                                                                    if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                      goto __dyc_dummy_label;
                                                                                    }
#line 3812
                                                                                    bufp->allocated <<= 1;
#line 3812
                                                                                    if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 3812
                                                                                      bufp->allocated = (unsigned long )(1L << 16);
                                                                                    }
                                                                                    {
#line 3812
                                                                                    tmp___505 = __dyc_funcallvar_156;
#line 3812
                                                                                    bufp->buffer = (unsigned char *)tmp___505;
                                                                                    }
#line 3812
                                                                                    if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                      goto __dyc_dummy_label;
                                                                                    }
#line 3812
                                                                                    if ((unsigned long )old_buffer___12 != (unsigned long )bufp->buffer) {
#line 3812
                                                                                      incr___12 = (ptrdiff_t )(bufp->buffer - old_buffer___12);
#line 3812
                                                                                      b += incr___12;
#line 3812
                                                                                      begalt += incr___12;
#line 3812
                                                                                      if (fixup_alt_jump) {
#line 3812
                                                                                        fixup_alt_jump += incr___12;
                                                                                      }
#line 3812
                                                                                      if (laststart) {
#line 3812
                                                                                        laststart += incr___12;
                                                                                      }
#line 3812
                                                                                      if (pending_exact) {
#line 3812
                                                                                        pending_exact += incr___12;
                                                                                      }
                                                                                    }
                                                                                    goto while_65_break;
                                                                                  }
                                                                                  while_65_break: /* CIL Label */ ;
                                                                                  }
                                                                                }
                                                                                while_64_break: /* CIL Label */ ;
                                                                                }
#line 3813
                                                                                b += 3;
#line 3815
                                                                                laststart = (unsigned char *)0;
#line 3816
                                                                                begalt = b;
                                                                                goto switch_52_break;
                                                                                switch_52_123: /* CIL Label */ 
#line 3822
                                                                                if (! (syntax & (((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1))) {
                                                                                  goto normal_backslash;
                                                                                } else {
#line 3822
                                                                                  if (syntax & ((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                    goto normal_backslash;
                                                                                  }
                                                                                }
                                                                                handle_interval: 
#line 3833
                                                                                lower_bound = -1;
#line 3833
                                                                                upper_bound = -1;
#line 3837
                                                                                beg_interval = p;
#line 3839
                                                                                if ((unsigned long )p == (unsigned long )pend) {
                                                                                  goto invalid_interval;
                                                                                }
                                                                                {
#line 3842
                                                                                while (1) {
                                                                                  while_66_continue: /* CIL Label */ ;
#line 3842
                                                                                  if (! ((unsigned long )p != (unsigned long )pend)) {
                                                                                    goto while_66_break;
                                                                                  }
                                                                                  {
#line 3842
                                                                                  while (1) {
                                                                                    while_67_continue: /* CIL Label */ ;
#line 3842
                                                                                    if ((unsigned long )p == (unsigned long )pend) {
                                                                                      goto __dyc_dummy_label;
                                                                                    }
#line 3842
                                                                                    tmp___506 = p;
#line 3842
                                                                                    p ++;
#line 3842
                                                                                    c = (unsigned char )*tmp___506;
#line 3842
                                                                                    if (translate) {
#line 3842
                                                                                      c = (unsigned char )*(translate + c);
                                                                                    }
                                                                                    goto while_67_break;
                                                                                  }
                                                                                  while_67_break: /* CIL Label */ ;
                                                                                  }
#line 3842
                                                                                  if ((int )c < 48) {
                                                                                    goto while_66_break;
                                                                                  } else {
#line 3842
                                                                                    if ((int )c > 57) {
                                                                                      goto while_66_break;
                                                                                    }
                                                                                  }
#line 3842
                                                                                  if (lower_bound <= 32767) {
#line 3842
                                                                                    if (lower_bound < 0) {
#line 3842
                                                                                      lower_bound = 0;
                                                                                    }
#line 3842
                                                                                    lower_bound = (lower_bound * 10 + (int )c) - 48;
                                                                                  }
                                                                                }
                                                                                while_66_break: /* CIL Label */ ;
                                                                                }
#line 3844
                                                                                if ((int )c == 44) {
                                                                                  {
#line 3846
                                                                                  while (1) {
                                                                                    while_68_continue: /* CIL Label */ ;
#line 3846
                                                                                    if (! ((unsigned long )p != (unsigned long )pend)) {
                                                                                      goto while_68_break;
                                                                                    }
                                                                                    {
#line 3846
                                                                                    while (1) {
                                                                                      while_69_continue: /* CIL Label */ ;
#line 3846
                                                                                      if ((unsigned long )p == (unsigned long )pend) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 3846
                                                                                      tmp___507 = p;
#line 3846
                                                                                      p ++;
#line 3846
                                                                                      c = (unsigned char )*tmp___507;
#line 3846
                                                                                      if (translate) {
#line 3846
                                                                                        c = (unsigned char )*(translate + c);
                                                                                      }
                                                                                      goto while_69_break;
                                                                                    }
                                                                                    while_69_break: /* CIL Label */ ;
                                                                                    }
#line 3846
                                                                                    if ((int )c < 48) {
                                                                                      goto while_68_break;
                                                                                    } else {
#line 3846
                                                                                      if ((int )c > 57) {
                                                                                        goto while_68_break;
                                                                                      }
                                                                                    }
#line 3846
                                                                                    if (upper_bound <= 32767) {
#line 3846
                                                                                      if (upper_bound < 0) {
#line 3846
                                                                                        upper_bound = 0;
                                                                                      }
#line 3846
                                                                                      upper_bound = (upper_bound * 10 + (int )c) - 48;
                                                                                    }
                                                                                  }
                                                                                  while_68_break: /* CIL Label */ ;
                                                                                  }
#line 3847
                                                                                  if (upper_bound < 0) {
#line 3848
                                                                                    upper_bound = 32767;
                                                                                  }
                                                                                } else {
#line 3852
                                                                                  upper_bound = lower_bound;
                                                                                }
#line 3854
                                                                                if (0 <= lower_bound) {
#line 3854
                                                                                  if (! (lower_bound <= upper_bound)) {
                                                                                    goto invalid_interval;
                                                                                  }
                                                                                } else {
                                                                                  goto invalid_interval;
                                                                                }
#line 3857
                                                                                if (! (syntax & ((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1))) {
#line 3859
                                                                                  if ((int )c != 92) {
                                                                                    goto invalid_interval;
                                                                                  } else {
#line 3859
                                                                                    if ((unsigned long )p == (unsigned long )pend) {
                                                                                      goto invalid_interval;
                                                                                    }
                                                                                  }
                                                                                  {
#line 3861
                                                                                  while (1) {
                                                                                    while_70_continue: /* CIL Label */ ;
#line 3861
                                                                                    if ((unsigned long )p == (unsigned long )pend) {
                                                                                      goto __dyc_dummy_label;
                                                                                    }
#line 3861
                                                                                    tmp___508 = p;
#line 3861
                                                                                    p ++;
#line 3861
                                                                                    c = (unsigned char )*tmp___508;
#line 3861
                                                                                    if (translate) {
#line 3861
                                                                                      c = (unsigned char )*(translate + c);
                                                                                    }
                                                                                    goto while_70_break;
                                                                                  }
                                                                                  while_70_break: /* CIL Label */ ;
                                                                                  }
                                                                                }
#line 3864
                                                                                if ((int )c != 125) {
                                                                                  goto invalid_interval;
                                                                                }
#line 3868
                                                                                if (! laststart) {
#line 3870
                                                                                  if (syntax & (((((1UL << 1) << 1) << 1) << 1) << 1)) {
#line 3870
                                                                                    if (! (syntax & (((((((((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1))) {
                                                                                      {

                                                                                      }
                                                                                      goto __dyc_dummy_label;
                                                                                    } else {
                                                                                      goto _L___79;
                                                                                    }
                                                                                  } else {
                                                                                    _L___79: /* CIL Label */ 
#line 3873
                                                                                    if (syntax & ((((1UL << 1) << 1) << 1) << 1)) {
#line 3874
                                                                                      laststart = b;
                                                                                    } else {
                                                                                      goto unfetch_interval;
                                                                                    }
                                                                                  }
                                                                                }
#line 3881
                                                                                if (32767 < upper_bound) {
                                                                                  {

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                }
#line 3889
                                                                                if (upper_bound == 0) {
                                                                                  {
#line 3891
                                                                                  while (1) {
                                                                                    while_71_continue: /* CIL Label */ ;
#line 3891
                                                                                    if (! ((unsigned long )((b - bufp->buffer) + 3) > bufp->allocated)) {
                                                                                      goto while_71_break;
                                                                                    }
                                                                                    {
#line 3891
                                                                                    while (1) {
                                                                                      while_72_continue: /* CIL Label */ ;
#line 3891
                                                                                      old_buffer___13 = bufp->buffer;
#line 3891
                                                                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 3891
                                                                                      bufp->allocated <<= 1;
#line 3891
                                                                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 3891
                                                                                        bufp->allocated = (unsigned long )(1L << 16);
                                                                                      }
                                                                                      {
#line 3891
                                                                                      tmp___509 = __dyc_funcallvar_157;
#line 3891
                                                                                      bufp->buffer = (unsigned char *)tmp___509;
                                                                                      }
#line 3891
                                                                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 3891
                                                                                      if ((unsigned long )old_buffer___13 != (unsigned long )bufp->buffer) {
#line 3891
                                                                                        incr___13 = (ptrdiff_t )(bufp->buffer - old_buffer___13);
#line 3891
                                                                                        b += incr___13;
#line 3891
                                                                                        begalt += incr___13;
#line 3891
                                                                                        if (fixup_alt_jump) {
#line 3891
                                                                                          fixup_alt_jump += incr___13;
                                                                                        }
#line 3891
                                                                                        if (laststart) {
#line 3891
                                                                                          laststart += incr___13;
                                                                                        }
#line 3891
                                                                                        if (pending_exact) {
#line 3891
                                                                                          pending_exact += incr___13;
                                                                                        }
                                                                                      }
                                                                                      goto while_72_break;
                                                                                    }
                                                                                    while_72_break: /* CIL Label */ ;
                                                                                    }
                                                                                  }
                                                                                  while_71_break: /* CIL Label */ ;
                                                                                  }
                                                                                  {

#line 3894
                                                                                  b += 3;
                                                                                  }
                                                                                } else {
#line 3909
                                                                                  nbytes = (unsigned int )(10 + (upper_bound > 1) * 10);
                                                                                  {
#line 3912
                                                                                  while (1) {
                                                                                    while_73_continue: /* CIL Label */ ;
#line 3912
                                                                                    if (! ((unsigned long )((unsigned int )(b - bufp->buffer) + nbytes) > bufp->allocated)) {
                                                                                      goto while_73_break;
                                                                                    }
                                                                                    {
#line 3912
                                                                                    while (1) {
                                                                                      while_74_continue: /* CIL Label */ ;
#line 3912
                                                                                      old_buffer___14 = bufp->buffer;
#line 3912
                                                                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 3912
                                                                                      bufp->allocated <<= 1;
#line 3912
                                                                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 3912
                                                                                        bufp->allocated = (unsigned long )(1L << 16);
                                                                                      }
                                                                                      {
#line 3912
                                                                                      tmp___510 = __dyc_funcallvar_158;
#line 3912
                                                                                      bufp->buffer = (unsigned char *)tmp___510;
                                                                                      }
#line 3912
                                                                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 3912
                                                                                      if ((unsigned long )old_buffer___14 != (unsigned long )bufp->buffer) {
#line 3912
                                                                                        incr___14 = (ptrdiff_t )(bufp->buffer - old_buffer___14);
#line 3912
                                                                                        b += incr___14;
#line 3912
                                                                                        begalt += incr___14;
#line 3912
                                                                                        if (fixup_alt_jump) {
#line 3912
                                                                                          fixup_alt_jump += incr___14;
                                                                                        }
#line 3912
                                                                                        if (laststart) {
#line 3912
                                                                                          laststart += incr___14;
                                                                                        }
#line 3912
                                                                                        if (pending_exact) {
#line 3912
                                                                                          pending_exact += incr___14;
                                                                                        }
                                                                                      }
                                                                                      goto while_74_break;
                                                                                    }
                                                                                    while_74_break: /* CIL Label */ ;
                                                                                    }
                                                                                  }
                                                                                  while_73_break: /* CIL Label */ ;
                                                                                  }
                                                                                  {

#line 3923
                                                                                  b += 5;

#line 3934
                                                                                  b += 5;
                                                                                  }
#line 3936
                                                                                  if (upper_bound > 1) {
                                                                                    {

#line 3947
                                                                                    b += 5;

#line 3966
                                                                                    b += 5;
                                                                                    }
                                                                                  }
                                                                                }
#line 3969
                                                                                pending_exact = (unsigned char *)0;
                                                                                goto switch_52_break;
                                                                                invalid_interval: 
#line 3973
                                                                                if (! (syntax & (((((((((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1))) {
                                                                                  {

                                                                                  }
#line 3974
                                                                                  if ((unsigned long )p == (unsigned long )pend) {
#line 3974
                                                                                    tmp___511 = 9;
                                                                                  } else {
#line 3974
                                                                                    tmp___511 = 10;
                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                }
                                                                                unfetch_interval: 
#line 3977
                                                                                p = beg_interval;
#line 3978
                                                                                c = (unsigned char )'{';
#line 3979
                                                                                if (syntax & ((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_char;
                                                                                } else {
                                                                                  goto normal_backslash;
                                                                                }
                                                                                switch_52_119: /* CIL Label */ 
#line 4007
                                                                                if (syntax & (((((((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_char;
                                                                                }
#line 4009
                                                                                laststart = b;
                                                                                {
#line 4010
                                                                                while (1) {
                                                                                  while_75_continue: /* CIL Label */ ;
                                                                                  {
#line 4010
                                                                                  while (1) {
                                                                                    while_76_continue: /* CIL Label */ ;
#line 4010
                                                                                    if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                                                                      goto while_76_break;
                                                                                    }
                                                                                    {
#line 4010
                                                                                    while (1) {
                                                                                      while_77_continue: /* CIL Label */ ;
#line 4010
                                                                                      old_buffer___15 = bufp->buffer;
#line 4010
                                                                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4010
                                                                                      bufp->allocated <<= 1;
#line 4010
                                                                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 4010
                                                                                        bufp->allocated = (unsigned long )(1L << 16);
                                                                                      }
                                                                                      {
#line 4010
                                                                                      tmp___512 = __dyc_funcallvar_159;
#line 4010
                                                                                      bufp->buffer = (unsigned char *)tmp___512;
                                                                                      }
#line 4010
                                                                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4010
                                                                                      if ((unsigned long )old_buffer___15 != (unsigned long )bufp->buffer) {
#line 4010
                                                                                        incr___15 = (ptrdiff_t )(bufp->buffer - old_buffer___15);
#line 4010
                                                                                        b += incr___15;
#line 4010
                                                                                        begalt += incr___15;
#line 4010
                                                                                        if (fixup_alt_jump) {
#line 4010
                                                                                          fixup_alt_jump += incr___15;
                                                                                        }
#line 4010
                                                                                        if (laststart) {
#line 4010
                                                                                          laststart += incr___15;
                                                                                        }
#line 4010
                                                                                        if (pending_exact) {
#line 4010
                                                                                          pending_exact += incr___15;
                                                                                        }
                                                                                      }
                                                                                      goto while_77_break;
                                                                                    }
                                                                                    while_77_break: /* CIL Label */ ;
                                                                                    }
                                                                                  }
                                                                                  while_76_break: /* CIL Label */ ;
                                                                                  }
#line 4010
                                                                                  tmp___513 = b;
#line 4010
                                                                                  b ++;
#line 4010
                                                                                  *tmp___513 = (unsigned char)24;
                                                                                  goto while_75_break;
                                                                                }
                                                                                while_75_break: /* CIL Label */ ;
                                                                                }
                                                                                goto switch_52_break;
                                                                                switch_52_87: /* CIL Label */ 
#line 4015
                                                                                if (syntax & (((((((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_char;
                                                                                }
#line 4017
                                                                                laststart = b;
                                                                                {
#line 4018
                                                                                while (1) {
                                                                                  while_78_continue: /* CIL Label */ ;
                                                                                  {
#line 4018
                                                                                  while (1) {
                                                                                    while_79_continue: /* CIL Label */ ;
#line 4018
                                                                                    if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                                                                      goto while_79_break;
                                                                                    }
                                                                                    {
#line 4018
                                                                                    while (1) {
                                                                                      while_80_continue: /* CIL Label */ ;
#line 4018
                                                                                      old_buffer___16 = bufp->buffer;
#line 4018
                                                                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4018
                                                                                      bufp->allocated <<= 1;
#line 4018
                                                                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 4018
                                                                                        bufp->allocated = (unsigned long )(1L << 16);
                                                                                      }
                                                                                      {
#line 4018
                                                                                      tmp___514 = __dyc_funcallvar_160;
#line 4018
                                                                                      bufp->buffer = (unsigned char *)tmp___514;
                                                                                      }
#line 4018
                                                                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4018
                                                                                      if ((unsigned long )old_buffer___16 != (unsigned long )bufp->buffer) {
#line 4018
                                                                                        incr___16 = (ptrdiff_t )(bufp->buffer - old_buffer___16);
#line 4018
                                                                                        b += incr___16;
#line 4018
                                                                                        begalt += incr___16;
#line 4018
                                                                                        if (fixup_alt_jump) {
#line 4018
                                                                                          fixup_alt_jump += incr___16;
                                                                                        }
#line 4018
                                                                                        if (laststart) {
#line 4018
                                                                                          laststart += incr___16;
                                                                                        }
#line 4018
                                                                                        if (pending_exact) {
#line 4018
                                                                                          pending_exact += incr___16;
                                                                                        }
                                                                                      }
                                                                                      goto while_80_break;
                                                                                    }
                                                                                    while_80_break: /* CIL Label */ ;
                                                                                    }
                                                                                  }
                                                                                  while_79_break: /* CIL Label */ ;
                                                                                  }
#line 4018
                                                                                  tmp___515 = b;
#line 4018
                                                                                  b ++;
#line 4018
                                                                                  *tmp___515 = (unsigned char)25;
                                                                                  goto while_78_break;
                                                                                }
                                                                                while_78_break: /* CIL Label */ ;
                                                                                }
                                                                                goto switch_52_break;
                                                                                switch_52_60: /* CIL Label */ 
#line 4023
                                                                                if (syntax & (((((((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_char;
                                                                                }
                                                                                {
#line 4025
                                                                                while (1) {
                                                                                  while_81_continue: /* CIL Label */ ;
                                                                                  {
#line 4025
                                                                                  while (1) {
                                                                                    while_82_continue: /* CIL Label */ ;
#line 4025
                                                                                    if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                                                                      goto while_82_break;
                                                                                    }
                                                                                    {
#line 4025
                                                                                    while (1) {
                                                                                      while_83_continue: /* CIL Label */ ;
#line 4025
                                                                                      old_buffer___17 = bufp->buffer;
#line 4025
                                                                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4025
                                                                                      bufp->allocated <<= 1;
#line 4025
                                                                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 4025
                                                                                        bufp->allocated = (unsigned long )(1L << 16);
                                                                                      }
                                                                                      {
#line 4025
                                                                                      tmp___516 = __dyc_funcallvar_161;
#line 4025
                                                                                      bufp->buffer = (unsigned char *)tmp___516;
                                                                                      }
#line 4025
                                                                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4025
                                                                                      if ((unsigned long )old_buffer___17 != (unsigned long )bufp->buffer) {
#line 4025
                                                                                        incr___17 = (ptrdiff_t )(bufp->buffer - old_buffer___17);
#line 4025
                                                                                        b += incr___17;
#line 4025
                                                                                        begalt += incr___17;
#line 4025
                                                                                        if (fixup_alt_jump) {
#line 4025
                                                                                          fixup_alt_jump += incr___17;
                                                                                        }
#line 4025
                                                                                        if (laststart) {
#line 4025
                                                                                          laststart += incr___17;
                                                                                        }
#line 4025
                                                                                        if (pending_exact) {
#line 4025
                                                                                          pending_exact += incr___17;
                                                                                        }
                                                                                      }
                                                                                      goto while_83_break;
                                                                                    }
                                                                                    while_83_break: /* CIL Label */ ;
                                                                                    }
                                                                                  }
                                                                                  while_82_break: /* CIL Label */ ;
                                                                                  }
#line 4025
                                                                                  tmp___517 = b;
#line 4025
                                                                                  b ++;
#line 4025
                                                                                  *tmp___517 = (unsigned char)26;
                                                                                  goto while_81_break;
                                                                                }
                                                                                while_81_break: /* CIL Label */ ;
                                                                                }
                                                                                goto switch_52_break;
                                                                                switch_52_62: /* CIL Label */ 
#line 4029
                                                                                if (syntax & (((((((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_char;
                                                                                }
                                                                                {
#line 4031
                                                                                while (1) {
                                                                                  while_84_continue: /* CIL Label */ ;
                                                                                  {
#line 4031
                                                                                  while (1) {
                                                                                    while_85_continue: /* CIL Label */ ;
#line 4031
                                                                                    if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                                                                      goto while_85_break;
                                                                                    }
                                                                                    {
#line 4031
                                                                                    while (1) {
                                                                                      while_86_continue: /* CIL Label */ ;
#line 4031
                                                                                      old_buffer___18 = bufp->buffer;
#line 4031
                                                                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4031
                                                                                      bufp->allocated <<= 1;
#line 4031
                                                                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 4031
                                                                                        bufp->allocated = (unsigned long )(1L << 16);
                                                                                      }
                                                                                      {
#line 4031
                                                                                      tmp___518 = __dyc_funcallvar_162;
#line 4031
                                                                                      bufp->buffer = (unsigned char *)tmp___518;
                                                                                      }
#line 4031
                                                                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4031
                                                                                      if ((unsigned long )old_buffer___18 != (unsigned long )bufp->buffer) {
#line 4031
                                                                                        incr___18 = (ptrdiff_t )(bufp->buffer - old_buffer___18);
#line 4031
                                                                                        b += incr___18;
#line 4031
                                                                                        begalt += incr___18;
#line 4031
                                                                                        if (fixup_alt_jump) {
#line 4031
                                                                                          fixup_alt_jump += incr___18;
                                                                                        }
#line 4031
                                                                                        if (laststart) {
#line 4031
                                                                                          laststart += incr___18;
                                                                                        }
#line 4031
                                                                                        if (pending_exact) {
#line 4031
                                                                                          pending_exact += incr___18;
                                                                                        }
                                                                                      }
                                                                                      goto while_86_break;
                                                                                    }
                                                                                    while_86_break: /* CIL Label */ ;
                                                                                    }
                                                                                  }
                                                                                  while_85_break: /* CIL Label */ ;
                                                                                  }
#line 4031
                                                                                  tmp___519 = b;
#line 4031
                                                                                  b ++;
#line 4031
                                                                                  *tmp___519 = (unsigned char)27;
                                                                                  goto while_84_break;
                                                                                }
                                                                                while_84_break: /* CIL Label */ ;
                                                                                }
                                                                                goto switch_52_break;
                                                                                switch_52_98: /* CIL Label */ 
#line 4035
                                                                                if (syntax & (((((((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_char;
                                                                                }
                                                                                {
#line 4037
                                                                                while (1) {
                                                                                  while_87_continue: /* CIL Label */ ;
                                                                                  {
#line 4037
                                                                                  while (1) {
                                                                                    while_88_continue: /* CIL Label */ ;
#line 4037
                                                                                    if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                                                                      goto while_88_break;
                                                                                    }
                                                                                    {
#line 4037
                                                                                    while (1) {
                                                                                      while_89_continue: /* CIL Label */ ;
#line 4037
                                                                                      old_buffer___19 = bufp->buffer;
#line 4037
                                                                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4037
                                                                                      bufp->allocated <<= 1;
#line 4037
                                                                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 4037
                                                                                        bufp->allocated = (unsigned long )(1L << 16);
                                                                                      }
                                                                                      {
#line 4037
                                                                                      tmp___520 = __dyc_funcallvar_163;
#line 4037
                                                                                      bufp->buffer = (unsigned char *)tmp___520;
                                                                                      }
#line 4037
                                                                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4037
                                                                                      if ((unsigned long )old_buffer___19 != (unsigned long )bufp->buffer) {
#line 4037
                                                                                        incr___19 = (ptrdiff_t )(bufp->buffer - old_buffer___19);
#line 4037
                                                                                        b += incr___19;
#line 4037
                                                                                        begalt += incr___19;
#line 4037
                                                                                        if (fixup_alt_jump) {
#line 4037
                                                                                          fixup_alt_jump += incr___19;
                                                                                        }
#line 4037
                                                                                        if (laststart) {
#line 4037
                                                                                          laststart += incr___19;
                                                                                        }
#line 4037
                                                                                        if (pending_exact) {
#line 4037
                                                                                          pending_exact += incr___19;
                                                                                        }
                                                                                      }
                                                                                      goto while_89_break;
                                                                                    }
                                                                                    while_89_break: /* CIL Label */ ;
                                                                                    }
                                                                                  }
                                                                                  while_88_break: /* CIL Label */ ;
                                                                                  }
#line 4037
                                                                                  tmp___521 = b;
#line 4037
                                                                                  b ++;
#line 4037
                                                                                  *tmp___521 = (unsigned char)28;
                                                                                  goto while_87_break;
                                                                                }
                                                                                while_87_break: /* CIL Label */ ;
                                                                                }
                                                                                goto switch_52_break;
                                                                                switch_52_66: /* CIL Label */ 
#line 4041
                                                                                if (syntax & (((((((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_char;
                                                                                }
                                                                                {
#line 4043
                                                                                while (1) {
                                                                                  while_90_continue: /* CIL Label */ ;
                                                                                  {
#line 4043
                                                                                  while (1) {
                                                                                    while_91_continue: /* CIL Label */ ;
#line 4043
                                                                                    if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                                                                      goto while_91_break;
                                                                                    }
                                                                                    {
#line 4043
                                                                                    while (1) {
                                                                                      while_92_continue: /* CIL Label */ ;
#line 4043
                                                                                      old_buffer___20 = bufp->buffer;
#line 4043
                                                                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4043
                                                                                      bufp->allocated <<= 1;
#line 4043
                                                                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 4043
                                                                                        bufp->allocated = (unsigned long )(1L << 16);
                                                                                      }
                                                                                      {
#line 4043
                                                                                      tmp___522 = __dyc_funcallvar_164;
#line 4043
                                                                                      bufp->buffer = (unsigned char *)tmp___522;
                                                                                      }
#line 4043
                                                                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4043
                                                                                      if ((unsigned long )old_buffer___20 != (unsigned long )bufp->buffer) {
#line 4043
                                                                                        incr___20 = (ptrdiff_t )(bufp->buffer - old_buffer___20);
#line 4043
                                                                                        b += incr___20;
#line 4043
                                                                                        begalt += incr___20;
#line 4043
                                                                                        if (fixup_alt_jump) {
#line 4043
                                                                                          fixup_alt_jump += incr___20;
                                                                                        }
#line 4043
                                                                                        if (laststart) {
#line 4043
                                                                                          laststart += incr___20;
                                                                                        }
#line 4043
                                                                                        if (pending_exact) {
#line 4043
                                                                                          pending_exact += incr___20;
                                                                                        }
                                                                                      }
                                                                                      goto while_92_break;
                                                                                    }
                                                                                    while_92_break: /* CIL Label */ ;
                                                                                    }
                                                                                  }
                                                                                  while_91_break: /* CIL Label */ ;
                                                                                  }
#line 4043
                                                                                  tmp___523 = b;
#line 4043
                                                                                  b ++;
#line 4043
                                                                                  *tmp___523 = (unsigned char)29;
                                                                                  goto while_90_break;
                                                                                }
                                                                                while_90_break: /* CIL Label */ ;
                                                                                }
                                                                                goto switch_52_break;
                                                                                switch_52_96: /* CIL Label */ 
#line 4047
                                                                                if (syntax & (((((((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_char;
                                                                                }
                                                                                {
#line 4049
                                                                                while (1) {
                                                                                  while_93_continue: /* CIL Label */ ;
                                                                                  {
#line 4049
                                                                                  while (1) {
                                                                                    while_94_continue: /* CIL Label */ ;
#line 4049
                                                                                    if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                                                                      goto while_94_break;
                                                                                    }
                                                                                    {
#line 4049
                                                                                    while (1) {
                                                                                      while_95_continue: /* CIL Label */ ;
#line 4049
                                                                                      old_buffer___21 = bufp->buffer;
#line 4049
                                                                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4049
                                                                                      bufp->allocated <<= 1;
#line 4049
                                                                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 4049
                                                                                        bufp->allocated = (unsigned long )(1L << 16);
                                                                                      }
                                                                                      {
#line 4049
                                                                                      tmp___524 = __dyc_funcallvar_165;
#line 4049
                                                                                      bufp->buffer = (unsigned char *)tmp___524;
                                                                                      }
#line 4049
                                                                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4049
                                                                                      if ((unsigned long )old_buffer___21 != (unsigned long )bufp->buffer) {
#line 4049
                                                                                        incr___21 = (ptrdiff_t )(bufp->buffer - old_buffer___21);
#line 4049
                                                                                        b += incr___21;
#line 4049
                                                                                        begalt += incr___21;
#line 4049
                                                                                        if (fixup_alt_jump) {
#line 4049
                                                                                          fixup_alt_jump += incr___21;
                                                                                        }
#line 4049
                                                                                        if (laststart) {
#line 4049
                                                                                          laststart += incr___21;
                                                                                        }
#line 4049
                                                                                        if (pending_exact) {
#line 4049
                                                                                          pending_exact += incr___21;
                                                                                        }
                                                                                      }
                                                                                      goto while_95_break;
                                                                                    }
                                                                                    while_95_break: /* CIL Label */ ;
                                                                                    }
                                                                                  }
                                                                                  while_94_break: /* CIL Label */ ;
                                                                                  }
#line 4049
                                                                                  tmp___525 = b;
#line 4049
                                                                                  b ++;
#line 4049
                                                                                  *tmp___525 = (unsigned char)11;
                                                                                  goto while_93_break;
                                                                                }
                                                                                while_93_break: /* CIL Label */ ;
                                                                                }
                                                                                goto switch_52_break;
                                                                                switch_52_39: /* CIL Label */ 
#line 4053
                                                                                if (syntax & (((((((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_char;
                                                                                }
                                                                                {
#line 4055
                                                                                while (1) {
                                                                                  while_96_continue: /* CIL Label */ ;
                                                                                  {
#line 4055
                                                                                  while (1) {
                                                                                    while_97_continue: /* CIL Label */ ;
#line 4055
                                                                                    if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                                                                      goto while_97_break;
                                                                                    }
                                                                                    {
#line 4055
                                                                                    while (1) {
                                                                                      while_98_continue: /* CIL Label */ ;
#line 4055
                                                                                      old_buffer___22 = bufp->buffer;
#line 4055
                                                                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4055
                                                                                      bufp->allocated <<= 1;
#line 4055
                                                                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 4055
                                                                                        bufp->allocated = (unsigned long )(1L << 16);
                                                                                      }
                                                                                      {
#line 4055
                                                                                      tmp___526 = __dyc_funcallvar_166;
#line 4055
                                                                                      bufp->buffer = (unsigned char *)tmp___526;
                                                                                      }
#line 4055
                                                                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4055
                                                                                      if ((unsigned long )old_buffer___22 != (unsigned long )bufp->buffer) {
#line 4055
                                                                                        incr___22 = (ptrdiff_t )(bufp->buffer - old_buffer___22);
#line 4055
                                                                                        b += incr___22;
#line 4055
                                                                                        begalt += incr___22;
#line 4055
                                                                                        if (fixup_alt_jump) {
#line 4055
                                                                                          fixup_alt_jump += incr___22;
                                                                                        }
#line 4055
                                                                                        if (laststart) {
#line 4055
                                                                                          laststart += incr___22;
                                                                                        }
#line 4055
                                                                                        if (pending_exact) {
#line 4055
                                                                                          pending_exact += incr___22;
                                                                                        }
                                                                                      }
                                                                                      goto while_98_break;
                                                                                    }
                                                                                    while_98_break: /* CIL Label */ ;
                                                                                    }
                                                                                  }
                                                                                  while_97_break: /* CIL Label */ ;
                                                                                  }
#line 4055
                                                                                  tmp___527 = b;
#line 4055
                                                                                  b ++;
#line 4055
                                                                                  *tmp___527 = (unsigned char)12;
                                                                                  goto while_96_break;
                                                                                }
                                                                                while_96_break: /* CIL Label */ ;
                                                                                }
                                                                                goto switch_52_break;
                                                                                switch_52_49: /* CIL Label */ 
                                                                                switch_52_50: /* CIL Label */ 
                                                                                switch_52_51: /* CIL Label */ 
                                                                                switch_52_52: /* CIL Label */ 
                                                                                switch_52_53: /* CIL Label */ 
                                                                                switch_52_54: /* CIL Label */ 
                                                                                switch_52_55: /* CIL Label */ 
                                                                                switch_52_56: /* CIL Label */ 
                                                                                switch_52_57: /* CIL Label */ 
#line 4060
                                                                                if (syntax & ((((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
                                                                                  goto normal_char;
                                                                                }
#line 4063
                                                                                c1 = (unsigned char )((int )c - 48);
#line 4065
                                                                                if ((regnum_t )c1 > regnum) {
                                                                                  {

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                }
                                                                                {
#line 4069
                                                                                tmp___528 = __dyc_funcallvar_167;
                                                                                }
#line 4069
                                                                                if (tmp___528) {
                                                                                  goto normal_char;
                                                                                }
#line 4072
                                                                                laststart = b;
                                                                                {
#line 4073
                                                                                while (1) {
                                                                                  while_99_continue: /* CIL Label */ ;
                                                                                  {
#line 4073
                                                                                  while (1) {
                                                                                    while_100_continue: /* CIL Label */ ;
#line 4073
                                                                                    if (! ((unsigned long )((b - bufp->buffer) + 2) > bufp->allocated)) {
                                                                                      goto while_100_break;
                                                                                    }
                                                                                    {
#line 4073
                                                                                    while (1) {
                                                                                      while_101_continue: /* CIL Label */ ;
#line 4073
                                                                                      old_buffer___23 = bufp->buffer;
#line 4073
                                                                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4073
                                                                                      bufp->allocated <<= 1;
#line 4073
                                                                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 4073
                                                                                        bufp->allocated = (unsigned long )(1L << 16);
                                                                                      }
                                                                                      {
#line 4073
                                                                                      tmp___529 = __dyc_funcallvar_168;
#line 4073
                                                                                      bufp->buffer = (unsigned char *)tmp___529;
                                                                                      }
#line 4073
                                                                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                                                        goto __dyc_dummy_label;
                                                                                      }
#line 4073
                                                                                      if ((unsigned long )old_buffer___23 != (unsigned long )bufp->buffer) {
#line 4073
                                                                                        incr___23 = (ptrdiff_t )(bufp->buffer - old_buffer___23);
#line 4073
                                                                                        b += incr___23;
#line 4073
                                                                                        begalt += incr___23;
#line 4073
                                                                                        if (fixup_alt_jump) {
#line 4073
                                                                                          fixup_alt_jump += incr___23;
                                                                                        }
#line 4073
                                                                                        if (laststart) {
#line 4073
                                                                                          laststart += incr___23;
                                                                                        }
#line 4073
                                                                                        if (pending_exact) {
#line 4073
                                                                                          pending_exact += incr___23;
                                                                                        }
                                                                                      }
                                                                                      goto while_101_break;
                                                                                    }
                                                                                    while_101_break: /* CIL Label */ ;
                                                                                    }
                                                                                  }
                                                                                  while_100_break: /* CIL Label */ ;
                                                                                  }
#line 4073
                                                                                  tmp___530 = b;
#line 4073
                                                                                  b ++;
#line 4073
                                                                                  *tmp___530 = (unsigned char)8;
#line 4073
                                                                                  tmp___531 = b;
#line 4073
                                                                                  b ++;
#line 4073
                                                                                  *tmp___531 = c1;
                                                                                  goto while_99_break;
                                                                                }
                                                                                while_99_break: /* CIL Label */ ;
                                                                                }
                                                                                goto switch_52_break;
                                                                                switch_52_43: /* CIL Label */ 
                                                                                switch_52_63: /* CIL Label */ 
#line 4079
                                                                                if (syntax & (1UL << 1)) {
                                                                                  goto handle_plus;
                                                                                } else {
                                                                                  goto normal_backslash;
                                                                                }
                                                                                switch_52_default: /* CIL Label */ ;
                                                                                normal_backslash: 
#line 4089
                                                                                if (translate) {
#line 4089
                                                                                  c = (unsigned char )*(translate + c);
                                                                                } else {
#line 4089
                                                                                  c = (unsigned char )((char )c);
                                                                                }
                                                                                goto normal_char;
                                                                              } else {
                                                                                switch_52_break: /* CIL Label */ ;
                                                                              }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                                goto switch_3_break;
                                switch_3_default: /* CIL Label */ ;
                                normal_char: 
#line 4099
                                if (! pending_exact) {
                                  goto _L___80;
                                } else {
#line 4099
                                  if ((unsigned long )((pending_exact + (int )*pending_exact) + 1) != (unsigned long )b) {
                                    goto _L___80;
                                  } else {
#line 4099
                                    if ((int )*pending_exact == (1 << 8) - 1) {
                                      goto _L___80;
                                    } else {
#line 4099
                                      if ((int const   )*p == 42) {
                                        goto _L___80;
                                      } else {
#line 4099
                                        if ((int const   )*p == 94) {
                                          goto _L___80;
                                        } else {
#line 4099
                                          if (syntax & (1UL << 1)) {
#line 4099
                                            if ((int const   )*p == 92) {
#line 4099
                                              if ((int const   )*(p + 1) == 43) {
#line 4099
                                                tmp___538 = 1;
                                              } else {
#line 4099
                                                if ((int const   )*(p + 1) == 63) {
#line 4099
                                                  tmp___538 = 1;
                                                } else {
#line 4099
                                                  tmp___538 = 0;
                                                }
                                              }
                                            } else {
#line 4099
                                              tmp___538 = 0;
                                            }
#line 4099
                                            tmp___537 = tmp___538;
                                          } else {
#line 4099
                                            if ((int const   )*p == 43) {
#line 4099
                                              tmp___539 = 1;
                                            } else {
#line 4099
                                              if ((int const   )*p == 63) {
#line 4099
                                                tmp___539 = 1;
                                              } else {
#line 4099
                                                tmp___539 = 0;
                                              }
                                            }
#line 4099
                                            tmp___537 = tmp___539;
                                          }
#line 4099
                                          if (tmp___537) {
                                            goto _L___80;
                                          } else {
#line 4099
                                            if (syntax & (((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
#line 4099
                                              if (syntax & ((((((((((((1UL << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1) << 1)) {
#line 4099
                                                tmp___541 = (int const   )*p == 123;
                                              } else {
#line 4099
                                                if ((int const   )*(p + 0) == 92) {
#line 4099
                                                  if ((int const   )*(p + 1) == 123) {
#line 4099
                                                    tmp___542 = 1;
                                                  } else {
#line 4099
                                                    tmp___542 = 0;
                                                  }
                                                } else {
#line 4099
                                                  tmp___542 = 0;
                                                }
#line 4099
                                                tmp___541 = tmp___542;
                                              }
#line 4099
                                              if (tmp___541) {
                                                _L___80: /* CIL Label */ 
#line 4124
                                                laststart = b;
                                                {
#line 4134
                                                while (1) {
                                                  while_102_continue: /* CIL Label */ ;
                                                  {
#line 4134
                                                  while (1) {
                                                    while_103_continue: /* CIL Label */ ;
#line 4134
                                                    if (! ((unsigned long )((b - bufp->buffer) + 2) > bufp->allocated)) {
                                                      goto while_103_break;
                                                    }
                                                    {
#line 4134
                                                    while (1) {
                                                      while_104_continue: /* CIL Label */ ;
#line 4134
                                                      old_buffer___24 = bufp->buffer;
#line 4134
                                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                                        goto __dyc_dummy_label;
                                                      }
#line 4134
                                                      bufp->allocated <<= 1;
#line 4134
                                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 4134
                                                        bufp->allocated = (unsigned long )(1L << 16);
                                                      }
                                                      {
#line 4134
                                                      tmp___532 = __dyc_funcallvar_169;
#line 4134
                                                      bufp->buffer = (unsigned char *)tmp___532;
                                                      }
#line 4134
                                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                                        goto __dyc_dummy_label;
                                                      }
#line 4134
                                                      if ((unsigned long )old_buffer___24 != (unsigned long )bufp->buffer) {
#line 4134
                                                        incr___24 = (ptrdiff_t )(bufp->buffer - old_buffer___24);
#line 4134
                                                        b += incr___24;
#line 4134
                                                        begalt += incr___24;
#line 4134
                                                        if (fixup_alt_jump) {
#line 4134
                                                          fixup_alt_jump += incr___24;
                                                        }
#line 4134
                                                        if (laststart) {
#line 4134
                                                          laststart += incr___24;
                                                        }
#line 4134
                                                        if (pending_exact) {
#line 4134
                                                          pending_exact += incr___24;
                                                        }
                                                      }
                                                      goto while_104_break;
                                                    }
                                                    while_104_break: /* CIL Label */ ;
                                                    }
                                                  }
                                                  while_103_break: /* CIL Label */ ;
                                                  }
#line 4134
                                                  tmp___533 = b;
#line 4134
                                                  b ++;
#line 4134
                                                  *tmp___533 = (unsigned char)2;
#line 4134
                                                  tmp___534 = b;
#line 4134
                                                  b ++;
#line 4134
                                                  *tmp___534 = (unsigned char)0;
                                                  goto while_102_break;
                                                }
                                                while_102_break: /* CIL Label */ ;
                                                }
#line 4136
                                                pending_exact = b - 1;
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                                {
#line 4139
                                while (1) {
                                  while_105_continue: /* CIL Label */ ;
                                  {
#line 4139
                                  while (1) {
                                    while_106_continue: /* CIL Label */ ;
#line 4139
                                    if (! ((unsigned long )((b - bufp->buffer) + 1) > bufp->allocated)) {
                                      goto while_106_break;
                                    }
                                    {
#line 4139
                                    while (1) {
                                      while_107_continue: /* CIL Label */ ;
#line 4139
                                      old_buffer___25 = bufp->buffer;
#line 4139
                                      if (bufp->allocated == (unsigned long )(1L << 16)) {
                                        goto __dyc_dummy_label;
                                      }
#line 4139
                                      bufp->allocated <<= 1;
#line 4139
                                      if (bufp->allocated > (unsigned long )(1L << 16)) {
#line 4139
                                        bufp->allocated = (unsigned long )(1L << 16);
                                      }
                                      {
#line 4139
                                      tmp___543 = __dyc_funcallvar_170;
#line 4139
                                      bufp->buffer = (unsigned char *)tmp___543;
                                      }
#line 4139
                                      if ((unsigned long )bufp->buffer == (unsigned long )((void *)0)) {
                                        goto __dyc_dummy_label;
                                      }
#line 4139
                                      if ((unsigned long )old_buffer___25 != (unsigned long )bufp->buffer) {
#line 4139
                                        incr___25 = (ptrdiff_t )(bufp->buffer - old_buffer___25);
#line 4139
                                        b += incr___25;
#line 4139
                                        begalt += incr___25;
#line 4139
                                        if (fixup_alt_jump) {
#line 4139
                                          fixup_alt_jump += incr___25;
                                        }
#line 4139
                                        if (laststart) {
#line 4139
                                          laststart += incr___25;
                                        }
#line 4139
                                        if (pending_exact) {
#line 4139
                                          pending_exact += incr___25;
                                        }
                                      }
                                      goto while_107_break;
                                    }
                                    while_107_break: /* CIL Label */ ;
                                    }
                                  }
                                  while_106_break: /* CIL Label */ ;
                                  }
#line 4139
                                  tmp___544 = b;
#line 4139
                                  b ++;
#line 4139
                                  *tmp___544 = c;
                                  goto while_105_break;
                                }
                                while_105_break: /* CIL Label */ ;
                                }
#line 4140
                                *pending_exact = (unsigned char )((int )*pending_exact + 1);
                                goto switch_3_break;
                              } else {
                                switch_3_break: /* CIL Label */ ;
                              }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(c);
  __dyc_printpre_byte(c1);
  __dyc_print_ptr__char(p1);
  __dyc_print_ptr__char(b);
  __dyc_print_comp_38__anonstruct_compile_stack_type_29(compile_stack);
  __dyc_print_ptr__char(p);
  __dyc_print_ptr__char(pending_exact);
  __dyc_print_ptr__char(laststart);
  __dyc_print_ptr__char(begalt);
  __dyc_print_ptr__char(fixup_alt_jump);
  __dyc_printpre_byte(regnum);
  __dyc_print_ptr__char(old_buffer);
  __dyc_print_ptr__char(old_buffer___0);
  __dyc_printpre_byte(keep_string_p);
  __dyc_printpre_byte(zero_times_ok);
  __dyc_printpre_byte(many_times_ok);
  __dyc_print_ptr__char(old_buffer___1);
  __dyc_print_ptr__char(old_buffer___2);
  __dyc_printpre_byte(tmp___17);
  __dyc_print_ptr__char(old_buffer___3);
  __dyc_print_ptr__char(old_buffer___4);
  __dyc_printpre_byte(had_char_class);
  __dyc_printpre_byte(range_start);
  __dyc_print_ptr__char(old_buffer___5);
  __dyc_print_ptr__char(old_buffer___6);
  __dyc_print_ptr__char(old_buffer___7);
  __dyc_printpre_byte(is_alnum);
  __dyc_printpre_byte(__s1_len);
  __dyc_printpre_byte(__s2_len);
  __dyc_printpre_byte(is_alpha);
  __dyc_printpre_byte(__s1_len___0);
  __dyc_printpre_byte(__s2_len___0);
  __dyc_printpre_byte(is_blank);
  __dyc_printpre_byte(__s1_len___1);
  __dyc_printpre_byte(__s2_len___1);
  __dyc_printpre_byte(is_cntrl);
  __dyc_printpre_byte(__s1_len___2);
  __dyc_printpre_byte(__s2_len___2);
  __dyc_printpre_byte(is_digit);
  __dyc_printpre_byte(__s1_len___3);
  __dyc_printpre_byte(__s2_len___3);
  __dyc_printpre_byte(is_graph);
  __dyc_printpre_byte(__s1_len___4);
  __dyc_printpre_byte(__s2_len___4);
  __dyc_printpre_byte(is_lower);
  __dyc_printpre_byte(__s1_len___5);
  __dyc_printpre_byte(__s2_len___5);
  __dyc_printpre_byte(is_print);
  __dyc_printpre_byte(__s1_len___6);
  __dyc_printpre_byte(__s2_len___6);
  __dyc_printpre_byte(is_punct);
  __dyc_printpre_byte(__s1_len___7);
  __dyc_printpre_byte(__s2_len___7);
  __dyc_printpre_byte(is_space);
  __dyc_printpre_byte(__s1_len___8);
  __dyc_printpre_byte(__s2_len___8);
  __dyc_printpre_byte(is_upper);
  __dyc_printpre_byte(__s1_len___9);
  __dyc_printpre_byte(__s2_len___9);
  __dyc_printpre_byte(is_xdigit);
  __dyc_printpre_byte(__s1_len___10);
  __dyc_printpre_byte(__s2_len___10);
  __dyc_printpre_byte(__s1_len___11);
  __dyc_printpre_byte(__s2_len___11);
  __dyc_printpre_byte(__s1_len___12);
  __dyc_printpre_byte(__s2_len___12);
  __dyc_printpre_byte(__s1_len___13);
  __dyc_printpre_byte(__s2_len___13);
  __dyc_printpre_byte(__s1_len___14);
  __dyc_printpre_byte(__s2_len___14);
  __dyc_printpre_byte(__s1_len___15);
  __dyc_printpre_byte(__s2_len___15);
  __dyc_printpre_byte(__s1_len___16);
  __dyc_printpre_byte(__s2_len___16);
  __dyc_printpre_byte(__s1_len___17);
  __dyc_printpre_byte(__s2_len___17);
  __dyc_printpre_byte(__s1_len___18);
  __dyc_printpre_byte(__s2_len___18);
  __dyc_printpre_byte(__s1_len___19);
  __dyc_printpre_byte(__s2_len___19);
  __dyc_printpre_byte(__s1_len___20);
  __dyc_printpre_byte(__s2_len___20);
  __dyc_printpre_byte(__s1_len___21);
  __dyc_printpre_byte(__s2_len___21);
  __dyc_printpre_byte(__s1_len___22);
  __dyc_printpre_byte(__s2_len___22);
  __dyc_print_ptr__char(old_buffer___8);
  __dyc_print_ptr__char(old_buffer___9);
  __dyc_print_ptr__char(old_buffer___10);
  __dyc_print_ptr__char(old_buffer___11);
  __dyc_print_ptr__char(old_buffer___12);
  __dyc_printpre_byte(lower_bound);
  __dyc_printpre_byte(upper_bound);
  __dyc_print_ptr__char(beg_interval);
  __dyc_print_ptr__char(old_buffer___13);
  __dyc_print_ptr__char(old_buffer___14);
  __dyc_printpre_byte(tmp___511);
  __dyc_print_ptr__char(old_buffer___15);
  __dyc_print_ptr__char(old_buffer___16);
  __dyc_print_ptr__char(old_buffer___17);
  __dyc_print_ptr__char(old_buffer___18);
  __dyc_print_ptr__char(old_buffer___19);
  __dyc_print_ptr__char(old_buffer___20);
  __dyc_print_ptr__char(old_buffer___21);
  __dyc_print_ptr__char(old_buffer___22);
  __dyc_print_ptr__char(old_buffer___23);
  __dyc_print_ptr__char(old_buffer___24);
  __dyc_print_ptr__char(old_buffer___25);
}
}
