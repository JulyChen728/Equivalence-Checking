#include <dycfoo.h>
#include "../lua_cjson.i.hd.c.h"
void __dyc_foo(void) 
{ int ch ;
  int tmp ;
  int tmp___0 ;
  int tmp___22 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___32 ;
  int tmp___37 ;
  int tmp___38 ;
  int tmp___39 ;
  int tmp___40 ;
  int tmp___64 ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___74 ;
  int tmp___79 ;
  int tmp___80 ;
  int tmp___81 ;
  int tmp___82 ;
  int tmp___106 ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___116 ;
  int tmp___121 ;
  int tmp___122 ;
  int tmp___123 ;
  int tmp___124 ;
  json_parse_t *json ;
  json_token_t *token ;
  int __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;

  {
  ch = __dyc_readpre_byte();
  json = __dyc_read_ptr__typdef_json_parse_t();
  token = __dyc_read_ptr__typdef_json_token_t();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  tmp = 0;
  tmp___0 = 0;
  tmp___22 = 0;
  __s1_len___0 = 0;
  __s2_len___0 = 0;
  tmp___32 = 0;
  tmp___37 = 0;
  tmp___38 = 0;
  tmp___39 = 0;
  tmp___40 = 0;
  tmp___64 = 0;
  __s1_len___2 = 0;
  __s2_len___2 = 0;
  tmp___74 = 0;
  tmp___79 = 0;
  tmp___80 = 0;
  tmp___81 = 0;
  tmp___82 = 0;
  tmp___106 = 0;
  __s1_len___4 = 0;
  __s2_len___4 = 0;
  tmp___116 = 0;
  tmp___121 = 0;
  tmp___122 = 0;
  tmp___123 = 0;
  tmp___124 = 0;
#line 1057
  if (48 <= ch) {
#line 1057
    if (ch <= 57) {
      _L___11: /* CIL Label */ 
#line 1058
      if (! (json->cfg)->decode_invalid_numbers) {
        {
#line 1058
        tmp = __dyc_funcallvar_1;
        }
#line 1058
        if (tmp) {
          {

          }
          goto __dyc_dummy_label;
        }
      }
      {

      }
      goto __dyc_dummy_label;
    } else {
      goto _L___12;
    }
  } else {
    _L___12: /* CIL Label */ 
#line 1064
    if (0) {
#line 1064
      if (0) {
        {
#line 1064
        tmp___122 = __dyc_funcallvar_2;
#line 1064
        __s1_len___4 = (unsigned long )tmp___122;
#line 1064
        tmp___123 = __dyc_funcallvar_3;
#line 1064
        __s2_len___4 = (unsigned long )tmp___123;
        }
#line 1064
        if (! ((unsigned long )((void const   *)(json->ptr + 1)) - (unsigned long )((void const   *)json->ptr) == 1UL)) {
          goto _L___10;
        } else {
#line 1064
          if (__s1_len___4 >= 4UL) {
            _L___10: /* CIL Label */ 
#line 1064
            if (! ((unsigned long )((void const   *)("true" + 1)) - (unsigned long )((void const   *)"true") == 1UL)) {
#line 1064
              tmp___124 = 1;
            } else {
#line 1064
              if (__s2_len___4 >= 4UL) {
#line 1064
                tmp___124 = 1;
              } else {
#line 1064
                tmp___124 = 0;
              }
            }
          } else {
#line 1064
            tmp___124 = 0;
          }
        }
#line 1064
        if (tmp___124) {
          {
#line 1064
          tmp___116 = __dyc_funcallvar_4;
          }
        } else {
          {
#line 1064
          tmp___121 = __dyc_funcallvar_5;
#line 1064
          tmp___116 = tmp___121;
          }
        }
      } else {
        {
#line 1064
        tmp___121 = __dyc_funcallvar_6;
#line 1064
        tmp___116 = tmp___121;
        }
      }
#line 1064
      tmp___106 = tmp___116;
    } else {
      {
#line 1064
      tmp___106 = __dyc_funcallvar_7;
      }
    }
#line 1064
    if (tmp___106) {
#line 1069
      if (0) {
#line 1069
        if (0) {
          {
#line 1069
          tmp___80 = __dyc_funcallvar_8;
#line 1069
          __s1_len___2 = (unsigned long )tmp___80;
#line 1069
          tmp___81 = __dyc_funcallvar_9;
#line 1069
          __s2_len___2 = (unsigned long )tmp___81;
          }
#line 1069
          if (! ((unsigned long )((void const   *)(json->ptr + 1)) - (unsigned long )((void const   *)json->ptr) == 1UL)) {
            goto _L___6;
          } else {
#line 1069
            if (__s1_len___2 >= 4UL) {
              _L___6: /* CIL Label */ 
#line 1069
              if (! ((unsigned long )((void const   *)("false" + 1)) - (unsigned long )((void const   *)"false") == 1UL)) {
#line 1069
                tmp___82 = 1;
              } else {
#line 1069
                if (__s2_len___2 >= 4UL) {
#line 1069
                  tmp___82 = 1;
                } else {
#line 1069
                  tmp___82 = 0;
                }
              }
            } else {
#line 1069
              tmp___82 = 0;
            }
          }
#line 1069
          if (tmp___82) {
            {
#line 1069
            tmp___74 = __dyc_funcallvar_10;
            }
          } else {
            {
#line 1069
            tmp___79 = __dyc_funcallvar_11;
#line 1069
            tmp___74 = tmp___79;
            }
          }
        } else {
          {
#line 1069
          tmp___79 = __dyc_funcallvar_12;
#line 1069
          tmp___74 = tmp___79;
          }
        }
#line 1069
        tmp___64 = tmp___74;
      } else {
        {
#line 1069
        tmp___64 = __dyc_funcallvar_13;
        }
      }
#line 1069
      if (tmp___64) {
#line 1074
        if (0) {
#line 1074
          if (0) {
            {
#line 1074
            tmp___38 = __dyc_funcallvar_14;
#line 1074
            __s1_len___0 = (unsigned long )tmp___38;
#line 1074
            tmp___39 = __dyc_funcallvar_15;
#line 1074
            __s2_len___0 = (unsigned long )tmp___39;
            }
#line 1074
            if (! ((unsigned long )((void const   *)(json->ptr + 1)) - (unsigned long )((void const   *)json->ptr) == 1UL)) {
              goto _L___2;
            } else {
#line 1074
              if (__s1_len___0 >= 4UL) {
                _L___2: /* CIL Label */ 
#line 1074
                if (! ((unsigned long )((void const   *)("null" + 1)) - (unsigned long )((void const   *)"null") == 1UL)) {
#line 1074
                  tmp___40 = 1;
                } else {
#line 1074
                  if (__s2_len___0 >= 4UL) {
#line 1074
                    tmp___40 = 1;
                  } else {
#line 1074
                    tmp___40 = 0;
                  }
                }
              } else {
#line 1074
                tmp___40 = 0;
              }
            }
#line 1074
            if (tmp___40) {
              {
#line 1074
              tmp___32 = __dyc_funcallvar_16;
              }
            } else {
              {
#line 1074
              tmp___37 = __dyc_funcallvar_17;
#line 1074
              tmp___32 = tmp___37;
              }
            }
          } else {
            {
#line 1074
            tmp___37 = __dyc_funcallvar_18;
#line 1074
            tmp___32 = tmp___37;
            }
          }
#line 1074
          tmp___22 = tmp___32;
        } else {
          {
#line 1074
          tmp___22 = __dyc_funcallvar_19;
          }
        }
#line 1074
        if (tmp___22) {
#line 1078
          if ((json->cfg)->decode_invalid_numbers) {
            {
#line 1078
            tmp___0 = __dyc_funcallvar_20;
            }
#line 1078
            if (tmp___0) {
              {

              }
              goto __dyc_dummy_label;
            }
          }
        } else {
#line 1075
          token->type = 7;
#line 1076
          json->ptr += 4;
          goto __dyc_dummy_label;
        }
      } else {
#line 1070
        token->type = 6;
#line 1071
        token->value.boolean = 0;
#line 1072
        json->ptr += 5;
        goto __dyc_dummy_label;
      }
    } else {
#line 1065
      token->type = 6;
#line 1066
      token->value.boolean = 1;
#line 1067
      json->ptr += 4;
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(__s1_len___0);
  __dyc_printpre_byte(__s2_len___0);
  __dyc_printpre_byte(__s1_len___2);
  __dyc_printpre_byte(__s2_len___2);
  __dyc_printpre_byte(__s1_len___4);
  __dyc_printpre_byte(__s2_len___4);
}
}
