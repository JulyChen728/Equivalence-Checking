#include <dycfoo.h>
#include "../lvm.i.hd.c.h"
void __dyc_foo(void) 
{ LClosure *cl ;
  StkId base ;
  TValue *k ;
  Instruction const   *pc ;
  Instruction i ;
  StkId ra ;
  TValue *rb ;
  TValue *tmp___0 ;
  int b ;
  TValue const   *o2___1 ;
  TValue *o1___1 ;
  TValue g ;
  TValue *rb___0 ;
  TValue *i_o___0 ;
  TValue *tmp___1 ;
  TValue g___0 ;
  TValue *i_o___1 ;
  UpVal *uv ;
  TValue const   *o2___2 ;
  TValue *o1___2 ;
  TValue *tmp___2 ;
  TValue *tmp___3 ;
  int b___0 ;
  int c ;
  TValue *i_o___2 ;
  int __attribute__((__visibility__("hidden")))  tmp___4 ;
  int __attribute__((__visibility__("hidden")))  tmp___5 ;
  Table __attribute__((__visibility__("hidden")))  *tmp___6 ;
  StkId rb___1 ;
  TValue const   *o2___3 ;
  TValue *o1___3 ;
  TValue *tmp___7 ;
  TValue *rb___2 ;
  TValue *tmp___8 ;
  TValue *rc ;
  TValue *tmp___9 ;
  lua_Number nb ;
  lua_Number nc ;
  TValue *i_o___3 ;
  TValue *rb___3 ;
  TValue *tmp___10 ;
  TValue *rc___0 ;
  TValue *tmp___11 ;
  lua_Number nb___0 ;
  lua_Number nc___0 ;
  TValue *i_o___4 ;
  TValue *rb___4 ;
  TValue *tmp___12 ;
  TValue *rc___1 ;
  TValue *tmp___13 ;
  lua_Number nb___1 ;
  lua_Number nc___1 ;
  TValue *i_o___5 ;
  TValue *rb___5 ;
  TValue *tmp___14 ;
  TValue *rc___2 ;
  TValue *tmp___15 ;
  lua_Number nb___2 ;
  lua_Number nc___2 ;
  TValue *i_o___6 ;
  TValue *rb___6 ;
  TValue *tmp___16 ;
  TValue *rc___3 ;
  TValue *tmp___17 ;
  lua_Number nb___3 ;
  lua_Number nc___3 ;
  TValue *i_o___7 ;
  double tmp___18 ;
  TValue *rb___7 ;
  TValue *tmp___19 ;
  TValue *rc___4 ;
  TValue *tmp___20 ;
  lua_Number nb___4 ;
  lua_Number nc___4 ;
  TValue *i_o___8 ;
  TValue *rb___8 ;
  lua_Number nb___5 ;
  TValue *i_o___9 ;
  int res ;
  int tmp___21 ;
  TValue *i_o___10 ;
  TValue const   *rb___9 ;
  TValue *i_o___11 ;
  int __attribute__((__visibility__("hidden")))  tmp___22 ;
  TValue *i_o___12 ;
  int tmp___23 ;
  int b___1 ;
  int c___0 ;
  TValue const   *o2___4 ;
  TValue *o1___4 ;
  TValue *rb___10 ;
  TValue *tmp___24 ;
  TValue *rc___5 ;
  TValue *tmp___25 ;
  int __attribute__((__visibility__("hidden")))  tmp___26 ;
  int tmp___27 ;
  TValue *tmp___28 ;
  TValue *tmp___29 ;
  int __attribute__((__visibility__("hidden")))  tmp___30 ;
  TValue *tmp___31 ;
  TValue *tmp___32 ;
  int tmp___33 ;
  int tmp___34 ;
  TValue *rb___11 ;
  TValue const   *o2___5 ;
  TValue *o1___5 ;
  int tmp___35 ;
  int b___2 ;
  int nresults ;
  int __attribute__((__visibility__("hidden")))  tmp___36 ;
  int b___3 ;
  int __attribute__((__visibility__("hidden")))  tmp___37 ;
  CallInfo *ci ;
  int aux ;
  StkId func ;
  StkId pfunc ;
  TValue const   *o2___6 ;
  TValue *o1___6 ;
  int b___4 ;
  int __attribute__((__visibility__("hidden")))  tmp___38 ;
  lua_Number step ;
  lua_Number idx ;
  lua_Number limit ;
  TValue *i_o___13 ;
  TValue *i_o___14 ;
  int tmp___39 ;
  TValue const   *init ;
  TValue const   *plimit ;
  TValue const   *pstep ;
  TValue const __attribute__((__visibility__("hidden")))  *tmp___40 ;
  TValue const __attribute__((__visibility__("hidden")))  *tmp___41 ;
  TValue const __attribute__((__visibility__("hidden")))  *tmp___42 ;
  lua_State *L ;
  int nexeccalls ;
  int __attribute__((__visibility__("hidden")))  __dyc_funcallvar_1 ;
  int __attribute__((__visibility__("hidden")))  __dyc_funcallvar_2 ;
  Table __attribute__((__visibility__("hidden")))  *__dyc_funcallvar_3 ;
  double __dyc_funcallvar_4 ;
  double __dyc_funcallvar_5 ;
  int __attribute__((__visibility__("hidden")))  __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __attribute__((__visibility__("hidden")))  __dyc_funcallvar_8 ;
  int __attribute__((__visibility__("hidden")))  __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __attribute__((__visibility__("hidden")))  __dyc_funcallvar_11 ;
  int __attribute__((__visibility__("hidden")))  __dyc_funcallvar_12 ;
  int __attribute__((__visibility__("hidden")))  __dyc_funcallvar_13 ;
  TValue const __attribute__((__visibility__("hidden")))  *__dyc_funcallvar_14 ;
  TValue const __attribute__((__visibility__("hidden")))  *__dyc_funcallvar_15 ;
  TValue const __attribute__((__visibility__("hidden")))  *__dyc_funcallvar_16 ;

  {
  cl = __dyc_read_ptr__typdef_LClosure();
  base = __dyc_read_ptr__typdef_TValue();
  k = __dyc_read_ptr__typdef_TValue();
  pc = (Instruction const   *)__dyc_read_ptr__typdef_Instruction();
  i = (Instruction )__dyc_readpre_byte();
  ra = __dyc_read_ptr__typdef_TValue();
  g = __dyc_read_comp_46lua_TValue();
  g___0 = __dyc_read_comp_46lua_TValue();
  L = __dyc_read_ptr__typdef_lua_State();
  nexeccalls = __dyc_readpre_byte();
  __dyc_funcallvar_1 = (int __attribute__((__visibility__("hidden")))  )__dyc_readpre_byte();
  __dyc_funcallvar_2 = (int __attribute__((__visibility__("hidden")))  )__dyc_readpre_byte();
  __dyc_funcallvar_3 = (Table __attribute__((__visibility__("hidden")))  *)__dyc_read_ptr__typdef_Table();
  __dyc_funcallvar_4 = (double )__dyc_readpre_byte();
  __dyc_funcallvar_5 = (double )__dyc_readpre_byte();
  __dyc_funcallvar_6 = (int __attribute__((__visibility__("hidden")))  )__dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = (int __attribute__((__visibility__("hidden")))  )__dyc_readpre_byte();
  __dyc_funcallvar_9 = (int __attribute__((__visibility__("hidden")))  )__dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = (int __attribute__((__visibility__("hidden")))  )__dyc_readpre_byte();
  __dyc_funcallvar_12 = (int __attribute__((__visibility__("hidden")))  )__dyc_readpre_byte();
  __dyc_funcallvar_13 = (int __attribute__((__visibility__("hidden")))  )__dyc_readpre_byte();
  __dyc_funcallvar_14 = (TValue const __attribute__((__visibility__("hidden")))  *)__dyc_read_ptr__typdef_TValue();
  __dyc_funcallvar_15 = (TValue const __attribute__((__visibility__("hidden")))  *)__dyc_read_ptr__typdef_TValue();
  __dyc_funcallvar_16 = (TValue const __attribute__((__visibility__("hidden")))  *)__dyc_read_ptr__typdef_TValue();
  rb = 0;
  tmp___0 = 0;
  b = 0;
  o2___1 = 0;
  o1___1 = 0;
  rb___0 = 0;
  i_o___0 = 0;
  tmp___1 = 0;
  i_o___1 = 0;
  uv = 0;
  o2___2 = 0;
  o1___2 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  b___0 = 0;
  c = 0;
  i_o___2 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  rb___1 = 0;
  o2___3 = 0;
  o1___3 = 0;
  tmp___7 = 0;
  rb___2 = 0;
  tmp___8 = 0;
  rc = 0;
  tmp___9 = 0;
  nb = 0;
  nc = 0;
  i_o___3 = 0;
  rb___3 = 0;
  tmp___10 = 0;
  rc___0 = 0;
  tmp___11 = 0;
  nb___0 = 0;
  nc___0 = 0;
  i_o___4 = 0;
  rb___4 = 0;
  tmp___12 = 0;
  rc___1 = 0;
  tmp___13 = 0;
  nb___1 = 0;
  nc___1 = 0;
  i_o___5 = 0;
  rb___5 = 0;
  tmp___14 = 0;
  rc___2 = 0;
  tmp___15 = 0;
  nb___2 = 0;
  nc___2 = 0;
  i_o___6 = 0;
  rb___6 = 0;
  tmp___16 = 0;
  rc___3 = 0;
  tmp___17 = 0;
  nb___3 = 0;
  nc___3 = 0;
  i_o___7 = 0;
  tmp___18 = 0;
  rb___7 = 0;
  tmp___19 = 0;
  rc___4 = 0;
  tmp___20 = 0;
  nb___4 = 0;
  nc___4 = 0;
  i_o___8 = 0;
  rb___8 = 0;
  nb___5 = 0;
  i_o___9 = 0;
  res = 0;
  tmp___21 = 0;
  i_o___10 = 0;
  rb___9 = 0;
  i_o___11 = 0;
  tmp___22 = 0;
  i_o___12 = 0;
  tmp___23 = 0;
  b___1 = 0;
  c___0 = 0;
  o2___4 = 0;
  o1___4 = 0;
  rb___10 = 0;
  tmp___24 = 0;
  rc___5 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  tmp___27 = 0;
  tmp___28 = 0;
  tmp___29 = 0;
  tmp___30 = 0;
  tmp___31 = 0;
  tmp___32 = 0;
  tmp___33 = 0;
  tmp___34 = 0;
  rb___11 = 0;
  o2___5 = 0;
  o1___5 = 0;
  tmp___35 = 0;
  b___2 = 0;
  nresults = 0;
  tmp___36 = 0;
  b___3 = 0;
  tmp___37 = 0;
  ci = 0;
  aux = 0;
  func = 0;
  pfunc = 0;
  o2___6 = 0;
  o1___6 = 0;
  b___4 = 0;
  tmp___38 = 0;
  step = 0;
  idx = 0;
  limit = 0;
  i_o___13 = 0;
  i_o___14 = 0;
  tmp___39 = 0;
  init = 0;
  plimit = 0;
  pstep = 0;
  tmp___40 = 0;
  tmp___41 = 0;
  tmp___42 = 0;
#line 417
  if ((int )((i >> 14) & ~ (4294967295U << 9))) {
#line 417
    pc ++;
  }
  goto __dyc_dummy_label;
  switch_9_3: /* CIL Label */ 
#line 421
  rb = base + (int )((i >> 23) & ~ (4294967295U << 9));
#line 422
  while (1) {
    while_10_continue: /* CIL Label */ ;
#line 423
    tmp___0 = rb;
#line 423
    rb --;
#line 423
    tmp___0->tt = 0;
#line 422
    if (! ((unsigned long )rb >= (unsigned long )ra)) {
      goto while_10_break;
    }
  }
  while_10_break: /* CIL Label */ ;
  goto __dyc_dummy_label;
  switch_9_4: /* CIL Label */ 
#line 428
  b = (int )((i >> 23) & ~ (4294967295U << 9));
#line 429
  o2___1 = (TValue const   *)(cl->upvals[b])->v;
#line 429
  o1___1 = ra;
#line 429
  o1___1->value = (union __anonunion_Value_29 )o2___1->value;
#line 429
  o1___1->tt = (int )o2___1->tt;
  goto __dyc_dummy_label;
#line 434
  rb___0 = k + (int )((i >> 14) & ~ (4294967295U << 18));
#line 435
  i_o___0 = & g;
#line 435
  i_o___0->value.gc = (GCObject *)cl->env;
#line 435
  i_o___0->tt = 5;
#line 437
  L->savedpc = pc;

#line 437
  base = L->base;
  goto __dyc_dummy_label;
  switch_9_6: /* CIL Label */ 
#line 441
  L->savedpc = pc;
#line 441
  if ((int )((i >> 14) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 441
    tmp___1 = k + ((int )((i >> 14) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 441
    tmp___1 = base + (int )((i >> 14) & ~ (4294967295U << 9));
  }

#line 441
  base = L->base;
  goto __dyc_dummy_label;
#line 446
  i_o___1 = & g___0;
#line 446
  i_o___1->value.gc = (GCObject *)cl->env;
#line 446
  i_o___1->tt = 5;
#line 448
  L->savedpc = pc;

#line 448
  base = L->base;
  goto __dyc_dummy_label;
  switch_9_8: /* CIL Label */ 
#line 452
  uv = cl->upvals[(int )((i >> 23) & ~ (4294967295U << 9))];
#line 453
  o2___2 = (TValue const   *)ra;
#line 453
  o1___2 = uv->v;
#line 453
  o1___2->value = (union __anonunion_Value_29 )o2___2->value;
#line 453
  o1___2->tt = (int )o2___2->tt;
#line 454
  if (ra->tt >= 4) {
#line 454
    if ((int )(ra->value.gc)->gch.marked & (1 | (1 << 1))) {
#line 454
      if ((int )((GCObject *)uv)->gch.marked & (1 << 2)) {
        {

        }
      }
    }
  }
  goto __dyc_dummy_label;
  switch_9_9: /* CIL Label */ 
#line 458
  L->savedpc = pc;
#line 458
  if ((int )((i >> 14) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 458
    tmp___2 = k + ((int )((i >> 14) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 458
    tmp___2 = base + (int )((i >> 14) & ~ (4294967295U << 9));
  }
#line 458
  if ((int )((i >> 23) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 458
    tmp___3 = k + ((int )((i >> 23) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 458
    tmp___3 = base + (int )((i >> 23) & ~ (4294967295U << 9));
  }

#line 458
  base = L->base;
  goto __dyc_dummy_label;
#line 462
  b___0 = (int )((i >> 23) & ~ (4294967295U << 9));
#line 463
  c = (int )((i >> 14) & ~ (4294967295U << 9));
#line 464
  i_o___2 = ra;
#line 464
  tmp___4 = __dyc_funcallvar_1;
#line 464
  tmp___5 = __dyc_funcallvar_2;
#line 464
  tmp___6 = __dyc_funcallvar_3;
#line 464
  i_o___2->value.gc = (GCObject *)tmp___6;
#line 464
  i_o___2->tt = 5;
#line 465
  L->savedpc = pc;
#line 465
  if ((L->l_G)->totalbytes >= (L->l_G)->GCthreshold) {
    {

    }
  }
#line 465
  base = L->base;
  goto __dyc_dummy_label;
  switch_9_11: /* CIL Label */ 
#line 469
  rb___1 = base + (int )((i >> 23) & ~ (4294967295U << 9));
#line 470
  o2___3 = (TValue const   *)rb___1;
#line 470
  o1___3 = ra + 1;
#line 470
  o1___3->value = (union __anonunion_Value_29 )o2___3->value;
#line 470
  o1___3->tt = (int )o2___3->tt;
#line 471
  L->savedpc = pc;
#line 471
  if ((int )((i >> 14) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 471
    tmp___7 = k + ((int )((i >> 14) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 471
    tmp___7 = base + (int )((i >> 14) & ~ (4294967295U << 9));
  }

#line 471
  base = L->base;
  goto __dyc_dummy_label;
  switch_9_12: /* CIL Label */ 
#line 475
  if ((int )((i >> 23) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 475
    tmp___8 = k + ((int )((i >> 23) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 475
    tmp___8 = base + (int )((i >> 23) & ~ (4294967295U << 9));
  }
#line 475
  rb___2 = tmp___8;
#line 475
  if ((int )((i >> 14) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 475
    tmp___9 = k + ((int )((i >> 14) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 475
    tmp___9 = base + (int )((i >> 14) & ~ (4294967295U << 9));
  }
#line 475
  rc = tmp___9;
#line 475
  if (rb___2->tt == 3) {
#line 475
    if (rc->tt == 3) {
#line 475
      nb = rb___2->value.n;
#line 475
      nc = rc->value.n;
#line 475
      i_o___3 = ra;
#line 475
      i_o___3->value.n = nb + nc;
#line 475
      i_o___3->tt = 3;
    } else {
      {
#line 475
      L->savedpc = pc;

#line 475
      base = L->base;
      }
    }
  } else {
    {
#line 475
    L->savedpc = pc;

#line 475
    base = L->base;
    }
  }
  goto __dyc_dummy_label;
  switch_9_13: /* CIL Label */ 
#line 479
  if ((int )((i >> 23) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 479
    tmp___10 = k + ((int )((i >> 23) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 479
    tmp___10 = base + (int )((i >> 23) & ~ (4294967295U << 9));
  }
#line 479
  rb___3 = tmp___10;
#line 479
  if ((int )((i >> 14) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 479
    tmp___11 = k + ((int )((i >> 14) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 479
    tmp___11 = base + (int )((i >> 14) & ~ (4294967295U << 9));
  }
#line 479
  rc___0 = tmp___11;
#line 479
  if (rb___3->tt == 3) {
#line 479
    if (rc___0->tt == 3) {
#line 479
      nb___0 = rb___3->value.n;
#line 479
      nc___0 = rc___0->value.n;
#line 479
      i_o___4 = ra;
#line 479
      i_o___4->value.n = nb___0 - nc___0;
#line 479
      i_o___4->tt = 3;
    } else {
      {
#line 479
      L->savedpc = pc;

#line 479
      base = L->base;
      }
    }
  } else {
    {
#line 479
    L->savedpc = pc;

#line 479
    base = L->base;
    }
  }
  goto __dyc_dummy_label;
  switch_9_14: /* CIL Label */ 
#line 483
  if ((int )((i >> 23) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 483
    tmp___12 = k + ((int )((i >> 23) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 483
    tmp___12 = base + (int )((i >> 23) & ~ (4294967295U << 9));
  }
#line 483
  rb___4 = tmp___12;
#line 483
  if ((int )((i >> 14) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 483
    tmp___13 = k + ((int )((i >> 14) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 483
    tmp___13 = base + (int )((i >> 14) & ~ (4294967295U << 9));
  }
#line 483
  rc___1 = tmp___13;
#line 483
  if (rb___4->tt == 3) {
#line 483
    if (rc___1->tt == 3) {
#line 483
      nb___1 = rb___4->value.n;
#line 483
      nc___1 = rc___1->value.n;
#line 483
      i_o___5 = ra;
#line 483
      i_o___5->value.n = nb___1 * nc___1;
#line 483
      i_o___5->tt = 3;
    } else {
      {
#line 483
      L->savedpc = pc;

#line 483
      base = L->base;
      }
    }
  } else {
    {
#line 483
    L->savedpc = pc;

#line 483
    base = L->base;
    }
  }
  goto __dyc_dummy_label;
  switch_9_15: /* CIL Label */ 
#line 487
  if ((int )((i >> 23) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 487
    tmp___14 = k + ((int )((i >> 23) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 487
    tmp___14 = base + (int )((i >> 23) & ~ (4294967295U << 9));
  }
#line 487
  rb___5 = tmp___14;
#line 487
  if ((int )((i >> 14) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 487
    tmp___15 = k + ((int )((i >> 14) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 487
    tmp___15 = base + (int )((i >> 14) & ~ (4294967295U << 9));
  }
#line 487
  rc___2 = tmp___15;
#line 487
  if (rb___5->tt == 3) {
#line 487
    if (rc___2->tt == 3) {
#line 487
      nb___2 = rb___5->value.n;
#line 487
      nc___2 = rc___2->value.n;
#line 487
      i_o___6 = ra;
#line 487
      i_o___6->value.n = nb___2 / nc___2;
#line 487
      i_o___6->tt = 3;
    } else {
      {
#line 487
      L->savedpc = pc;

#line 487
      base = L->base;
      }
    }
  } else {
    {
#line 487
    L->savedpc = pc;

#line 487
    base = L->base;
    }
  }
  goto __dyc_dummy_label;
  switch_9_16: /* CIL Label */ 
#line 491
  if ((int )((i >> 23) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 491
    tmp___16 = k + ((int )((i >> 23) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 491
    tmp___16 = base + (int )((i >> 23) & ~ (4294967295U << 9));
  }
#line 491
  rb___6 = tmp___16;
#line 491
  if ((int )((i >> 14) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 491
    tmp___17 = k + ((int )((i >> 14) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 491
    tmp___17 = base + (int )((i >> 14) & ~ (4294967295U << 9));
  }
#line 491
  rc___3 = tmp___17;
#line 491
  if (rb___6->tt == 3) {
#line 491
    if (rc___3->tt == 3) {
      {
#line 491
      nb___3 = rb___6->value.n;
#line 491
      nc___3 = rc___3->value.n;
#line 491
      i_o___7 = ra;
#line 491
      tmp___18 = __dyc_funcallvar_4;
#line 491
      i_o___7->value.n = nb___3 - tmp___18 * nc___3;
#line 491
      i_o___7->tt = 3;
      }
    } else {
      {
#line 491
      L->savedpc = pc;

#line 491
      base = L->base;
      }
    }
  } else {
    {
#line 491
    L->savedpc = pc;

#line 491
    base = L->base;
    }
  }
  goto __dyc_dummy_label;
  switch_9_17: /* CIL Label */ 
#line 495
  if ((int )((i >> 23) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 495
    tmp___19 = k + ((int )((i >> 23) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 495
    tmp___19 = base + (int )((i >> 23) & ~ (4294967295U << 9));
  }
#line 495
  rb___7 = tmp___19;
#line 495
  if ((int )((i >> 14) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 495
    tmp___20 = k + ((int )((i >> 14) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 495
    tmp___20 = base + (int )((i >> 14) & ~ (4294967295U << 9));
  }
#line 495
  rc___4 = tmp___20;
#line 495
  if (rb___7->tt == 3) {
#line 495
    if (rc___4->tt == 3) {
      {
#line 495
      nb___4 = rb___7->value.n;
#line 495
      nc___4 = rc___4->value.n;
#line 495
      i_o___8 = ra;
#line 495
      i_o___8->value.n = __dyc_funcallvar_5;
#line 495
      i_o___8->tt = 3;
      }
    } else {
      {
#line 495
      L->savedpc = pc;

#line 495
      base = L->base;
      }
    }
  } else {
    {
#line 495
    L->savedpc = pc;

#line 495
    base = L->base;
    }
  }
  goto __dyc_dummy_label;
  switch_9_18: /* CIL Label */ 
#line 499
  rb___8 = base + (int )((i >> 23) & ~ (4294967295U << 9));
#line 500
  if (rb___8->tt == 3) {
#line 501
    nb___5 = rb___8->value.n;
#line 502
    i_o___9 = ra;
#line 502
    i_o___9->value.n = - nb___5;
#line 502
    i_o___9->tt = 3;
  } else {
    {
#line 505
    L->savedpc = pc;

#line 505
    base = L->base;
    }
  }
  goto __dyc_dummy_label;
  switch_9_19: /* CIL Label */ 
#line 510
  if ((base + (int )((i >> 23) & ~ (4294967295U << 9)))->tt == 0) {
#line 510
    tmp___21 = 1;
  } else {
#line 510
    if ((base + (int )((i >> 23) & ~ (4294967295U << 9)))->tt == 1) {
#line 510
      if ((base + (int )((i >> 23) & ~ (4294967295U << 9)))->value.b == 0) {
#line 510
        tmp___21 = 1;
      } else {
#line 510
        tmp___21 = 0;
      }
    } else {
#line 510
      tmp___21 = 0;
    }
  }
#line 510
  res = tmp___21;
#line 511
  i_o___10 = ra;
#line 511
  i_o___10->value.b = res;
#line 511
  i_o___10->tt = 1;
  goto __dyc_dummy_label;
  switch_9_20: /* CIL Label */ 
#line 515
  rb___9 = (TValue const   *)(base + (int )((i >> 23) & ~ (4294967295U << 9)));
#line 517
  if ((int )rb___9->tt == 5) {
    goto switch_11_5;
  } else {
#line 521
    if ((int )rb___9->tt == 4) {
      goto switch_11_4;
    } else {
      {
      goto switch_11_default;
#line 516
      if (0) {
        switch_11_5: /* CIL Label */ 
        {
#line 518
        i_o___11 = ra;
#line 518
        tmp___22 = __dyc_funcallvar_6;
#line 518
        i_o___11->value.n = (double )tmp___22;
#line 518
        i_o___11->tt = 3;
        }
        goto switch_11_break;
        switch_11_4: /* CIL Label */ 
#line 522
        i_o___12 = ra;
#line 522
        i_o___12->value.n = (double )(rb___9->value.gc)->ts.tsv.len;
#line 522
        i_o___12->tt = 3;
        goto switch_11_break;
        switch_11_default: /* CIL Label */ 
        {
#line 526
        L->savedpc = pc;
#line 526
        tmp___23 = __dyc_funcallvar_7;
        }
#line 526
        if (! tmp___23) {
          {

          }
        }
#line 526
        base = L->base;
      } else {
        switch_11_break: /* CIL Label */ ;
      }
      }
    }
  }
  goto __dyc_dummy_label;
#line 535
  b___1 = (int )((i >> 23) & ~ (4294967295U << 9));
#line 536
  c___0 = (int )((i >> 14) & ~ (4294967295U << 9));
#line 537
  L->savedpc = pc;

#line 537
  if ((L->l_G)->totalbytes >= (L->l_G)->GCthreshold) {
    {

    }
  }
#line 537
  base = L->base;
#line 538
  o2___4 = (TValue const   *)(base + b___1);
#line 538
  o1___4 = base + (int )((i >> 6) & ~ (4294967295U << 8));
#line 538
  o1___4->value = (union __anonunion_Value_29 )o2___4->value;
#line 538
  o1___4->tt = (int )o2___4->tt;
  goto __dyc_dummy_label;
  switch_9_22: /* CIL Label */ 
#line 542
  pc += (int )((i >> 14) & ~ (4294967295U << 18)) - (((1 << 18) - 1) >> 1);
  goto __dyc_dummy_label;
  switch_9_23: /* CIL Label */ 
#line 546
  if ((int )((i >> 23) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 546
    tmp___24 = k + ((int )((i >> 23) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 546
    tmp___24 = base + (int )((i >> 23) & ~ (4294967295U << 9));
  }
#line 546
  rb___10 = tmp___24;
#line 547
  if ((int )((i >> 14) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 547
    tmp___25 = k + ((int )((i >> 14) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 547
    tmp___25 = base + (int )((i >> 14) & ~ (4294967295U << 9));
  }
#line 547
  rc___5 = tmp___25;
#line 548
  L->savedpc = pc;
#line 548
  if (rb___10->tt == rc___5->tt) {
    {
#line 548
    tmp___26 = __dyc_funcallvar_8;
    }
#line 548
    if (tmp___26) {
#line 548
      tmp___27 = 1;
    } else {
#line 548
      tmp___27 = 0;
    }
  } else {
#line 548
    tmp___27 = 0;
  }
#line 548
  if (tmp___27 == (int )((i >> 6) & ~ (4294967295U << 8))) {
#line 548
    pc += (int )((*pc >> 14) & (unsigned int const   )(~ (4294967295U << 18))) - (((1 << 18) - 1) >> 1);
  }
#line 548
  base = L->base;
#line 552
  pc ++;
  goto __dyc_dummy_label;
  switch_9_24: /* CIL Label */ 
#line 556
  L->savedpc = pc;
#line 556
  if ((int )((i >> 14) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 556
    tmp___28 = k + ((int )((i >> 14) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 556
    tmp___28 = base + (int )((i >> 14) & ~ (4294967295U << 9));
  }
#line 556
  if ((int )((i >> 23) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 556
    tmp___29 = k + ((int )((i >> 23) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 556
    tmp___29 = base + (int )((i >> 23) & ~ (4294967295U << 9));
  }
#line 556
  tmp___30 = __dyc_funcallvar_9;
#line 556
  if (tmp___30 == (int __attribute__((__visibility__("hidden")))  )((int )((i >> 6) & ~ (4294967295U << 8)))) {
#line 556
    pc += (int )((*pc >> 14) & (unsigned int const   )(~ (4294967295U << 18))) - (((1 << 18) - 1) >> 1);
  }
#line 556
  base = L->base;
#line 560
  pc ++;
  goto __dyc_dummy_label;
  switch_9_25: /* CIL Label */ 
#line 564
  L->savedpc = pc;
#line 564
  if ((int )((i >> 14) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 564
    tmp___31 = k + ((int )((i >> 14) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 564
    tmp___31 = base + (int )((i >> 14) & ~ (4294967295U << 9));
  }
#line 564
  if ((int )((i >> 23) & ~ (4294967295U << 9)) & (1 << 8)) {
#line 564
    tmp___32 = k + ((int )((i >> 23) & ~ (4294967295U << 9)) & ~ (1 << 8));
  } else {
#line 564
    tmp___32 = base + (int )((i >> 23) & ~ (4294967295U << 9));
  }
#line 564
  tmp___33 = __dyc_funcallvar_10;
#line 564
  if (tmp___33 == (int )((i >> 6) & ~ (4294967295U << 8))) {
#line 564
    pc += (int )((*pc >> 14) & (unsigned int const   )(~ (4294967295U << 18))) - (((1 << 18) - 1) >> 1);
  }
#line 564
  base = L->base;
#line 568
  pc ++;
  goto __dyc_dummy_label;
  switch_9_26: /* CIL Label */ 
#line 572
  if (ra->tt == 0) {
#line 572
    tmp___34 = 1;
  } else {
#line 572
    if (ra->tt == 1) {
#line 572
      if (ra->value.b == 0) {
#line 572
        tmp___34 = 1;
      } else {
#line 572
        tmp___34 = 0;
      }
    } else {
#line 572
      tmp___34 = 0;
    }
  }
#line 572
  if (tmp___34 != (int )((i >> 14) & ~ (4294967295U << 9))) {
#line 573
    pc += (int )((*pc >> 14) & (unsigned int const   )(~ (4294967295U << 18))) - (((1 << 18) - 1) >> 1);
  }
#line 574
  pc ++;
  goto __dyc_dummy_label;
  switch_9_27: /* CIL Label */ 
#line 578
  rb___11 = base + (int )((i >> 23) & ~ (4294967295U << 9));
#line 579
  if (rb___11->tt == 0) {
#line 579
    tmp___35 = 1;
  } else {
#line 579
    if (rb___11->tt == 1) {
#line 579
      if (rb___11->value.b == 0) {
#line 579
        tmp___35 = 1;
      } else {
#line 579
        tmp___35 = 0;
      }
    } else {
#line 579
      tmp___35 = 0;
    }
  }
#line 579
  if (tmp___35 != (int )((i >> 14) & ~ (4294967295U << 9))) {
#line 580
    o2___5 = (TValue const   *)rb___11;
#line 580
    o1___5 = ra;
#line 580
    o1___5->value = (union __anonunion_Value_29 )o2___5->value;
#line 580
    o1___5->tt = (int )o2___5->tt;
#line 581
    pc += (int )((*pc >> 14) & (unsigned int const   )(~ (4294967295U << 18))) - (((1 << 18) - 1) >> 1);
  }
#line 583
  pc ++;
  goto __dyc_dummy_label;
  switch_9_28: /* CIL Label */ 
#line 587
  b___2 = (int )((i >> 23) & ~ (4294967295U << 9));
#line 588
  nresults = (int )((i >> 14) & ~ (4294967295U << 9)) - 1;
#line 589
  if (b___2 != 0) {
#line 589
    L->top = ra + b___2;
  }
#line 590
  L->savedpc = pc;
#line 591
  tmp___36 = __dyc_funcallvar_11;
#line 592
  if ((int )tmp___36 == 0) {
    goto switch_12_0;
  } else {
#line 596
    if ((int )tmp___36 == 1) {
      goto switch_12_1;
    } else {
      {
      goto switch_12_default;
#line 591
      if (0) {
        switch_12_0: /* CIL Label */ 
#line 593
        nexeccalls ++;
        goto __dyc_dummy_label;
        switch_12_1: /* CIL Label */ 
#line 598
        if (nresults >= 0) {
#line 598
          L->top = (L->ci)->top;
        }
#line 599
        base = L->base;
        goto __dyc_dummy_label;
        switch_12_default: /* CIL Label */ ;
        goto __dyc_dummy_label;
      } else {
        switch_12_break: /* CIL Label */ ;
      }
      }
    }
  }
  switch_9_29: /* CIL Label */ 
#line 608
  b___3 = (int )((i >> 23) & ~ (4294967295U << 9));
#line 609
  if (b___3 != 0) {
#line 609
    L->top = ra + b___3;
  }
#line 610
  L->savedpc = pc;
#line 612
  tmp___37 = __dyc_funcallvar_12;
#line 613
  if ((int )tmp___37 == 0) {
    goto switch_13_0;
  } else {
#line 630
    if ((int )tmp___37 == 1) {
      goto switch_13_1;
    } else {
      {
      goto switch_13_default;
#line 612
      if (0) {
        switch_13_0: /* CIL Label */ 
#line 615
        ci = L->ci - 1;
#line 617
        func = ci->func;
#line 618
        pfunc = (ci + 1)->func;
#line 619
        if (L->openupval) {
          {

          }
        }
#line 620
        ci->base = ci->func + ((ci + 1)->base - pfunc);
#line 620
        L->base = ci->base;
#line 621
        aux = 0;
        {
#line 621
        while (1) {
          while_14_continue: /* CIL Label */ ;
#line 621
          if (! ((unsigned long )(pfunc + aux) < (unsigned long )L->top)) {
            goto while_14_break;
          }
#line 622
          o2___6 = (TValue const   *)(pfunc + aux);
#line 622
          o1___6 = func + aux;
#line 622
          o1___6->value = (union __anonunion_Value_29 )o2___6->value;
#line 622
          o1___6->tt = (int )o2___6->tt;
#line 621
          aux ++;
        }
        while_14_break: /* CIL Label */ ;
        }
#line 623
        L->top = func + aux;
#line 623
        ci->top = L->top;
#line 625
        ci->savedpc = L->savedpc;
#line 626
        (ci->tailcalls) ++;
#line 627
        (L->ci) --;
        goto __dyc_dummy_label;
        switch_13_1: /* CIL Label */ 
#line 631
        base = L->base;
        goto __dyc_dummy_label;
        switch_13_default: /* CIL Label */ ;
        goto __dyc_dummy_label;
      } else {
        switch_13_break: /* CIL Label */ ;
      }
      }
    }
  }
  switch_9_30: /* CIL Label */ 
#line 640
  b___4 = (int )((i >> 23) & ~ (4294967295U << 9));
#line 641
  if (b___4 != 0) {
#line 641
    L->top = (ra + b___4) - 1;
  }
#line 642
  if (L->openupval) {
    {

    }
  }
#line 643
  L->savedpc = pc;
#line 644
  tmp___38 = __dyc_funcallvar_13;
#line 644
  b___4 = (int )tmp___38;
#line 645
  nexeccalls --;
#line 645
  if (nexeccalls == 0) {
    goto __dyc_dummy_label;
  } else {
#line 648
    if (b___4) {
#line 648
      L->top = (L->ci)->top;
    }
    goto __dyc_dummy_label;
  }
  switch_9_31: /* CIL Label */ 
#line 655
  step = (ra + 2)->value.n;
#line 656
  idx = ra->value.n + step;
#line 657
  limit = (ra + 1)->value.n;
#line 658
  if ((lua_Number )0 < step) {
#line 658
    tmp___39 = idx <= limit;
  } else {
#line 658
    tmp___39 = limit <= idx;
  }
#line 658
  if (tmp___39) {
#line 660
    pc += (int )((i >> 14) & ~ (4294967295U << 18)) - (((1 << 18) - 1) >> 1);
#line 661
    i_o___13 = ra;
#line 661
    i_o___13->value.n = idx;
#line 661
    i_o___13->tt = 3;
#line 662
    i_o___14 = ra + 3;
#line 662
    i_o___14->value.n = idx;
#line 662
    i_o___14->tt = 3;
  }
  goto __dyc_dummy_label;
  switch_9_32: /* CIL Label */ 
#line 667
  init = (TValue const   *)ra;
#line 668
  plimit = (TValue const   *)(ra + 1);
#line 669
  pstep = (TValue const   *)(ra + 2);
#line 670
  L->savedpc = pc;
#line 671
  if (init->tt == 3) {
    goto _L___1;
  } else {
    {
#line 671
    tmp___42 = __dyc_funcallvar_14;
#line 671
    init = (TValue const   *)tmp___42;
    }
#line 671
    if ((unsigned long )init != (unsigned long )((void *)0)) {
      _L___1: /* CIL Label */ 
#line 673
      if (plimit->tt == 3) {
        goto _L___0;
      } else {
        {
#line 673
        tmp___41 = __dyc_funcallvar_15;
#line 673
        plimit = (TValue const   *)tmp___41;
        }
#line 673
        if ((unsigned long )plimit != (unsigned long )((void *)0)) {
          _L___0: /* CIL Label */ 
#line 675
          if (! (pstep->tt == 3)) {
            {
#line 675
            tmp___40 = __dyc_funcallvar_16;
#line 675
            pstep = (TValue const   *)tmp___40;
            }
#line 675
            if (! ((unsigned long )pstep != (unsigned long )((void *)0))) {
              {

              }
            }
          }
        } else {
          {

          }
        }
      }
    } else {
      {

      }
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__typdef_TValue(base);
  __dyc_print_ptr__typdef_Instruction(pc);
  __dyc_print_ptr__typdef_TValue(rb___0);
  __dyc_print_ptr__typdef_TValue(tmp___1);
  __dyc_print_ptr__typdef_TValue(tmp___2);
  __dyc_print_ptr__typdef_TValue(tmp___3);
  __dyc_printpre_byte(b___0);
  __dyc_printpre_byte(c);
  __dyc_printpre_byte(tmp___4);
  __dyc_printpre_byte(tmp___5);
  __dyc_print_ptr__typdef_TValue(tmp___7);
  __dyc_print_ptr__typdef_TValue(rc);
  __dyc_print_ptr__typdef_TValue(rc___0);
  __dyc_print_ptr__typdef_TValue(rc___1);
  __dyc_print_ptr__typdef_TValue(rc___2);
  __dyc_print_ptr__typdef_TValue(rc___3);
  __dyc_print_ptr__typdef_TValue(rc___4);
  __dyc_printpre_byte(nb___4);
  __dyc_printpre_byte(nc___4);
  __dyc_printpre_byte(c___0);
  __dyc_print_ptr__typdef_TValue(tmp___28);
  __dyc_print_ptr__typdef_TValue(tmp___29);
  __dyc_print_ptr__typdef_TValue(tmp___31);
  __dyc_print_ptr__typdef_TValue(tmp___32);
  __dyc_printpre_byte(nresults);
  __dyc_printpre_byte(b___4);
  __dyc_print_ptr__typdef_TValue(plimit);
  __dyc_print_ptr__typdef_TValue(pstep);
  __dyc_printpre_byte(nexeccalls);
}
}
