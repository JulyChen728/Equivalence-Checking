#include <dycfoo.h>
#include "../regex.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned char c ;
  char const   *p ;
  char const   *pend ;
  char *translate ;
  char str[7] ;
  int tmp___259 ;
  size_t __s1_len___12 ;
  size_t __s2_len___12 ;
  int tmp___277 ;
  int tmp___282 ;
  int tmp___283 ;
  int tmp___284 ;
  int tmp___285 ;
  size_t __s1_len___13 ;
  size_t __s2_len___13 ;
  int tmp___295 ;
  int tmp___300 ;
  int tmp___301 ;
  int tmp___302 ;
  int tmp___303 ;
  size_t __s1_len___14 ;
  size_t __s2_len___14 ;
  int tmp___313 ;
  int tmp___318 ;
  int tmp___319 ;
  int tmp___320 ;
  int tmp___321 ;
  size_t __s1_len___15 ;
  size_t __s2_len___15 ;
  int tmp___331 ;
  int tmp___336 ;
  int tmp___337 ;
  int tmp___338 ;
  int tmp___339 ;
  size_t __s1_len___16 ;
  size_t __s2_len___16 ;
  int tmp___349 ;
  int tmp___354 ;
  int tmp___355 ;
  int tmp___356 ;
  int tmp___357 ;
  size_t __s1_len___17 ;
  size_t __s2_len___17 ;
  int tmp___367 ;
  int tmp___372 ;
  int tmp___373 ;
  int tmp___374 ;
  int tmp___375 ;
  size_t __s1_len___18 ;
  size_t __s2_len___18 ;
  int tmp___385 ;
  int tmp___390 ;
  int tmp___391 ;
  int tmp___392 ;
  int tmp___393 ;
  size_t __s1_len___19 ;
  size_t __s2_len___19 ;
  int tmp___403 ;
  int tmp___408 ;
  int tmp___409 ;
  int tmp___410 ;
  int tmp___411 ;
  size_t __s1_len___20 ;
  size_t __s2_len___20 ;
  int tmp___421 ;
  int tmp___426 ;
  int tmp___427 ;
  int tmp___428 ;
  int tmp___429 ;
  size_t __s1_len___21 ;
  size_t __s2_len___21 ;
  int tmp___439 ;
  int tmp___444 ;
  int tmp___445 ;
  int tmp___446 ;
  int tmp___447 ;
  size_t __s1_len___22 ;
  size_t __s2_len___22 ;
  int tmp___457 ;
  int tmp___462 ;
  int tmp___463 ;
  int tmp___464 ;
  int tmp___465 ;
  char const   *tmp___466 ;
  int __dyc_funcallvar_82 ;
  int __dyc_funcallvar_83 ;
  int __dyc_funcallvar_84 ;
  int __dyc_funcallvar_85 ;
  int __dyc_funcallvar_86 ;
  int __dyc_funcallvar_87 ;
  int __dyc_funcallvar_88 ;
  int __dyc_funcallvar_89 ;
  int __dyc_funcallvar_90 ;
  int __dyc_funcallvar_91 ;
  int __dyc_funcallvar_92 ;
  int __dyc_funcallvar_93 ;
  int __dyc_funcallvar_94 ;
  int __dyc_funcallvar_95 ;
  int __dyc_funcallvar_96 ;
  int __dyc_funcallvar_97 ;
  int __dyc_funcallvar_98 ;
  int __dyc_funcallvar_99 ;
  int __dyc_funcallvar_100 ;
  int __dyc_funcallvar_101 ;
  int __dyc_funcallvar_102 ;
  int __dyc_funcallvar_103 ;
  int __dyc_funcallvar_104 ;
  int __dyc_funcallvar_105 ;
  int __dyc_funcallvar_106 ;
  int __dyc_funcallvar_107 ;
  int __dyc_funcallvar_108 ;
  int __dyc_funcallvar_109 ;
  int __dyc_funcallvar_110 ;
  int __dyc_funcallvar_111 ;
  int __dyc_funcallvar_112 ;
  int __dyc_funcallvar_113 ;
  int __dyc_funcallvar_114 ;
  int __dyc_funcallvar_115 ;
  int __dyc_funcallvar_116 ;
  int __dyc_funcallvar_117 ;
  int __dyc_funcallvar_118 ;
  int __dyc_funcallvar_119 ;
  int __dyc_funcallvar_120 ;
  int __dyc_funcallvar_121 ;
  int __dyc_funcallvar_122 ;
  int __dyc_funcallvar_123 ;
  int __dyc_funcallvar_124 ;
  int __dyc_funcallvar_125 ;
  int __dyc_funcallvar_126 ;
  int __dyc_funcallvar_127 ;
  int __dyc_funcallvar_128 ;
  int __dyc_funcallvar_129 ;
  int __dyc_funcallvar_130 ;
  int __dyc_funcallvar_131 ;
  int __dyc_funcallvar_132 ;
  int __dyc_funcallvar_133 ;
  int __dyc_funcallvar_134 ;
  int __dyc_funcallvar_135 ;
  int __dyc_funcallvar_136 ;

  {
  p = (char const   *)__dyc_read_ptr__char();
  pend = (char const   *)__dyc_read_ptr__char();
  translate = (char *)__dyc_read_ptr__char();
  tmp___259 = __dyc_readpre_byte();
  __dyc_funcallvar_82 = __dyc_readpre_byte();
  __dyc_funcallvar_83 = __dyc_readpre_byte();
  __dyc_funcallvar_84 = __dyc_readpre_byte();
  __dyc_funcallvar_85 = __dyc_readpre_byte();
  __dyc_funcallvar_86 = __dyc_readpre_byte();
  __dyc_funcallvar_87 = __dyc_readpre_byte();
  __dyc_funcallvar_88 = __dyc_readpre_byte();
  __dyc_funcallvar_89 = __dyc_readpre_byte();
  __dyc_funcallvar_90 = __dyc_readpre_byte();
  __dyc_funcallvar_91 = __dyc_readpre_byte();
  __dyc_funcallvar_92 = __dyc_readpre_byte();
  __dyc_funcallvar_93 = __dyc_readpre_byte();
  __dyc_funcallvar_94 = __dyc_readpre_byte();
  __dyc_funcallvar_95 = __dyc_readpre_byte();
  __dyc_funcallvar_96 = __dyc_readpre_byte();
  __dyc_funcallvar_97 = __dyc_readpre_byte();
  __dyc_funcallvar_98 = __dyc_readpre_byte();
  __dyc_funcallvar_99 = __dyc_readpre_byte();
  __dyc_funcallvar_100 = __dyc_readpre_byte();
  __dyc_funcallvar_101 = __dyc_readpre_byte();
  __dyc_funcallvar_102 = __dyc_readpre_byte();
  __dyc_funcallvar_103 = __dyc_readpre_byte();
  __dyc_funcallvar_104 = __dyc_readpre_byte();
  __dyc_funcallvar_105 = __dyc_readpre_byte();
  __dyc_funcallvar_106 = __dyc_readpre_byte();
  __dyc_funcallvar_107 = __dyc_readpre_byte();
  __dyc_funcallvar_108 = __dyc_readpre_byte();
  __dyc_funcallvar_109 = __dyc_readpre_byte();
  __dyc_funcallvar_110 = __dyc_readpre_byte();
  __dyc_funcallvar_111 = __dyc_readpre_byte();
  __dyc_funcallvar_112 = __dyc_readpre_byte();
  __dyc_funcallvar_113 = __dyc_readpre_byte();
  __dyc_funcallvar_114 = __dyc_readpre_byte();
  __dyc_funcallvar_115 = __dyc_readpre_byte();
  __dyc_funcallvar_116 = __dyc_readpre_byte();
  __dyc_funcallvar_117 = __dyc_readpre_byte();
  __dyc_funcallvar_118 = __dyc_readpre_byte();
  __dyc_funcallvar_119 = __dyc_readpre_byte();
  __dyc_funcallvar_120 = __dyc_readpre_byte();
  __dyc_funcallvar_121 = __dyc_readpre_byte();
  __dyc_funcallvar_122 = __dyc_readpre_byte();
  __dyc_funcallvar_123 = __dyc_readpre_byte();
  __dyc_funcallvar_124 = __dyc_readpre_byte();
  __dyc_funcallvar_125 = __dyc_readpre_byte();
  __dyc_funcallvar_126 = __dyc_readpre_byte();
  __dyc_funcallvar_127 = __dyc_readpre_byte();
  __dyc_funcallvar_128 = __dyc_readpre_byte();
  __dyc_funcallvar_129 = __dyc_readpre_byte();
  __dyc_funcallvar_130 = __dyc_readpre_byte();
  __dyc_funcallvar_131 = __dyc_readpre_byte();
  __dyc_funcallvar_132 = __dyc_readpre_byte();
  __dyc_funcallvar_133 = __dyc_readpre_byte();
  __dyc_funcallvar_134 = __dyc_readpre_byte();
  __dyc_funcallvar_135 = __dyc_readpre_byte();
  __dyc_funcallvar_136 = __dyc_readpre_byte();
  c = 0;
  __s1_len___12 = 0;
  __s2_len___12 = 0;
  tmp___277 = 0;
  tmp___282 = 0;
  tmp___283 = 0;
  tmp___284 = 0;
  tmp___285 = 0;
  __s1_len___13 = 0;
  __s2_len___13 = 0;
  tmp___295 = 0;
  tmp___300 = 0;
  tmp___301 = 0;
  tmp___302 = 0;
  tmp___303 = 0;
  __s1_len___14 = 0;
  __s2_len___14 = 0;
  tmp___313 = 0;
  tmp___318 = 0;
  tmp___319 = 0;
  tmp___320 = 0;
  tmp___321 = 0;
  __s1_len___15 = 0;
  __s2_len___15 = 0;
  tmp___331 = 0;
  tmp___336 = 0;
  tmp___337 = 0;
  tmp___338 = 0;
  tmp___339 = 0;
  __s1_len___16 = 0;
  __s2_len___16 = 0;
  tmp___349 = 0;
  tmp___354 = 0;
  tmp___355 = 0;
  tmp___356 = 0;
  tmp___357 = 0;
  __s1_len___17 = 0;
  __s2_len___17 = 0;
  tmp___367 = 0;
  tmp___372 = 0;
  tmp___373 = 0;
  tmp___374 = 0;
  tmp___375 = 0;
  __s1_len___18 = 0;
  __s2_len___18 = 0;
  tmp___385 = 0;
  tmp___390 = 0;
  tmp___391 = 0;
  tmp___392 = 0;
  tmp___393 = 0;
  __s1_len___19 = 0;
  __s2_len___19 = 0;
  tmp___403 = 0;
  tmp___408 = 0;
  tmp___409 = 0;
  tmp___410 = 0;
  tmp___411 = 0;
  __s1_len___20 = 0;
  __s2_len___20 = 0;
  tmp___421 = 0;
  tmp___426 = 0;
  tmp___427 = 0;
  tmp___428 = 0;
  tmp___429 = 0;
  __s1_len___21 = 0;
  __s2_len___21 = 0;
  tmp___439 = 0;
  tmp___444 = 0;
  tmp___445 = 0;
  tmp___446 = 0;
  tmp___447 = 0;
  __s1_len___22 = 0;
  __s2_len___22 = 0;
  tmp___457 = 0;
  tmp___462 = 0;
  tmp___463 = 0;
  tmp___464 = 0;
  tmp___465 = 0;
  tmp___466 = 0;
#line 3268
  if (! (tmp___259 == 0)) {
#line 3268
    if (0) {
      {
#line 3268
      tmp___283 = __dyc_funcallvar_82;
#line 3268
      __s1_len___12 = (unsigned long )tmp___283;
#line 3268
      tmp___284 = __dyc_funcallvar_83;
#line 3268
      __s2_len___12 = (unsigned long )tmp___284;
      }
#line 3268
      if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
        goto _L___30;
      } else {
#line 3268
        if (__s1_len___12 >= 4UL) {
          _L___30: /* CIL Label */ 
#line 3268
          if (! ((unsigned long )((void const   *)("upper" + 1)) - (unsigned long )((void const   *)"upper") == 1UL)) {
#line 3268
            tmp___285 = 1;
          } else {
#line 3268
            if (__s2_len___12 >= 4UL) {
#line 3268
              tmp___285 = 1;
            } else {
#line 3268
              tmp___285 = 0;
            }
          }
        } else {
#line 3268
          tmp___285 = 0;
        }
      }
#line 3268
      if (tmp___285) {
        {
#line 3268
        tmp___277 = __dyc_funcallvar_84;
        }
      } else {
        {
#line 3268
        tmp___282 = __dyc_funcallvar_85;
#line 3268
        tmp___277 = tmp___282;
        }
      }
    } else {
      {
#line 3268
      tmp___282 = __dyc_funcallvar_86;
#line 3268
      tmp___277 = tmp___282;
      }
    }
#line 3268
    if (! (tmp___277 == 0)) {
#line 3268
      if (0) {
        {
#line 3268
        tmp___301 = __dyc_funcallvar_87;
#line 3268
        __s1_len___13 = (unsigned long )tmp___301;
#line 3268
        tmp___302 = __dyc_funcallvar_88;
#line 3268
        __s2_len___13 = (unsigned long )tmp___302;
        }
#line 3268
        if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
          goto _L___32;
        } else {
#line 3268
          if (__s1_len___13 >= 4UL) {
            _L___32: /* CIL Label */ 
#line 3268
            if (! ((unsigned long )((void const   *)("lower" + 1)) - (unsigned long )((void const   *)"lower") == 1UL)) {
#line 3268
              tmp___303 = 1;
            } else {
#line 3268
              if (__s2_len___13 >= 4UL) {
#line 3268
                tmp___303 = 1;
              } else {
#line 3268
                tmp___303 = 0;
              }
            }
          } else {
#line 3268
            tmp___303 = 0;
          }
        }
#line 3268
        if (tmp___303) {
          {
#line 3268
          tmp___295 = __dyc_funcallvar_89;
          }
        } else {
          {
#line 3268
          tmp___300 = __dyc_funcallvar_90;
#line 3268
          tmp___295 = tmp___300;
          }
        }
      } else {
        {
#line 3268
        tmp___300 = __dyc_funcallvar_91;
#line 3268
        tmp___295 = tmp___300;
        }
      }
#line 3268
      if (! (tmp___295 == 0)) {
#line 3268
        if (0) {
          {
#line 3268
          tmp___319 = __dyc_funcallvar_92;
#line 3268
          __s1_len___14 = (unsigned long )tmp___319;
#line 3268
          tmp___320 = __dyc_funcallvar_93;
#line 3268
          __s2_len___14 = (unsigned long )tmp___320;
          }
#line 3268
          if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
            goto _L___34;
          } else {
#line 3268
            if (__s1_len___14 >= 4UL) {
              _L___34: /* CIL Label */ 
#line 3268
              if (! ((unsigned long )((void const   *)("digit" + 1)) - (unsigned long )((void const   *)"digit") == 1UL)) {
#line 3268
                tmp___321 = 1;
              } else {
#line 3268
                if (__s2_len___14 >= 4UL) {
#line 3268
                  tmp___321 = 1;
                } else {
#line 3268
                  tmp___321 = 0;
                }
              }
            } else {
#line 3268
              tmp___321 = 0;
            }
          }
#line 3268
          if (tmp___321) {
            {
#line 3268
            tmp___313 = __dyc_funcallvar_94;
            }
          } else {
            {
#line 3268
            tmp___318 = __dyc_funcallvar_95;
#line 3268
            tmp___313 = tmp___318;
            }
          }
        } else {
          {
#line 3268
          tmp___318 = __dyc_funcallvar_96;
#line 3268
          tmp___313 = tmp___318;
          }
        }
#line 3268
        if (! (tmp___313 == 0)) {
#line 3268
          if (0) {
            {
#line 3268
            tmp___337 = __dyc_funcallvar_97;
#line 3268
            __s1_len___15 = (unsigned long )tmp___337;
#line 3268
            tmp___338 = __dyc_funcallvar_98;
#line 3268
            __s2_len___15 = (unsigned long )tmp___338;
            }
#line 3268
            if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
              goto _L___36;
            } else {
#line 3268
              if (__s1_len___15 >= 4UL) {
                _L___36: /* CIL Label */ 
#line 3268
                if (! ((unsigned long )((void const   *)("alnum" + 1)) - (unsigned long )((void const   *)"alnum") == 1UL)) {
#line 3268
                  tmp___339 = 1;
                } else {
#line 3268
                  if (__s2_len___15 >= 4UL) {
#line 3268
                    tmp___339 = 1;
                  } else {
#line 3268
                    tmp___339 = 0;
                  }
                }
              } else {
#line 3268
                tmp___339 = 0;
              }
            }
#line 3268
            if (tmp___339) {
              {
#line 3268
              tmp___331 = __dyc_funcallvar_99;
              }
            } else {
              {
#line 3268
              tmp___336 = __dyc_funcallvar_100;
#line 3268
              tmp___331 = tmp___336;
              }
            }
          } else {
            {
#line 3268
            tmp___336 = __dyc_funcallvar_101;
#line 3268
            tmp___331 = tmp___336;
            }
          }
#line 3268
          if (! (tmp___331 == 0)) {
#line 3268
            if (0) {
              {
#line 3268
              tmp___355 = __dyc_funcallvar_102;
#line 3268
              __s1_len___16 = (unsigned long )tmp___355;
#line 3268
              tmp___356 = __dyc_funcallvar_103;
#line 3268
              __s2_len___16 = (unsigned long )tmp___356;
              }
#line 3268
              if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                goto _L___38;
              } else {
#line 3268
                if (__s1_len___16 >= 4UL) {
                  _L___38: /* CIL Label */ 
#line 3268
                  if (! ((unsigned long )((void const   *)("xdigit" + 1)) - (unsigned long )((void const   *)"xdigit") == 1UL)) {
#line 3268
                    tmp___357 = 1;
                  } else {
#line 3268
                    if (__s2_len___16 >= 4UL) {
#line 3268
                      tmp___357 = 1;
                    } else {
#line 3268
                      tmp___357 = 0;
                    }
                  }
                } else {
#line 3268
                  tmp___357 = 0;
                }
              }
#line 3268
              if (tmp___357) {
                {
#line 3268
                tmp___349 = __dyc_funcallvar_104;
                }
              } else {
                {
#line 3268
                tmp___354 = __dyc_funcallvar_105;
#line 3268
                tmp___349 = tmp___354;
                }
              }
            } else {
              {
#line 3268
              tmp___354 = __dyc_funcallvar_106;
#line 3268
              tmp___349 = tmp___354;
              }
            }
#line 3268
            if (! (tmp___349 == 0)) {
#line 3268
              if (0) {
                {
#line 3268
                tmp___373 = __dyc_funcallvar_107;
#line 3268
                __s1_len___17 = (unsigned long )tmp___373;
#line 3268
                tmp___374 = __dyc_funcallvar_108;
#line 3268
                __s2_len___17 = (unsigned long )tmp___374;
                }
#line 3268
                if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                  goto _L___40;
                } else {
#line 3268
                  if (__s1_len___17 >= 4UL) {
                    _L___40: /* CIL Label */ 
#line 3268
                    if (! ((unsigned long )((void const   *)("space" + 1)) - (unsigned long )((void const   *)"space") == 1UL)) {
#line 3268
                      tmp___375 = 1;
                    } else {
#line 3268
                      if (__s2_len___17 >= 4UL) {
#line 3268
                        tmp___375 = 1;
                      } else {
#line 3268
                        tmp___375 = 0;
                      }
                    }
                  } else {
#line 3268
                    tmp___375 = 0;
                  }
                }
#line 3268
                if (tmp___375) {
                  {
#line 3268
                  tmp___367 = __dyc_funcallvar_109;
                  }
                } else {
                  {
#line 3268
                  tmp___372 = __dyc_funcallvar_110;
#line 3268
                  tmp___367 = tmp___372;
                  }
                }
              } else {
                {
#line 3268
                tmp___372 = __dyc_funcallvar_111;
#line 3268
                tmp___367 = tmp___372;
                }
              }
#line 3268
              if (! (tmp___367 == 0)) {
#line 3268
                if (0) {
                  {
#line 3268
                  tmp___391 = __dyc_funcallvar_112;
#line 3268
                  __s1_len___18 = (unsigned long )tmp___391;
#line 3268
                  tmp___392 = __dyc_funcallvar_113;
#line 3268
                  __s2_len___18 = (unsigned long )tmp___392;
                  }
#line 3268
                  if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                    goto _L___42;
                  } else {
#line 3268
                    if (__s1_len___18 >= 4UL) {
                      _L___42: /* CIL Label */ 
#line 3268
                      if (! ((unsigned long )((void const   *)("print" + 1)) - (unsigned long )((void const   *)"print") == 1UL)) {
#line 3268
                        tmp___393 = 1;
                      } else {
#line 3268
                        if (__s2_len___18 >= 4UL) {
#line 3268
                          tmp___393 = 1;
                        } else {
#line 3268
                          tmp___393 = 0;
                        }
                      }
                    } else {
#line 3268
                      tmp___393 = 0;
                    }
                  }
#line 3268
                  if (tmp___393) {
                    {
#line 3268
                    tmp___385 = __dyc_funcallvar_114;
                    }
                  } else {
                    {
#line 3268
                    tmp___390 = __dyc_funcallvar_115;
#line 3268
                    tmp___385 = tmp___390;
                    }
                  }
                } else {
                  {
#line 3268
                  tmp___390 = __dyc_funcallvar_116;
#line 3268
                  tmp___385 = tmp___390;
                  }
                }
#line 3268
                if (! (tmp___385 == 0)) {
#line 3268
                  if (0) {
                    {
#line 3268
                    tmp___409 = __dyc_funcallvar_117;
#line 3268
                    __s1_len___19 = (unsigned long )tmp___409;
#line 3268
                    tmp___410 = __dyc_funcallvar_118;
#line 3268
                    __s2_len___19 = (unsigned long )tmp___410;
                    }
#line 3268
                    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                      goto _L___44;
                    } else {
#line 3268
                      if (__s1_len___19 >= 4UL) {
                        _L___44: /* CIL Label */ 
#line 3268
                        if (! ((unsigned long )((void const   *)("punct" + 1)) - (unsigned long )((void const   *)"punct") == 1UL)) {
#line 3268
                          tmp___411 = 1;
                        } else {
#line 3268
                          if (__s2_len___19 >= 4UL) {
#line 3268
                            tmp___411 = 1;
                          } else {
#line 3268
                            tmp___411 = 0;
                          }
                        }
                      } else {
#line 3268
                        tmp___411 = 0;
                      }
                    }
#line 3268
                    if (tmp___411) {
                      {
#line 3268
                      tmp___403 = __dyc_funcallvar_119;
                      }
                    } else {
                      {
#line 3268
                      tmp___408 = __dyc_funcallvar_120;
#line 3268
                      tmp___403 = tmp___408;
                      }
                    }
                  } else {
                    {
#line 3268
                    tmp___408 = __dyc_funcallvar_121;
#line 3268
                    tmp___403 = tmp___408;
                    }
                  }
#line 3268
                  if (! (tmp___403 == 0)) {
#line 3268
                    if (0) {
                      {
#line 3268
                      tmp___427 = __dyc_funcallvar_122;
#line 3268
                      __s1_len___20 = (unsigned long )tmp___427;
#line 3268
                      tmp___428 = __dyc_funcallvar_123;
#line 3268
                      __s2_len___20 = (unsigned long )tmp___428;
                      }
#line 3268
                      if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                        goto _L___46;
                      } else {
#line 3268
                        if (__s1_len___20 >= 4UL) {
                          _L___46: /* CIL Label */ 
#line 3268
                          if (! ((unsigned long )((void const   *)("graph" + 1)) - (unsigned long )((void const   *)"graph") == 1UL)) {
#line 3268
                            tmp___429 = 1;
                          } else {
#line 3268
                            if (__s2_len___20 >= 4UL) {
#line 3268
                              tmp___429 = 1;
                            } else {
#line 3268
                              tmp___429 = 0;
                            }
                          }
                        } else {
#line 3268
                          tmp___429 = 0;
                        }
                      }
#line 3268
                      if (tmp___429) {
                        {
#line 3268
                        tmp___421 = __dyc_funcallvar_124;
                        }
                      } else {
                        {
#line 3268
                        tmp___426 = __dyc_funcallvar_125;
#line 3268
                        tmp___421 = tmp___426;
                        }
                      }
                    } else {
                      {
#line 3268
                      tmp___426 = __dyc_funcallvar_126;
#line 3268
                      tmp___421 = tmp___426;
                      }
                    }
#line 3268
                    if (! (tmp___421 == 0)) {
#line 3268
                      if (0) {
                        {
#line 3268
                        tmp___445 = __dyc_funcallvar_127;
#line 3268
                        __s1_len___21 = (unsigned long )tmp___445;
#line 3268
                        tmp___446 = __dyc_funcallvar_128;
#line 3268
                        __s2_len___21 = (unsigned long )tmp___446;
                        }
#line 3268
                        if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                          goto _L___48;
                        } else {
#line 3268
                          if (__s1_len___21 >= 4UL) {
                            _L___48: /* CIL Label */ 
#line 3268
                            if (! ((unsigned long )((void const   *)("cntrl" + 1)) - (unsigned long )((void const   *)"cntrl") == 1UL)) {
#line 3268
                              tmp___447 = 1;
                            } else {
#line 3268
                              if (__s2_len___21 >= 4UL) {
#line 3268
                                tmp___447 = 1;
                              } else {
#line 3268
                                tmp___447 = 0;
                              }
                            }
                          } else {
#line 3268
                            tmp___447 = 0;
                          }
                        }
#line 3268
                        if (tmp___447) {
                          {
#line 3268
                          tmp___439 = __dyc_funcallvar_129;
                          }
                        } else {
                          {
#line 3268
                          tmp___444 = __dyc_funcallvar_130;
#line 3268
                          tmp___439 = tmp___444;
                          }
                        }
                      } else {
                        {
#line 3268
                        tmp___444 = __dyc_funcallvar_131;
#line 3268
                        tmp___439 = tmp___444;
                        }
                      }
#line 3268
                      if (! (tmp___439 == 0)) {
#line 3268
                        if (0) {
                          {
#line 3268
                          tmp___463 = __dyc_funcallvar_132;
#line 3268
                          __s1_len___22 = (unsigned long )tmp___463;
#line 3268
                          tmp___464 = __dyc_funcallvar_133;
#line 3268
                          __s2_len___22 = (unsigned long )tmp___464;
                          }
#line 3268
                          if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
                            goto _L___50;
                          } else {
#line 3268
                            if (__s1_len___22 >= 4UL) {
                              _L___50: /* CIL Label */ 
#line 3268
                              if (! ((unsigned long )((void const   *)("blank" + 1)) - (unsigned long )((void const   *)"blank") == 1UL)) {
#line 3268
                                tmp___465 = 1;
                              } else {
#line 3268
                                if (__s2_len___22 >= 4UL) {
#line 3268
                                  tmp___465 = 1;
                                } else {
#line 3268
                                  tmp___465 = 0;
                                }
                              }
                            } else {
#line 3268
                              tmp___465 = 0;
                            }
                          }
#line 3268
                          if (tmp___465) {
                            {
#line 3268
                            tmp___457 = __dyc_funcallvar_134;
                            }
                          } else {
                            {
#line 3268
                            tmp___462 = __dyc_funcallvar_135;
#line 3268
                            tmp___457 = tmp___462;
                            }
                          }
                        } else {
                          {
#line 3268
                          tmp___462 = __dyc_funcallvar_136;
#line 3268
                          tmp___457 = tmp___462;
                          }
                        }
#line 3268
                        if (! (tmp___457 == 0)) {
                          {

                          }
                          goto __dyc_dummy_label;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
#line 3273
  while (1) {
    while_37_continue: /* CIL Label */ ;
#line 3273
    if ((unsigned long )p == (unsigned long )pend) {
      goto __dyc_dummy_label;
    }
#line 3273
    tmp___466 = p;
#line 3273
    p ++;
#line 3273
    c = (unsigned char )*tmp___466;
#line 3273
    if (translate) {
#line 3273
      c = (unsigned char )*(translate + c);
    }
    goto while_37_break;
  }
  while_37_break: /* CIL Label */ ;
#line 3275
  if ((unsigned long )p == (unsigned long )pend) {
    {

    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(c);
  __dyc_printpre_byte(__s1_len___12);
  __dyc_printpre_byte(__s2_len___12);
  __dyc_printpre_byte(__s1_len___13);
  __dyc_printpre_byte(__s2_len___13);
  __dyc_printpre_byte(__s1_len___14);
  __dyc_printpre_byte(__s2_len___14);
  __dyc_printpre_byte(__s1_len___15);
  __dyc_printpre_byte(__s2_len___15);
  __dyc_printpre_byte(__s1_len___16);
  __dyc_printpre_byte(__s2_len___16);
  __dyc_printpre_byte(__s1_len___17);
  __dyc_printpre_byte(__s2_len___17);
  __dyc_printpre_byte(__s1_len___18);
  __dyc_printpre_byte(__s2_len___18);
  __dyc_printpre_byte(__s1_len___19);
  __dyc_printpre_byte(__s2_len___19);
  __dyc_printpre_byte(__s1_len___20);
  __dyc_printpre_byte(__s2_len___20);
  __dyc_printpre_byte(__s1_len___21);
  __dyc_printpre_byte(__s2_len___21);
  __dyc_printpre_byte(__s1_len___22);
  __dyc_printpre_byte(__s2_len___22);
}
}
