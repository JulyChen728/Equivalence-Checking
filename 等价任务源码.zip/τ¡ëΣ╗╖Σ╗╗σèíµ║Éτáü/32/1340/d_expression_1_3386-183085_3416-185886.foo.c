#include <dycfoo.h>
#include "../cp-demangle.i.hd.c.h"
void __dyc_foo(void) 
{ struct demangle_component *op ;
  char const   *code ;
  int args ;
  struct demangle_component *tmp___12 ;
  struct demangle_component *tmp___13 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___23 ;
  int tmp___28 ;
  int tmp___29 ;
  int tmp___30 ;
  int tmp___31 ;
  struct demangle_component *tmp___32 ;
  struct demangle_component *operand ;
  int suffix ;
  int tmp___33 ;
  int tmp___34 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___44 ;
  int tmp___49 ;
  int tmp___50 ;
  int tmp___51 ;
  int tmp___52 ;
  int tmp___53 ;
  struct demangle_component *tmp___54 ;
  struct demangle_component *left ;
  struct demangle_component *right ;
  int tmp___55 ;
  struct demangle_component *tmp___56 ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___66 ;
  int tmp___71 ;
  int tmp___72 ;
  int tmp___73 ;
  int tmp___74 ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___84 ;
  int tmp___89 ;
  int tmp___90 ;
  int tmp___91 ;
  int tmp___92 ;
  size_t __s1_len___3 ;
  size_t __s2_len___3 ;
  int tmp___102 ;
  int tmp___107 ;
  int tmp___108 ;
  int tmp___109 ;
  int tmp___110 ;
  struct demangle_component *tmp___111 ;
  struct demangle_component *tmp___112 ;
  struct demangle_component *first ;
  struct demangle_component *second ;
  struct demangle_component *third ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___122 ;
  int tmp___127 ;
  int tmp___128 ;
  int tmp___129 ;
  int tmp___130 ;
  struct demangle_component *tmp___131 ;
  struct demangle_component *tmp___132 ;
  struct demangle_component *tmp___133 ;
  struct d_info *di ;
  struct demangle_component *__dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  struct demangle_component *__dyc_funcallvar_25 ;
  struct demangle_component *__dyc_funcallvar_26 ;
  struct demangle_component *__dyc_funcallvar_27 ;
  struct demangle_component *__dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;
  int __dyc_funcallvar_30 ;
  int __dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  int __dyc_funcallvar_33 ;
  struct demangle_component *__dyc_funcallvar_34 ;
  struct demangle_component *__dyc_funcallvar_35 ;
  struct demangle_component *__dyc_funcallvar_36 ;
  struct demangle_component *__dyc_funcallvar_37 ;
  struct demangle_component *__dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  struct demangle_component *__dyc_funcallvar_40 ;
  struct demangle_component *__dyc_funcallvar_41 ;
  struct demangle_component *__dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;
  int __dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  int __dyc_funcallvar_50 ;
  int __dyc_funcallvar_51 ;
  int __dyc_funcallvar_52 ;
  int __dyc_funcallvar_53 ;
  int __dyc_funcallvar_54 ;
  int __dyc_funcallvar_55 ;
  int __dyc_funcallvar_56 ;
  int __dyc_funcallvar_57 ;
  struct demangle_component *__dyc_funcallvar_58 ;
  struct demangle_component *__dyc_funcallvar_59 ;
  struct demangle_component *__dyc_funcallvar_60 ;
  struct demangle_component *__dyc_funcallvar_61 ;
  struct demangle_component *__dyc_funcallvar_62 ;
  struct demangle_component *__dyc_funcallvar_63 ;
  struct demangle_component *__dyc_funcallvar_64 ;
  int __dyc_funcallvar_65 ;
  int __dyc_funcallvar_66 ;
  int __dyc_funcallvar_67 ;
  int __dyc_funcallvar_68 ;
  int __dyc_funcallvar_69 ;
  struct demangle_component *__dyc_funcallvar_70 ;
  struct demangle_component *__dyc_funcallvar_71 ;
  struct demangle_component *__dyc_funcallvar_72 ;
  struct demangle_component *__dyc_funcallvar_73 ;
  struct demangle_component *__dyc_funcallvar_74 ;
  struct demangle_component *__dyc_funcallvar_75 ;
  struct demangle_component *__dyc_funcallvar_76 ;
  struct demangle_component *__dyc_funcallvar_77 ;
  struct demangle_component *__dyc_funcallvar_78 ;
  struct demangle_component *__dyc_funcallvar_79 ;
  struct demangle_component *__dyc_funcallvar_80 ;
  struct demangle_component *__dyc_funcallvar_81 ;
  struct demangle_component *__dyc_funcallvar_82 ;

  {
  code = (char const   *)__dyc_read_ptr__char();
  di = __dyc_read_ptr__comp_60d_info();
  __dyc_funcallvar_19 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_26 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_27 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_28 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  __dyc_funcallvar_31 = __dyc_readpre_byte();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_35 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_36 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_37 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_38 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_41 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_42 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = __dyc_readpre_byte();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_readpre_byte();
  __dyc_funcallvar_51 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  __dyc_funcallvar_53 = __dyc_readpre_byte();
  __dyc_funcallvar_54 = __dyc_readpre_byte();
  __dyc_funcallvar_55 = __dyc_readpre_byte();
  __dyc_funcallvar_56 = __dyc_readpre_byte();
  __dyc_funcallvar_57 = __dyc_readpre_byte();
  __dyc_funcallvar_58 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_59 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_60 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_61 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_62 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_63 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_64 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_65 = __dyc_readpre_byte();
  __dyc_funcallvar_66 = __dyc_readpre_byte();
  __dyc_funcallvar_67 = __dyc_readpre_byte();
  __dyc_funcallvar_68 = __dyc_readpre_byte();
  __dyc_funcallvar_69 = __dyc_readpre_byte();
  __dyc_funcallvar_70 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_71 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_72 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_73 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_74 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_75 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_76 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_77 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_78 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_79 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_80 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_81 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_82 = __dyc_read_ptr__comp_46demangle_component();
  op = 0;
  args = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  __s1_len = 0;
  __s2_len = 0;
  tmp___23 = 0;
  tmp___28 = 0;
  tmp___29 = 0;
  tmp___30 = 0;
  tmp___31 = 0;
  tmp___32 = 0;
  operand = 0;
  suffix = 0;
  tmp___33 = 0;
  tmp___34 = 0;
  __s1_len___0 = 0;
  __s2_len___0 = 0;
  tmp___44 = 0;
  tmp___49 = 0;
  tmp___50 = 0;
  tmp___51 = 0;
  tmp___52 = 0;
  tmp___53 = 0;
  tmp___54 = 0;
  left = 0;
  right = 0;
  tmp___55 = 0;
  tmp___56 = 0;
  __s1_len___1 = 0;
  __s2_len___1 = 0;
  tmp___66 = 0;
  tmp___71 = 0;
  tmp___72 = 0;
  tmp___73 = 0;
  tmp___74 = 0;
  __s1_len___2 = 0;
  __s2_len___2 = 0;
  tmp___84 = 0;
  tmp___89 = 0;
  tmp___90 = 0;
  tmp___91 = 0;
  tmp___92 = 0;
  __s1_len___3 = 0;
  __s2_len___3 = 0;
  tmp___102 = 0;
  tmp___107 = 0;
  tmp___108 = 0;
  tmp___109 = 0;
  tmp___110 = 0;
  tmp___111 = 0;
  tmp___112 = 0;
  first = 0;
  second = 0;
  third = 0;
  __s1_len___4 = 0;
  __s2_len___4 = 0;
  tmp___122 = 0;
  tmp___127 = 0;
  tmp___128 = 0;
  tmp___129 = 0;
  tmp___130 = 0;
  tmp___131 = 0;
  tmp___132 = 0;
  tmp___133 = 0;
#line 3386
  op = __dyc_funcallvar_19;
#line 3387
  if ((unsigned long )op == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }
#line 3390
  if ((int )op->type == 50) {
#line 3392
    code = (char const   *)(op->u.s_operator.op)->code;
#line 3393
    di->expansion += (int )((op->u.s_operator.op)->len - 2);
#line 3394
    if (0) {
      {
#line 3394
      tmp___29 = __dyc_funcallvar_20;
#line 3394
      __s1_len = (unsigned long )tmp___29;
#line 3394
      tmp___30 = __dyc_funcallvar_21;
#line 3394
      __s2_len = (unsigned long )tmp___30;
      }
#line 3394
      if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
        goto _L___0;
      } else {
#line 3394
        if (__s1_len >= 4UL) {
          _L___0: /* CIL Label */ 
#line 3394
          if (! ((unsigned long )((void const   *)("st" + 1)) - (unsigned long )((void const   *)"st") == 1UL)) {
#line 3394
            tmp___31 = 1;
          } else {
#line 3394
            if (__s2_len >= 4UL) {
#line 3394
              tmp___31 = 1;
            } else {
#line 3394
              tmp___31 = 0;
            }
          }
        } else {
#line 3394
          tmp___31 = 0;
        }
      }
#line 3394
      if (tmp___31) {
        {
#line 3394
        tmp___23 = __dyc_funcallvar_22;
        }
      } else {
        {
#line 3394
        tmp___28 = __dyc_funcallvar_23;
#line 3394
        tmp___23 = tmp___28;
        }
      }
    } else {
      {
#line 3394
      tmp___28 = __dyc_funcallvar_24;
#line 3394
      tmp___23 = tmp___28;
      }
    }
#line 3394
    if (tmp___23 == 0) {
      {
#line 3395
      tmp___12 = __dyc_funcallvar_25;
#line 3395
      tmp___13 = __dyc_funcallvar_26;
      }
      goto __dyc_dummy_label;
    }
  }
#line 3403
  if ((int )op->type == 50) {
    goto switch_32_50;
  } else {
#line 3406
    if ((int )op->type == 51) {
      goto switch_32_51;
    } else {
#line 3409
      if ((int )op->type == 52) {
        goto switch_32_52;
      } else {
        {
        goto switch_32_default;
#line 3399
        if (0) {
          switch_32_default: /* CIL Label */ ;
          goto __dyc_dummy_label;
          switch_32_50: /* CIL Label */ 
#line 3404
          args = (int )(op->u.s_operator.op)->args;
          goto switch_32_break;
          switch_32_51: /* CIL Label */ 
#line 3407
          args = op->u.s_extended_operator.args;
          goto switch_32_break;
          switch_32_52: /* CIL Label */ 
#line 3410
          args = 1;
          goto switch_32_break;
        } else {
          switch_32_break: /* CIL Label */ ;
        }
        }
      }
    }
  }
#line 3416
  if (args == 0) {
    goto switch_33_0;
  } else {
#line 3419
    if (args == 1) {
      goto switch_33_1;
    } else {
#line 3444
      if (args == 2) {
        goto switch_33_2;
      } else {
#line 3475
        if (args == 3) {
          goto switch_33_3;
        } else {
          {
          goto switch_33_default;
#line 3414
          if (0) {
            switch_33_0: /* CIL Label */ 
            {
#line 3417
            tmp___32 = __dyc_funcallvar_27;
            }
            goto __dyc_dummy_label;
            switch_33_1: /* CIL Label */ 
#line 3422
            suffix = 0;
#line 3424
            if (code) {
#line 3424
              if ((int const   )*(code + 0) == 112) {
                goto _L___1;
              } else {
#line 3424
                if ((int const   )*(code + 0) == 109) {
                  _L___1: /* CIL Label */ 
#line 3424
                  if ((int const   )*(code + 1) == (int const   )*(code + 0)) {
#line 3427
                    if ((int const   )*(di->n) == 95) {
#line 3427
                      (di->n) ++;
#line 3427
                      tmp___33 = 1;
                    } else {
#line 3427
                      tmp___33 = 0;
                    }
#line 3427
                    if (tmp___33) {
#line 3427
                      tmp___34 = 0;
                    } else {
#line 3427
                      tmp___34 = 1;
                    }
#line 3427
                    suffix = tmp___34;
                  }
                }
              }
            }
#line 3429
            if ((int )op->type == 52) {
#line 3429
              if ((int const   )*(di->n) == 95) {
#line 3429
                (di->n) ++;
#line 3429
                tmp___53 = 1;
              } else {
#line 3429
                tmp___53 = 0;
              }
#line 3429
              if (tmp___53) {
                {
#line 3431
                operand = __dyc_funcallvar_28;
                }
              } else {
                goto _L___4;
              }
            } else {
              _L___4: /* CIL Label */ 
#line 3432
              if (code) {
#line 3432
                if (0) {
                  {
#line 3432
                  tmp___50 = __dyc_funcallvar_29;
#line 3432
                  __s1_len___0 = (unsigned long )tmp___50;
#line 3432
                  tmp___51 = __dyc_funcallvar_30;
#line 3432
                  __s2_len___0 = (unsigned long )tmp___51;
                  }
#line 3432
                  if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
                    goto _L___3;
                  } else {
#line 3432
                    if (__s1_len___0 >= 4UL) {
                      _L___3: /* CIL Label */ 
#line 3432
                      if (! ((unsigned long )((void const   *)("sP" + 1)) - (unsigned long )((void const   *)"sP") == 1UL)) {
#line 3432
                        tmp___52 = 1;
                      } else {
#line 3432
                        if (__s2_len___0 >= 4UL) {
#line 3432
                          tmp___52 = 1;
                        } else {
#line 3432
                          tmp___52 = 0;
                        }
                      }
                    } else {
#line 3432
                      tmp___52 = 0;
                    }
                  }
#line 3432
                  if (tmp___52) {
                    {
#line 3432
                    tmp___44 = __dyc_funcallvar_31;
                    }
                  } else {
                    {
#line 3432
                    tmp___49 = __dyc_funcallvar_32;
#line 3432
                    tmp___44 = tmp___49;
                    }
                  }
                } else {
                  {
#line 3432
                  tmp___49 = __dyc_funcallvar_33;
#line 3432
                  tmp___44 = tmp___49;
                  }
                }
#line 3432
                if (tmp___44) {
                  {
#line 3435
                  operand = __dyc_funcallvar_34;
                  }
                } else {
                  {
#line 3433
                  operand = __dyc_funcallvar_35;
                  }
                }
              } else {
                {
#line 3435
                operand = __dyc_funcallvar_36;
                }
              }
            }
#line 3437
            if (suffix) {
              {
#line 3439
              operand = __dyc_funcallvar_37;
              }
            }
            {
#line 3442
            tmp___54 = __dyc_funcallvar_38;
            }
            goto __dyc_dummy_label;
            switch_33_2: /* CIL Label */ 
#line 3449
            if ((unsigned long )code == (unsigned long )((void *)0)) {
              goto __dyc_dummy_label;
            }
            {
#line 3451
            tmp___55 = __dyc_funcallvar_39;
            }
#line 3451
            if (tmp___55) {
              {
#line 3452
              left = __dyc_funcallvar_40;
              }
            } else {
#line 3453
              if ((int const   )*(code + 0) == 102) {
                {
#line 3455
                left = __dyc_funcallvar_41;
                }
              } else {
                {
#line 3457
                left = __dyc_funcallvar_42;
                }
              }
            }
#line 3458
            if (0) {
              {
#line 3458
              tmp___108 = __dyc_funcallvar_43;
#line 3458
              __s1_len___3 = (unsigned long )tmp___108;
#line 3458
              tmp___109 = __dyc_funcallvar_44;
#line 3458
              __s2_len___3 = (unsigned long )tmp___109;
              }
#line 3458
              if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
                goto _L___11;
              } else {
#line 3458
                if (__s1_len___3 >= 4UL) {
                  _L___11: /* CIL Label */ 
#line 3458
                  if (! ((unsigned long )((void const   *)("cl" + 1)) - (unsigned long )((void const   *)"cl") == 1UL)) {
#line 3458
                    tmp___110 = 1;
                  } else {
#line 3458
                    if (__s2_len___3 >= 4UL) {
#line 3458
                      tmp___110 = 1;
                    } else {
#line 3458
                      tmp___110 = 0;
                    }
                  }
                } else {
#line 3458
                  tmp___110 = 0;
                }
              }
#line 3458
              if (tmp___110) {
                {
#line 3458
                tmp___102 = __dyc_funcallvar_45;
                }
              } else {
                {
#line 3458
                tmp___107 = __dyc_funcallvar_46;
#line 3458
                tmp___102 = tmp___107;
                }
              }
            } else {
              {
#line 3458
              tmp___107 = __dyc_funcallvar_47;
#line 3458
              tmp___102 = tmp___107;
              }
            }
#line 3458
            if (tmp___102) {
#line 3460
              if (0) {
                {
#line 3460
                tmp___72 = __dyc_funcallvar_48;
#line 3460
                __s1_len___1 = (unsigned long )tmp___72;
#line 3460
                tmp___73 = __dyc_funcallvar_49;
#line 3460
                __s2_len___1 = (unsigned long )tmp___73;
                }
#line 3460
                if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
                  goto _L___6;
                } else {
#line 3460
                  if (__s1_len___1 >= 4UL) {
                    _L___6: /* CIL Label */ 
#line 3460
                    if (! ((unsigned long )((void const   *)("dt" + 1)) - (unsigned long )((void const   *)"dt") == 1UL)) {
#line 3460
                      tmp___74 = 1;
                    } else {
#line 3460
                      if (__s2_len___1 >= 4UL) {
#line 3460
                        tmp___74 = 1;
                      } else {
#line 3460
                        tmp___74 = 0;
                      }
                    }
                  } else {
#line 3460
                    tmp___74 = 0;
                  }
                }
#line 3460
                if (tmp___74) {
                  {
#line 3460
                  tmp___66 = __dyc_funcallvar_50;
                  }
                } else {
                  {
#line 3460
                  tmp___71 = __dyc_funcallvar_51;
#line 3460
                  tmp___66 = tmp___71;
                  }
                }
              } else {
                {
#line 3460
                tmp___71 = __dyc_funcallvar_52;
#line 3460
                tmp___66 = tmp___71;
                }
              }
#line 3460
              if (tmp___66) {
#line 3460
                if (0) {
                  {
#line 3460
                  tmp___90 = __dyc_funcallvar_53;
#line 3460
                  __s1_len___2 = (unsigned long )tmp___90;
#line 3460
                  tmp___91 = __dyc_funcallvar_54;
#line 3460
                  __s2_len___2 = (unsigned long )tmp___91;
                  }
#line 3460
                  if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
                    goto _L___8;
                  } else {
#line 3460
                    if (__s1_len___2 >= 4UL) {
                      _L___8: /* CIL Label */ 
#line 3460
                      if (! ((unsigned long )((void const   *)("pt" + 1)) - (unsigned long )((void const   *)"pt") == 1UL)) {
#line 3460
                        tmp___92 = 1;
                      } else {
#line 3460
                        if (__s2_len___2 >= 4UL) {
#line 3460
                          tmp___92 = 1;
                        } else {
#line 3460
                          tmp___92 = 0;
                        }
                      }
                    } else {
#line 3460
                      tmp___92 = 0;
                    }
                  }
#line 3460
                  if (tmp___92) {
                    {
#line 3460
                    tmp___84 = __dyc_funcallvar_55;
                    }
                  } else {
                    {
#line 3460
                    tmp___89 = __dyc_funcallvar_56;
#line 3460
                    tmp___84 = tmp___89;
                    }
                  }
                } else {
                  {
#line 3460
                  tmp___89 = __dyc_funcallvar_57;
#line 3460
                  tmp___84 = tmp___89;
                  }
                }
#line 3460
                if (tmp___84) {
                  {
#line 3468
                  right = __dyc_funcallvar_58;
                  }
                } else {
                  _L___9: /* CIL Label */ 
                  {
#line 3462
                  right = __dyc_funcallvar_59;
                  }
#line 3463
                  if ((int const   )*(di->n) == 73) {
                    {
#line 3464
                    tmp___56 = __dyc_funcallvar_60;
#line 3464
                    right = __dyc_funcallvar_61;
                    }
                  }
                }
              } else {
                goto _L___9;
              }
            } else {
              {
#line 3459
              right = __dyc_funcallvar_62;
              }
            }
            {
#line 3470
            tmp___111 = __dyc_funcallvar_63;
#line 3470
            tmp___112 = __dyc_funcallvar_64;
            }
            goto __dyc_dummy_label;
            switch_33_3: /* CIL Label */ 
#line 3481
            if ((unsigned long )code == (unsigned long )((void *)0)) {
              goto __dyc_dummy_label;
            } else {
#line 3483
              if (0) {
                {
#line 3483
                tmp___128 = __dyc_funcallvar_65;
#line 3483
                __s1_len___4 = (unsigned long )tmp___128;
#line 3483
                tmp___129 = __dyc_funcallvar_66;
#line 3483
                __s2_len___4 = (unsigned long )tmp___129;
                }
#line 3483
                if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
                  goto _L___14;
                } else {
#line 3483
                  if (__s1_len___4 >= 4UL) {
                    _L___14: /* CIL Label */ 
#line 3483
                    if (! ((unsigned long )((void const   *)("qu" + 1)) - (unsigned long )((void const   *)"qu") == 1UL)) {
#line 3483
                      tmp___130 = 1;
                    } else {
#line 3483
                      if (__s2_len___4 >= 4UL) {
#line 3483
                        tmp___130 = 1;
                      } else {
#line 3483
                        tmp___130 = 0;
                      }
                    }
                  } else {
#line 3483
                    tmp___130 = 0;
                  }
                }
#line 3483
                if (tmp___130) {
                  {
#line 3483
                  tmp___122 = __dyc_funcallvar_67;
                  }
                } else {
                  {
#line 3483
                  tmp___127 = __dyc_funcallvar_68;
#line 3483
                  tmp___122 = tmp___127;
                  }
                }
              } else {
                {
#line 3483
                tmp___127 = __dyc_funcallvar_69;
#line 3483
                tmp___122 = tmp___127;
                }
              }
#line 3483
              if (tmp___122) {
#line 3492
                if ((int const   )*(code + 0) == 102) {
                  {
#line 3495
                  first = __dyc_funcallvar_70;
#line 3496
                  second = __dyc_funcallvar_71;
#line 3497
                  third = __dyc_funcallvar_72;
                  }
#line 3498
                  if ((unsigned long )third == (unsigned long )((void *)0)) {
                    goto __dyc_dummy_label;
                  }
                } else {
#line 3501
                  if ((int const   )*(code + 0) == 110) {
#line 3504
                    if ((int const   )*(code + 1) != 119) {
#line 3504
                      if ((int const   )*(code + 1) != 97) {
                        goto __dyc_dummy_label;
                      }
                    }
                    {
#line 3506
                    first = __dyc_funcallvar_73;
#line 3507
                    second = __dyc_funcallvar_74;
                    }
#line 3508
                    if ((int const   )*(di->n) == 69) {
#line 3510
                      (di->n) ++;
#line 3511
                      third = (struct demangle_component *)((void *)0);
                    } else {
#line 3513
                      if ((int const   )*(di->n) == 112) {
#line 3513
                        if ((int const   )*(di->n + 1) == 105) {
                          {
#line 3517
                          di->n += 2;
#line 3518
                          third = __dyc_funcallvar_75;
                          }
                        } else {
                          goto _L___12;
                        }
                      } else {
                        _L___12: /* CIL Label */ 
#line 3520
                        if ((int const   )*(di->n) == 105) {
#line 3520
                          if ((int const   )*(di->n + 1) == 108) {
                            {
#line 3523
                            third = __dyc_funcallvar_76;
                            }
                          } else {
                            goto __dyc_dummy_label;
                          }
                        } else {
                          goto __dyc_dummy_label;
                        }
                      }
                    }
                  } else {
                    goto __dyc_dummy_label;
                  }
                }
              } else {
                {
#line 3486
                first = __dyc_funcallvar_77;
#line 3487
                second = __dyc_funcallvar_78;
#line 3488
                third = __dyc_funcallvar_79;
                }
#line 3489
                if ((unsigned long )third == (unsigned long )((void *)0)) {
                  goto __dyc_dummy_label;
                }
              }
            }
            {
#line 3529
            tmp___131 = __dyc_funcallvar_80;
#line 3529
            tmp___132 = __dyc_funcallvar_81;
#line 3529
            tmp___133 = __dyc_funcallvar_82;
            }
            goto __dyc_dummy_label;
            switch_33_default: /* CIL Label */ ;
            goto __dyc_dummy_label;
          } else {
            switch_33_break: /* CIL Label */ ;
          }
          }
        }
      }
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__char(code);
  __dyc_print_ptr__comp_46demangle_component(tmp___12);
  __dyc_print_ptr__comp_46demangle_component(tmp___13);
  __dyc_printpre_byte(__s1_len);
  __dyc_printpre_byte(__s2_len);
  __dyc_print_ptr__comp_46demangle_component(tmp___32);
  __dyc_print_ptr__comp_46demangle_component(operand);
  __dyc_printpre_byte(__s1_len___0);
  __dyc_printpre_byte(__s2_len___0);
  __dyc_print_ptr__comp_46demangle_component(tmp___54);
  __dyc_print_ptr__comp_46demangle_component(left);
  __dyc_print_ptr__comp_46demangle_component(right);
  __dyc_print_ptr__comp_46demangle_component(tmp___56);
  __dyc_printpre_byte(__s1_len___1);
  __dyc_printpre_byte(__s2_len___1);
  __dyc_printpre_byte(__s1_len___2);
  __dyc_printpre_byte(__s2_len___2);
  __dyc_printpre_byte(__s1_len___3);
  __dyc_printpre_byte(__s2_len___3);
  __dyc_print_ptr__comp_46demangle_component(tmp___111);
  __dyc_print_ptr__comp_46demangle_component(tmp___112);
  __dyc_print_ptr__comp_46demangle_component(first);
  __dyc_print_ptr__comp_46demangle_component(second);
  __dyc_print_ptr__comp_46demangle_component(third);
  __dyc_printpre_byte(__s1_len___4);
  __dyc_printpre_byte(__s2_len___4);
  __dyc_print_ptr__comp_46demangle_component(tmp___131);
  __dyc_print_ptr__comp_46demangle_component(tmp___132);
  __dyc_print_ptr__comp_46demangle_component(tmp___133);
}
}
