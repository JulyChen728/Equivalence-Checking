#include <dycfoo.h>
#include "../dotdot.i.hd.c.h"
void __dyc_foo(void) 
{ size_t inlen ;
  char *clone ;
  size_t clen ;
  char *out ;
  void *tmp___0 ;
  char *outptr ;
  char *orgclone ;
  char *queryp ;
  void *__dyc_funcallvar_2 ;
  char *__dyc_funcallvar_3 ;
  char *__dyc_funcallvar_4 ;

  {
  inlen = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_read_ptr__void();
  __dyc_funcallvar_3 = __dyc_read_ptr__char();
  __dyc_funcallvar_4 = __dyc_read_ptr__char();
  clone = 0;
  clen = 0;
  out = 0;
  tmp___0 = 0;
  outptr = 0;
  orgclone = 0;
  queryp = 0;
#line 57
  clen = inlen;
#line 58
  tmp___0 = __dyc_funcallvar_2;
#line 58
  out = (char *)tmp___0;
#line 62
  if (! out) {
    goto __dyc_dummy_label;
  }
#line 65
  *out = (char)0;
#line 68
  clone = __dyc_funcallvar_3;
#line 69
  if (! clone) {
    {

    }
    goto __dyc_dummy_label;
  }
#line 73
  orgclone = clone;
#line 74
  outptr = out;
#line 76
  if (! *clone) {
    {

    }
    goto __dyc_dummy_label;
  }
#line 87
  queryp = __dyc_funcallvar_4;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(clen);
  __dyc_print_ptr__char(outptr);
  __dyc_print_ptr__char(orgclone);
  __dyc_print_ptr__char(queryp);
}
}
