#include <dycfoo.h>
#include "../inet_ntop.i.hd.c.h"
void __dyc_foo(void) 
{ char tmp[sizeof("ffff:ffff:ffff:ffff:ffff:ffff:255.255.255.255")] ;
  char *tp ;
  struct __anonstruct_best_74 best ;
  struct __anonstruct_best_74 cur ;
  unsigned long words[8] ;
  int i ;

  {

  tp = 0;
  memset(& best, 0, sizeof(struct __anonstruct_best_74 ));
  memset(& cur, 0, sizeof(struct __anonstruct_best_74 ));
  i = 0;
#line 103
  best.base = -1L;
#line 104
  cur.base = -1L;
#line 105
  best.len = 0L;
#line 106
  cur.len = 0L;
#line 108
  i = 0;
#line 108
  while (1) {
    while_2_continue: /* CIL Label */ ;
#line 108
    if (! (i < 8)) {
      goto while_2_break;
    }
#line 109
    if (words[i] == 0UL) {
#line 110
      if (cur.base == -1L) {
#line 111
        cur.base = (long )i;
#line 111
        cur.len = 1L;
      } else {
#line 113
        (cur.len) ++;
      }
    } else {
#line 115
      if (cur.base != -1L) {
#line 116
        if (best.base == -1L) {
#line 117
          best = cur;
        } else {
#line 116
          if (cur.len > best.len) {
#line 117
            best = cur;
          }
        }
#line 118
        cur.base = -1L;
      }
    }
#line 108
    i ++;
  }
  while_2_break: /* CIL Label */ ;
#line 121
  if (cur.base != -1L) {
#line 121
    if (best.base == -1L) {
#line 122
      best = cur;
    } else {
#line 121
      if (cur.len > best.len) {
#line 122
        best = cur;
      }
    }
  }
#line 123
  if (best.base != -1L) {
#line 123
    if (best.len < 2L) {
#line 124
      best.base = -1L;
    }
  }
#line 126
  tp = tmp;
#line 127
  i = 0;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__char(tp);
  __dyc_print_comp_92__anonstruct_best_74(best);
  __dyc_printpre_byte(i);
}
}
