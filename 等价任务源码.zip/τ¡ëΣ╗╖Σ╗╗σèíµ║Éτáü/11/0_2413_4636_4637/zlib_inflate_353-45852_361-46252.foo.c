#include <dycfoo.h>
#include "../inflate.i.hd.c.h"
void __dyc_foo(void) 
{ struct inflate_state *state ;
  unsigned char const   *next ;
  unsigned char *put ;
  unsigned int have ;
  unsigned int left ;
  unsigned long hold ;
  unsigned int bits ;
  unsigned int in ;
  unsigned int out ;
  int ret ;
  z_streamp strm ;

  {
  strm = __dyc_read_ptr__typdef_z_stream();
  state = 0;
  next = 0;
  put = 0;
  have = 0;
  left = 0;
  hold = 0;
  bits = 0;
  in = 0;
  out = 0;
  ret = 0;
#line 353
  if ((unsigned long )strm == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  } else {
#line 353
    if ((unsigned long )strm->state == (unsigned long )((void *)0)) {
      goto __dyc_dummy_label;
    } else {
#line 353
      if ((unsigned long )strm->next_in == (unsigned long )((void *)0)) {
#line 353
        if (strm->avail_in != 0U) {
          goto __dyc_dummy_label;
        }
      }
    }
  }
#line 357
  state = (struct inflate_state *)strm->state;
#line 359
  if ((int )state->mode == 11) {
#line 359
    state->mode = 12;
  }
#line 360
  while (1) {
    while_3_continue: /* CIL Label */ ;
#line 360
    put = strm->next_out;
#line 360
    left = strm->avail_out;
#line 360
    next = strm->next_in;
#line 360
    have = strm->avail_in;
#line 360
    hold = state->hold;
#line 360
    bits = state->bits;
    goto while_3_break;
  }
  while_3_break: /* CIL Label */ ;
#line 361
  in = have;
#line 362
  out = left;
#line 363
  ret = 0;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__char(next);
  __dyc_print_ptr__char(put);
  __dyc_printpre_byte(hold);
  __dyc_printpre_byte(bits);
  __dyc_printpre_byte(in);
  __dyc_printpre_byte(out);
  __dyc_printpre_byte(ret);
}
}
