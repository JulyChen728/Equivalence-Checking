#include <dycfoo.h>
#include "../printf.i.hd.c.h"
void __dyc_foo(void) 
{ int base ;
  char *str ;
  int flags ;
  char *tmp___17 ;
  char *tmp___18 ;
  char const   *fmt ;

  {
  str = __dyc_read_ptr__char();
  flags = __dyc_readpre_byte();
  fmt = (char const   *)__dyc_read_ptr__char();
  base = 0;
  tmp___17 = 0;
  tmp___18 = 0;
  switch_9_120: /* CIL Label */ 
#line 250
  base = 16;
  goto __dyc_dummy_label;
  switch_9_100: /* CIL Label */ 
  switch_9_105: /* CIL Label */ 
#line 255
  flags |= 2;
  switch_9_117: /* CIL Label */ 
  goto __dyc_dummy_label;
  switch_9_default: /* CIL Label */ 
#line 260
  tmp___17 = str;
#line 260
  str ++;
#line 260
  *tmp___17 = (char )'%';
#line 261
  if (*fmt) {
#line 262
    tmp___18 = str;
#line 262
    str ++;
#line 262
    *tmp___18 = (char )*fmt;
  } else {
#line 264
    fmt --;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(base);
  __dyc_print_ptr__char(str);
  __dyc_printpre_byte(flags);
  __dyc_print_ptr__char(fmt);
}
}
