#include <dycfoo.h>
#include "../deftree.i.hd.c.h"
void __dyc_foo(void) 
{ int prevlen ;
  int curlen ;
  int nextlen ;
  int count ;
  int max_count ;
  int min_count ;

  {
  curlen = __dyc_readpre_byte();
  nextlen = __dyc_readpre_byte();
  prevlen = 0;
  count = 0;
  max_count = 0;
  min_count = 0;
#line 657
  count = 0;
#line 657
  prevlen = curlen;
#line 658
  if (nextlen == 0) {
#line 659
    max_count = 138;
#line 659
    min_count = 3;
  } else {
#line 660
    if (curlen == nextlen) {
#line 661
      max_count = 6;
#line 661
      min_count = 3;
    } else {
#line 663
      max_count = 7;
#line 663
      min_count = 4;
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(prevlen);
  __dyc_printpre_byte(count);
  __dyc_printpre_byte(max_count);
  __dyc_printpre_byte(min_count);
}
}
