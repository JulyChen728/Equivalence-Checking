#include <dycfoo.h>
#include "../memory.i.hd.c.h"
void __dyc_foo(void) 
{ struct boot_params boot_params ;
  u16 ax ;
  u16 bx ;
  u16 cx ;
  u16 dx ;
  u8 err ;

  {
  err = (u8 )__dyc_readpre_byte();
  memset(& boot_params, 0, sizeof(struct boot_params ));
  ax = 0;
  bx = 0;
  cx = 0;
  dx = 0;
#line 65
  dx = (unsigned short)0;
#line 65
  cx = dx;
#line 65
  bx = cx;
#line 66
  ax = (unsigned short)59393;
#line 70
  if (err) {
    goto __dyc_dummy_label;
  }
#line 74
  if (cx) {
#line 75
    ax = cx;
#line 76
    bx = dx;
  } else {
#line 74
    if (dx) {
#line 75
      ax = cx;
#line 76
      bx = dx;
    }
  }
#line 79
  if ((int )ax > 15360) {
    goto __dyc_dummy_label;
  }
#line 86
  if ((int )ax == 15360) {
#line 86
    boot_params.alt_mem_k = (unsigned int )(((int )dx << 6) + (int )ax);
  } else {
#line 86
    boot_params.alt_mem_k = (unsigned int )ax;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_comp_35boot_params(boot_params);
  __dyc_printpre_byte(ax);
  __dyc_printpre_byte(bx);
}
}
