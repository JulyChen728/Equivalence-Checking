#include <dycfoo.h>
#include "../sha256.i.hd.c.h"
void __dyc_foo(void) 
{ uint32_t S[8] ;
  uint32_t W[64] ;
  uint32_t t0 ;
  uint32_t t1 ;
  int i ;
  uint32_t tmp ;
  uint32_t tmp___0 ;
  uint32_t tmp___1 ;
  uint32_t tmp___2 ;
  uint32_t tmp___3 ;
  uint32_t tmp___4 ;
  uint32_t tmp___5 ;
  uint32_t tmp___6 ;
  uint32_t tmp___7 ;
  uint32_t tmp___8 ;
  uint32_t tmp___9 ;
  uint32_t tmp___10 ;
  uint32_t tmp___11 ;
  uint32_t tmp___12 ;
  uint32_t tmp___13 ;
  uint32_t tmp___14 ;
  uint32_t tmp___15 ;
  uint32_t tmp___16 ;
  uint32_t tmp___17 ;
  uint32_t tmp___18 ;
  uint32_t tmp___19 ;
  uint32_t tmp___20 ;
  uint32_t tmp___21 ;
  uint32_t tmp___22 ;
  uint32_t tmp___23 ;
  uint32_t tmp___24 ;
  uint32_t tmp___25 ;
  uint32_t tmp___26 ;
  uint32_t tmp___27 ;
  uint32_t tmp___28 ;
  uint32_t tmp___29 ;
  uint32_t tmp___30 ;
  uint32_t tmp___31 ;
  uint32_t tmp___32 ;
  uint32_t tmp___33 ;
  uint32_t tmp___34 ;
  uint32_t tmp___35 ;
  uint32_t tmp___36 ;
  uint32_t tmp___37 ;
  uint32_t tmp___38 ;
  uint32_t tmp___39 ;
  uint32_t tmp___40 ;
  uint32_t tmp___41 ;
  uint32_t tmp___42 ;
  uint32_t tmp___43 ;
  uint32_t tmp___44 ;
  uint32_t tmp___45 ;
  uint32_t tmp___46 ;
  uint32_t tmp___47 ;
  uint32_t tmp___48 ;
  uint32_t tmp___49 ;
  uint32_t tmp___50 ;
  uint32_t tmp___51 ;
  uint32_t tmp___52 ;
  uint32_t tmp___53 ;
  uint32_t tmp___54 ;
  uint32_t tmp___55 ;
  uint32_t tmp___56 ;
  uint32_t tmp___57 ;
  uint32_t tmp___58 ;
  uint32_t tmp___59 ;
  uint32_t tmp___60 ;
  uint32_t tmp___61 ;
  uint32_t tmp___62 ;
  uint32_t tmp___63 ;
  uint32_t tmp___64 ;
  uint32_t tmp___65 ;
  uint32_t tmp___66 ;
  uint32_t tmp___67 ;
  uint32_t tmp___68 ;
  uint32_t tmp___69 ;
  uint32_t tmp___70 ;
  uint32_t tmp___71 ;
  uint32_t tmp___72 ;
  uint32_t tmp___73 ;
  uint32_t tmp___74 ;
  uint32_t tmp___75 ;
  uint32_t tmp___76 ;
  uint32_t tmp___77 ;
  uint32_t tmp___78 ;
  uint32_t tmp___79 ;
  uint32_t tmp___80 ;
  uint32_t tmp___81 ;
  uint32_t tmp___82 ;
  uint32_t tmp___83 ;
  uint32_t tmp___84 ;
  uint32_t tmp___85 ;
  uint32_t tmp___86 ;
  uint32_t tmp___87 ;
  uint32_t tmp___88 ;
  uint32_t tmp___89 ;
  uint32_t tmp___90 ;
  uint32_t tmp___91 ;
  uint32_t tmp___92 ;
  uint32_t tmp___93 ;
  uint32_t tmp___94 ;
  uint32_t tmp___95 ;
  uint32_t tmp___96 ;
  uint32_t tmp___97 ;
  uint32_t tmp___98 ;
  uint32_t tmp___99 ;
  uint32_t tmp___100 ;
  uint32_t tmp___101 ;
  uint32_t tmp___102 ;
  uint32_t tmp___103 ;
  uint32_t tmp___104 ;
  uint32_t tmp___105 ;
  uint32_t tmp___106 ;
  uint32_t tmp___107 ;
  uint32_t tmp___108 ;
  uint32_t tmp___109 ;
  uint32_t tmp___110 ;
  uint32_t tmp___111 ;
  uint32_t tmp___112 ;
  uint32_t tmp___113 ;
  uint32_t tmp___114 ;
  uint32_t tmp___115 ;
  uint32_t tmp___116 ;
  uint32_t tmp___117 ;
  uint32_t tmp___118 ;
  uint32_t tmp___119 ;
  uint32_t tmp___120 ;
  uint32_t tmp___121 ;
  uint32_t tmp___122 ;
  uint32_t tmp___123 ;
  uint32_t tmp___124 ;
  uint32_t tmp___125 ;
  uint32_t tmp___126 ;
  uint32_t tmp___127 ;
  uint32_t tmp___128 ;
  uint32_t tmp___129 ;
  uint32_t tmp___130 ;
  uint32_t tmp___131 ;
  uint32_t tmp___132 ;
  uint32_t tmp___133 ;
  uint32_t tmp___134 ;
  uint32_t tmp___135 ;
  uint32_t tmp___136 ;
  uint32_t tmp___137 ;
  uint32_t tmp___138 ;
  uint32_t tmp___139 ;
  uint32_t tmp___140 ;
  uint32_t tmp___141 ;
  uint32_t tmp___142 ;
  uint32_t tmp___143 ;
  uint32_t tmp___144 ;
  uint32_t tmp___145 ;
  uint32_t tmp___146 ;
  uint32_t tmp___147 ;
  uint32_t tmp___148 ;
  uint32_t tmp___149 ;
  uint32_t tmp___150 ;
  uint32_t tmp___151 ;
  uint32_t tmp___152 ;
  uint32_t tmp___153 ;
  uint32_t tmp___154 ;
  uint32_t tmp___155 ;
  uint32_t tmp___156 ;
  uint32_t tmp___157 ;
  uint32_t tmp___158 ;
  uint32_t tmp___159 ;
  uint32_t tmp___160 ;
  uint32_t tmp___161 ;
  uint32_t tmp___162 ;
  uint32_t tmp___163 ;
  uint32_t tmp___164 ;
  uint32_t tmp___165 ;
  uint32_t tmp___166 ;
  uint32_t tmp___167 ;
  uint32_t tmp___168 ;
  uint32_t tmp___169 ;
  uint32_t tmp___170 ;
  uint32_t tmp___171 ;
  uint32_t tmp___172 ;
  uint32_t tmp___173 ;
  uint32_t tmp___174 ;
  uint32_t tmp___175 ;
  uint32_t tmp___176 ;
  uint32_t tmp___177 ;
  uint32_t tmp___178 ;
  uint32_t tmp___179 ;
  uint32_t tmp___180 ;
  uint32_t tmp___181 ;
  uint32_t tmp___182 ;
  uint32_t tmp___183 ;
  uint32_t tmp___184 ;
  uint32_t tmp___185 ;
  uint32_t tmp___186 ;
  uint32_t tmp___187 ;
  uint32_t tmp___188 ;
  uint32_t tmp___189 ;
  uint32_t tmp___190 ;
  uint32_t tmp___191 ;
  uint32_t tmp___192 ;
  uint32_t tmp___193 ;
  uint32_t tmp___194 ;
  uint32_t tmp___195 ;
  uint32_t tmp___196 ;
  uint32_t tmp___197 ;
  uint32_t tmp___198 ;
  uint32_t tmp___199 ;
  uint32_t tmp___200 ;
  uint32_t tmp___201 ;
  uint32_t tmp___202 ;
  uint32_t tmp___203 ;
  uint32_t tmp___204 ;
  uint32_t tmp___205 ;
  uint32_t tmp___206 ;
  uint32_t tmp___207 ;
  uint32_t tmp___208 ;
  uint32_t tmp___209 ;
  uint32_t tmp___210 ;
  uint32_t tmp___211 ;
  uint32_t tmp___212 ;
  uint32_t tmp___213 ;
  uint32_t tmp___214 ;
  uint32_t tmp___215 ;
  uint32_t tmp___216 ;
  uint32_t tmp___217 ;
  uint32_t tmp___218 ;
  uint32_t tmp___219 ;
  uint32_t tmp___220 ;
  uint32_t tmp___221 ;
  uint32_t tmp___222 ;
  uint32_t tmp___223 ;
  uint32_t tmp___224 ;
  uint32_t tmp___225 ;
  uint32_t tmp___226 ;
  uint32_t tmp___227 ;
  uint32_t tmp___228 ;
  blk_SHA256_CTX *ctx ;
  unsigned char const   *buf ;
  uint32_t __dyc_funcallvar_1 ;
  uint32_t __dyc_funcallvar_2 ;
  uint32_t __dyc_funcallvar_3 ;
  uint32_t __dyc_funcallvar_4 ;
  uint32_t __dyc_funcallvar_5 ;
  uint32_t __dyc_funcallvar_6 ;
  uint32_t __dyc_funcallvar_7 ;
  uint32_t __dyc_funcallvar_8 ;
  uint32_t __dyc_funcallvar_9 ;
  uint32_t __dyc_funcallvar_10 ;
  uint32_t __dyc_funcallvar_11 ;
  uint32_t __dyc_funcallvar_12 ;
  uint32_t __dyc_funcallvar_13 ;
  uint32_t __dyc_funcallvar_14 ;
  uint32_t __dyc_funcallvar_15 ;
  uint32_t __dyc_funcallvar_16 ;
  uint32_t __dyc_funcallvar_17 ;
  uint32_t __dyc_funcallvar_18 ;
  uint32_t __dyc_funcallvar_19 ;
  uint32_t __dyc_funcallvar_20 ;
  uint32_t __dyc_funcallvar_21 ;
  uint32_t __dyc_funcallvar_22 ;
  uint32_t __dyc_funcallvar_23 ;
  uint32_t __dyc_funcallvar_24 ;
  uint32_t __dyc_funcallvar_25 ;
  uint32_t __dyc_funcallvar_26 ;
  uint32_t __dyc_funcallvar_27 ;
  uint32_t __dyc_funcallvar_28 ;
  uint32_t __dyc_funcallvar_29 ;
  uint32_t __dyc_funcallvar_30 ;
  uint32_t __dyc_funcallvar_31 ;
  uint32_t __dyc_funcallvar_32 ;
  uint32_t __dyc_funcallvar_33 ;
  uint32_t __dyc_funcallvar_34 ;
  uint32_t __dyc_funcallvar_35 ;
  uint32_t __dyc_funcallvar_36 ;
  uint32_t __dyc_funcallvar_37 ;
  uint32_t __dyc_funcallvar_38 ;
  uint32_t __dyc_funcallvar_39 ;
  uint32_t __dyc_funcallvar_40 ;
  uint32_t __dyc_funcallvar_41 ;
  uint32_t __dyc_funcallvar_42 ;
  uint32_t __dyc_funcallvar_43 ;
  uint32_t __dyc_funcallvar_44 ;
  uint32_t __dyc_funcallvar_45 ;
  uint32_t __dyc_funcallvar_46 ;
  uint32_t __dyc_funcallvar_47 ;
  uint32_t __dyc_funcallvar_48 ;
  uint32_t __dyc_funcallvar_49 ;
  uint32_t __dyc_funcallvar_50 ;
  uint32_t __dyc_funcallvar_51 ;
  uint32_t __dyc_funcallvar_52 ;
  uint32_t __dyc_funcallvar_53 ;
  uint32_t __dyc_funcallvar_54 ;
  uint32_t __dyc_funcallvar_55 ;
  uint32_t __dyc_funcallvar_56 ;
  uint32_t __dyc_funcallvar_57 ;
  uint32_t __dyc_funcallvar_58 ;
  uint32_t __dyc_funcallvar_59 ;
  uint32_t __dyc_funcallvar_60 ;
  uint32_t __dyc_funcallvar_61 ;
  uint32_t __dyc_funcallvar_62 ;
  uint32_t __dyc_funcallvar_63 ;
  uint32_t __dyc_funcallvar_64 ;
  uint32_t __dyc_funcallvar_65 ;
  uint32_t __dyc_funcallvar_66 ;
  uint32_t __dyc_funcallvar_67 ;
  uint32_t __dyc_funcallvar_68 ;
  uint32_t __dyc_funcallvar_69 ;
  uint32_t __dyc_funcallvar_70 ;
  uint32_t __dyc_funcallvar_71 ;
  uint32_t __dyc_funcallvar_72 ;
  uint32_t __dyc_funcallvar_73 ;
  uint32_t __dyc_funcallvar_74 ;
  uint32_t __dyc_funcallvar_75 ;
  uint32_t __dyc_funcallvar_76 ;
  uint32_t __dyc_funcallvar_77 ;
  uint32_t __dyc_funcallvar_78 ;
  uint32_t __dyc_funcallvar_79 ;
  uint32_t __dyc_funcallvar_80 ;
  uint32_t __dyc_funcallvar_81 ;
  uint32_t __dyc_funcallvar_82 ;
  uint32_t __dyc_funcallvar_83 ;
  uint32_t __dyc_funcallvar_84 ;
  uint32_t __dyc_funcallvar_85 ;
  uint32_t __dyc_funcallvar_86 ;
  uint32_t __dyc_funcallvar_87 ;
  uint32_t __dyc_funcallvar_88 ;
  uint32_t __dyc_funcallvar_89 ;
  uint32_t __dyc_funcallvar_90 ;
  uint32_t __dyc_funcallvar_91 ;
  uint32_t __dyc_funcallvar_92 ;
  uint32_t __dyc_funcallvar_93 ;
  uint32_t __dyc_funcallvar_94 ;
  uint32_t __dyc_funcallvar_95 ;
  uint32_t __dyc_funcallvar_96 ;
  uint32_t __dyc_funcallvar_97 ;
  uint32_t __dyc_funcallvar_98 ;
  uint32_t __dyc_funcallvar_99 ;
  uint32_t __dyc_funcallvar_100 ;
  uint32_t __dyc_funcallvar_101 ;
  uint32_t __dyc_funcallvar_102 ;
  uint32_t __dyc_funcallvar_103 ;
  uint32_t __dyc_funcallvar_104 ;
  uint32_t __dyc_funcallvar_105 ;
  uint32_t __dyc_funcallvar_106 ;
  uint32_t __dyc_funcallvar_107 ;
  uint32_t __dyc_funcallvar_108 ;
  uint32_t __dyc_funcallvar_109 ;
  uint32_t __dyc_funcallvar_110 ;
  uint32_t __dyc_funcallvar_111 ;
  uint32_t __dyc_funcallvar_112 ;
  uint32_t __dyc_funcallvar_113 ;
  uint32_t __dyc_funcallvar_114 ;
  uint32_t __dyc_funcallvar_115 ;
  uint32_t __dyc_funcallvar_116 ;
  uint32_t __dyc_funcallvar_117 ;
  uint32_t __dyc_funcallvar_118 ;
  uint32_t __dyc_funcallvar_119 ;
  uint32_t __dyc_funcallvar_120 ;
  uint32_t __dyc_funcallvar_121 ;
  uint32_t __dyc_funcallvar_122 ;
  uint32_t __dyc_funcallvar_123 ;
  uint32_t __dyc_funcallvar_124 ;
  uint32_t __dyc_funcallvar_125 ;
  uint32_t __dyc_funcallvar_126 ;
  uint32_t __dyc_funcallvar_127 ;
  uint32_t __dyc_funcallvar_128 ;
  uint32_t __dyc_funcallvar_129 ;
  uint32_t __dyc_funcallvar_130 ;
  uint32_t __dyc_funcallvar_131 ;
  uint32_t __dyc_funcallvar_132 ;
  uint32_t __dyc_funcallvar_133 ;
  uint32_t __dyc_funcallvar_134 ;
  uint32_t __dyc_funcallvar_135 ;
  uint32_t __dyc_funcallvar_136 ;
  uint32_t __dyc_funcallvar_137 ;
  uint32_t __dyc_funcallvar_138 ;
  uint32_t __dyc_funcallvar_139 ;
  uint32_t __dyc_funcallvar_140 ;
  uint32_t __dyc_funcallvar_141 ;
  uint32_t __dyc_funcallvar_142 ;
  uint32_t __dyc_funcallvar_143 ;
  uint32_t __dyc_funcallvar_144 ;
  uint32_t __dyc_funcallvar_145 ;
  uint32_t __dyc_funcallvar_146 ;
  uint32_t __dyc_funcallvar_147 ;
  uint32_t __dyc_funcallvar_148 ;
  uint32_t __dyc_funcallvar_149 ;
  uint32_t __dyc_funcallvar_150 ;
  uint32_t __dyc_funcallvar_151 ;
  uint32_t __dyc_funcallvar_152 ;
  uint32_t __dyc_funcallvar_153 ;
  uint32_t __dyc_funcallvar_154 ;
  uint32_t __dyc_funcallvar_155 ;
  uint32_t __dyc_funcallvar_156 ;
  uint32_t __dyc_funcallvar_157 ;
  uint32_t __dyc_funcallvar_158 ;
  uint32_t __dyc_funcallvar_159 ;
  uint32_t __dyc_funcallvar_160 ;
  uint32_t __dyc_funcallvar_161 ;
  uint32_t __dyc_funcallvar_162 ;
  uint32_t __dyc_funcallvar_163 ;
  uint32_t __dyc_funcallvar_164 ;
  uint32_t __dyc_funcallvar_165 ;
  uint32_t __dyc_funcallvar_166 ;
  uint32_t __dyc_funcallvar_167 ;
  uint32_t __dyc_funcallvar_168 ;
  uint32_t __dyc_funcallvar_169 ;
  uint32_t __dyc_funcallvar_170 ;
  uint32_t __dyc_funcallvar_171 ;
  uint32_t __dyc_funcallvar_172 ;
  uint32_t __dyc_funcallvar_173 ;
  uint32_t __dyc_funcallvar_174 ;
  uint32_t __dyc_funcallvar_175 ;
  uint32_t __dyc_funcallvar_176 ;
  uint32_t __dyc_funcallvar_177 ;
  uint32_t __dyc_funcallvar_178 ;
  uint32_t __dyc_funcallvar_179 ;
  uint32_t __dyc_funcallvar_180 ;
  uint32_t __dyc_funcallvar_181 ;
  uint32_t __dyc_funcallvar_182 ;
  uint32_t __dyc_funcallvar_183 ;
  uint32_t __dyc_funcallvar_184 ;
  uint32_t __dyc_funcallvar_185 ;
  uint32_t __dyc_funcallvar_186 ;
  uint32_t __dyc_funcallvar_187 ;
  uint32_t __dyc_funcallvar_188 ;
  uint32_t __dyc_funcallvar_189 ;
  uint32_t __dyc_funcallvar_190 ;
  uint32_t __dyc_funcallvar_191 ;
  uint32_t __dyc_funcallvar_192 ;
  uint32_t __dyc_funcallvar_193 ;
  uint32_t __dyc_funcallvar_194 ;
  uint32_t __dyc_funcallvar_195 ;
  uint32_t __dyc_funcallvar_196 ;
  uint32_t __dyc_funcallvar_197 ;
  uint32_t __dyc_funcallvar_198 ;
  uint32_t __dyc_funcallvar_199 ;
  uint32_t __dyc_funcallvar_200 ;
  uint32_t __dyc_funcallvar_201 ;
  uint32_t __dyc_funcallvar_202 ;
  uint32_t __dyc_funcallvar_203 ;
  uint32_t __dyc_funcallvar_204 ;
  uint32_t __dyc_funcallvar_205 ;
  uint32_t __dyc_funcallvar_206 ;
  uint32_t __dyc_funcallvar_207 ;
  uint32_t __dyc_funcallvar_208 ;
  uint32_t __dyc_funcallvar_209 ;
  uint32_t __dyc_funcallvar_210 ;
  uint32_t __dyc_funcallvar_211 ;
  uint32_t __dyc_funcallvar_212 ;
  uint32_t __dyc_funcallvar_213 ;
  uint32_t __dyc_funcallvar_214 ;
  uint32_t __dyc_funcallvar_215 ;
  uint32_t __dyc_funcallvar_216 ;
  uint32_t __dyc_funcallvar_217 ;
  uint32_t __dyc_funcallvar_218 ;
  uint32_t __dyc_funcallvar_219 ;
  uint32_t __dyc_funcallvar_220 ;
  uint32_t __dyc_funcallvar_221 ;
  uint32_t __dyc_funcallvar_222 ;
  uint32_t __dyc_funcallvar_223 ;
  uint32_t __dyc_funcallvar_224 ;
  uint32_t __dyc_funcallvar_225 ;
  uint32_t __dyc_funcallvar_226 ;
  uint32_t __dyc_funcallvar_227 ;
  uint32_t __dyc_funcallvar_228 ;
  uint32_t __dyc_funcallvar_229 ;
  uint32_t __dyc_funcallvar_230 ;
  uint32_t __dyc_funcallvar_231 ;

  {
  i = __dyc_readpre_byte();
  ctx = __dyc_read_ptr__typdef_blk_SHA256_CTX();
  buf = (unsigned char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_1 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_2 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_3 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_4 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_5 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_6 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_7 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_8 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_9 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_10 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_11 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_12 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_13 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_14 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_15 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_16 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_17 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_18 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_19 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_20 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_21 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_22 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_23 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_24 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_25 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_26 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_27 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_28 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_29 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_30 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_31 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_32 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_33 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_34 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_35 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_36 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_37 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_38 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_39 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_40 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_41 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_42 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_43 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_44 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_45 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_46 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_47 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_48 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_49 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_50 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_51 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_52 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_53 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_54 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_55 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_56 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_57 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_58 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_59 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_60 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_61 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_62 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_63 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_64 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_65 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_66 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_67 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_68 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_69 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_70 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_71 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_72 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_73 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_74 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_75 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_76 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_77 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_78 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_79 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_80 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_81 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_82 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_83 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_84 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_85 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_86 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_87 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_88 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_89 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_90 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_91 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_92 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_93 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_94 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_95 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_96 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_97 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_98 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_99 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_100 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_101 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_102 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_103 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_104 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_105 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_106 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_107 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_108 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_109 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_110 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_111 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_112 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_113 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_114 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_115 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_116 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_117 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_118 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_119 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_120 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_121 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_122 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_123 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_124 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_125 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_126 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_127 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_128 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_129 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_130 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_131 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_132 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_133 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_134 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_135 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_136 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_137 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_138 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_139 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_140 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_141 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_142 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_143 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_144 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_145 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_146 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_147 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_148 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_149 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_150 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_151 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_152 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_153 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_154 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_155 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_156 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_157 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_158 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_159 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_160 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_161 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_162 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_163 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_164 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_165 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_166 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_167 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_168 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_169 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_170 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_171 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_172 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_173 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_174 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_175 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_176 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_177 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_178 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_179 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_180 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_181 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_182 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_183 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_184 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_185 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_186 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_187 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_188 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_189 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_190 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_191 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_192 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_193 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_194 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_195 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_196 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_197 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_198 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_199 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_200 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_201 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_202 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_203 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_204 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_205 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_206 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_207 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_208 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_209 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_210 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_211 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_212 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_213 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_214 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_215 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_216 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_217 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_218 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_219 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_220 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_221 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_222 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_223 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_224 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_225 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_226 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_227 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_228 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_229 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_230 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_231 = (uint32_t )__dyc_readpre_byte();
  t0 = 0;
  t1 = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  tmp___17 = 0;
  tmp___18 = 0;
  tmp___19 = 0;
  tmp___20 = 0;
  tmp___21 = 0;
  tmp___22 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  tmp___27 = 0;
  tmp___28 = 0;
  tmp___29 = 0;
  tmp___30 = 0;
  tmp___31 = 0;
  tmp___32 = 0;
  tmp___33 = 0;
  tmp___34 = 0;
  tmp___35 = 0;
  tmp___36 = 0;
  tmp___37 = 0;
  tmp___38 = 0;
  tmp___39 = 0;
  tmp___40 = 0;
  tmp___41 = 0;
  tmp___42 = 0;
  tmp___43 = 0;
  tmp___44 = 0;
  tmp___45 = 0;
  tmp___46 = 0;
  tmp___47 = 0;
  tmp___48 = 0;
  tmp___49 = 0;
  tmp___50 = 0;
  tmp___51 = 0;
  tmp___52 = 0;
  tmp___53 = 0;
  tmp___54 = 0;
  tmp___55 = 0;
  tmp___56 = 0;
  tmp___57 = 0;
  tmp___58 = 0;
  tmp___59 = 0;
  tmp___60 = 0;
  tmp___61 = 0;
  tmp___62 = 0;
  tmp___63 = 0;
  tmp___64 = 0;
  tmp___65 = 0;
  tmp___66 = 0;
  tmp___67 = 0;
  tmp___68 = 0;
  tmp___69 = 0;
  tmp___70 = 0;
  tmp___71 = 0;
  tmp___72 = 0;
  tmp___73 = 0;
  tmp___74 = 0;
  tmp___75 = 0;
  tmp___76 = 0;
  tmp___77 = 0;
  tmp___78 = 0;
  tmp___79 = 0;
  tmp___80 = 0;
  tmp___81 = 0;
  tmp___82 = 0;
  tmp___83 = 0;
  tmp___84 = 0;
  tmp___85 = 0;
  tmp___86 = 0;
  tmp___87 = 0;
  tmp___88 = 0;
  tmp___89 = 0;
  tmp___90 = 0;
  tmp___91 = 0;
  tmp___92 = 0;
  tmp___93 = 0;
  tmp___94 = 0;
  tmp___95 = 0;
  tmp___96 = 0;
  tmp___97 = 0;
  tmp___98 = 0;
  tmp___99 = 0;
  tmp___100 = 0;
  tmp___101 = 0;
  tmp___102 = 0;
  tmp___103 = 0;
  tmp___104 = 0;
  tmp___105 = 0;
  tmp___106 = 0;
  tmp___107 = 0;
  tmp___108 = 0;
  tmp___109 = 0;
  tmp___110 = 0;
  tmp___111 = 0;
  tmp___112 = 0;
  tmp___113 = 0;
  tmp___114 = 0;
  tmp___115 = 0;
  tmp___116 = 0;
  tmp___117 = 0;
  tmp___118 = 0;
  tmp___119 = 0;
  tmp___120 = 0;
  tmp___121 = 0;
  tmp___122 = 0;
  tmp___123 = 0;
  tmp___124 = 0;
  tmp___125 = 0;
  tmp___126 = 0;
  tmp___127 = 0;
  tmp___128 = 0;
  tmp___129 = 0;
  tmp___130 = 0;
  tmp___131 = 0;
  tmp___132 = 0;
  tmp___133 = 0;
  tmp___134 = 0;
  tmp___135 = 0;
  tmp___136 = 0;
  tmp___137 = 0;
  tmp___138 = 0;
  tmp___139 = 0;
  tmp___140 = 0;
  tmp___141 = 0;
  tmp___142 = 0;
  tmp___143 = 0;
  tmp___144 = 0;
  tmp___145 = 0;
  tmp___146 = 0;
  tmp___147 = 0;
  tmp___148 = 0;
  tmp___149 = 0;
  tmp___150 = 0;
  tmp___151 = 0;
  tmp___152 = 0;
  tmp___153 = 0;
  tmp___154 = 0;
  tmp___155 = 0;
  tmp___156 = 0;
  tmp___157 = 0;
  tmp___158 = 0;
  tmp___159 = 0;
  tmp___160 = 0;
  tmp___161 = 0;
  tmp___162 = 0;
  tmp___163 = 0;
  tmp___164 = 0;
  tmp___165 = 0;
  tmp___166 = 0;
  tmp___167 = 0;
  tmp___168 = 0;
  tmp___169 = 0;
  tmp___170 = 0;
  tmp___171 = 0;
  tmp___172 = 0;
  tmp___173 = 0;
  tmp___174 = 0;
  tmp___175 = 0;
  tmp___176 = 0;
  tmp___177 = 0;
  tmp___178 = 0;
  tmp___179 = 0;
  tmp___180 = 0;
  tmp___181 = 0;
  tmp___182 = 0;
  tmp___183 = 0;
  tmp___184 = 0;
  tmp___185 = 0;
  tmp___186 = 0;
  tmp___187 = 0;
  tmp___188 = 0;
  tmp___189 = 0;
  tmp___190 = 0;
  tmp___191 = 0;
  tmp___192 = 0;
  tmp___193 = 0;
  tmp___194 = 0;
  tmp___195 = 0;
  tmp___196 = 0;
  tmp___197 = 0;
  tmp___198 = 0;
  tmp___199 = 0;
  tmp___200 = 0;
  tmp___201 = 0;
  tmp___202 = 0;
  tmp___203 = 0;
  tmp___204 = 0;
  tmp___205 = 0;
  tmp___206 = 0;
  tmp___207 = 0;
  tmp___208 = 0;
  tmp___209 = 0;
  tmp___210 = 0;
  tmp___211 = 0;
  tmp___212 = 0;
  tmp___213 = 0;
  tmp___214 = 0;
  tmp___215 = 0;
  tmp___216 = 0;
  tmp___217 = 0;
  tmp___218 = 0;
  tmp___219 = 0;
  tmp___220 = 0;
  tmp___221 = 0;
  tmp___222 = 0;
  tmp___223 = 0;
  tmp___224 = 0;
  tmp___225 = 0;
  tmp___226 = 0;
  tmp___227 = 0;
  tmp___228 = 0;
#line 65
  while (1) {
    while_0_continue: /* CIL Label */ ;
#line 65
    if (! (i < 8)) {
      goto while_0_break;
    }
#line 66
    S[i] = ctx->state[i];
#line 65
    i ++;
  }
  while_0_break: /* CIL Label */ ;
#line 69
  i = 0;
#line 69
  while (1) {
    while_1_continue: /* CIL Label */ ;
#line 69
    if (! (i < 16)) {
      goto while_1_break;
    }
    {
#line 70
    W[i] = __dyc_funcallvar_1;
#line 69
    i ++;
#line 69
    buf += sizeof(uint32_t );
    }
  }
  while_1_break: /* CIL Label */ ;
#line 73
  i = 16;
#line 73
  while (1) {
    while_2_continue: /* CIL Label */ ;
#line 73
    if (! (i < 64)) {
      goto while_2_break;
    }
    {
#line 74
    tmp = __dyc_funcallvar_2;
#line 74
    tmp___0 = __dyc_funcallvar_3;
#line 74
    W[i] = ((tmp + W[i - 7]) + tmp___0) + W[i - 16];
#line 73
    i ++;
    }
  }
  while_2_break: /* CIL Label */ ;
#line 82
  tmp___1 = __dyc_funcallvar_4;
#line 82
  tmp___2 = __dyc_funcallvar_5;
#line 82
  t0 = (((S[7] + tmp___1) + tmp___2) + 1116352408U) + W[0];
#line 82
  tmp___3 = __dyc_funcallvar_6;
#line 82
  tmp___4 = __dyc_funcallvar_7;
#line 82
  t1 = tmp___3 + tmp___4;
#line 82
  S[3] += t0;
#line 82
  S[7] = t0 + t1;
#line 83
  tmp___5 = __dyc_funcallvar_8;
#line 83
  tmp___6 = __dyc_funcallvar_9;
#line 83
  t0 = (((S[6] + tmp___5) + tmp___6) + 1899447441U) + W[1];
#line 83
  tmp___7 = __dyc_funcallvar_10;
#line 83
  tmp___8 = __dyc_funcallvar_11;
#line 83
  t1 = tmp___7 + tmp___8;
#line 83
  S[2] += t0;
#line 83
  S[6] = t0 + t1;
#line 84
  tmp___9 = __dyc_funcallvar_12;
#line 84
  tmp___10 = __dyc_funcallvar_13;
#line 84
  t0 = (((S[5] + tmp___9) + tmp___10) + 3049323471U) + W[2];
#line 84
  tmp___11 = __dyc_funcallvar_14;
#line 84
  tmp___12 = __dyc_funcallvar_15;
#line 84
  t1 = tmp___11 + tmp___12;
#line 84
  S[1] += t0;
#line 84
  S[5] = t0 + t1;
#line 85
  tmp___13 = __dyc_funcallvar_16;
#line 85
  tmp___14 = __dyc_funcallvar_17;
#line 85
  t0 = (((S[4] + tmp___13) + tmp___14) + 3921009573U) + W[3];
#line 85
  tmp___15 = __dyc_funcallvar_18;
#line 85
  tmp___16 = __dyc_funcallvar_19;
#line 85
  t1 = tmp___15 + tmp___16;
#line 85
  S[0] += t0;
#line 85
  S[4] = t0 + t1;
#line 86
  tmp___17 = __dyc_funcallvar_20;
#line 86
  tmp___18 = __dyc_funcallvar_21;
#line 86
  t0 = (((S[3] + tmp___17) + tmp___18) + 961987163U) + W[4];
#line 86
  tmp___19 = __dyc_funcallvar_22;
#line 86
  tmp___20 = __dyc_funcallvar_23;
#line 86
  t1 = tmp___19 + tmp___20;
#line 86
  S[7] += t0;
#line 86
  S[3] = t0 + t1;
#line 87
  tmp___21 = __dyc_funcallvar_24;
#line 87
  tmp___22 = __dyc_funcallvar_25;
#line 87
  t0 = (((S[2] + tmp___21) + tmp___22) + 1508970993U) + W[5];
#line 87
  tmp___23 = __dyc_funcallvar_26;
#line 87
  tmp___24 = __dyc_funcallvar_27;
#line 87
  t1 = tmp___23 + tmp___24;
#line 87
  S[6] += t0;
#line 87
  S[2] = t0 + t1;
#line 88
  tmp___25 = __dyc_funcallvar_28;
#line 88
  tmp___26 = __dyc_funcallvar_29;
#line 88
  t0 = (((S[1] + tmp___25) + tmp___26) + 2453635748U) + W[6];
#line 88
  tmp___27 = __dyc_funcallvar_30;
#line 88
  tmp___28 = __dyc_funcallvar_31;
#line 88
  t1 = tmp___27 + tmp___28;
#line 88
  S[5] += t0;
#line 88
  S[1] = t0 + t1;
#line 89
  tmp___29 = __dyc_funcallvar_32;
#line 89
  tmp___30 = __dyc_funcallvar_33;
#line 89
  t0 = (((S[0] + tmp___29) + tmp___30) + 2870763221U) + W[7];
#line 89
  tmp___31 = __dyc_funcallvar_34;
#line 89
  tmp___32 = __dyc_funcallvar_35;
#line 89
  t1 = tmp___31 + tmp___32;
#line 89
  S[4] += t0;
#line 89
  S[0] = t0 + t1;
#line 90
  tmp___33 = __dyc_funcallvar_36;
#line 90
  tmp___34 = __dyc_funcallvar_37;
#line 90
  t0 = (((S[7] + tmp___33) + tmp___34) + 3624381080U) + W[8];
#line 90
  tmp___35 = __dyc_funcallvar_38;
#line 90
  tmp___36 = __dyc_funcallvar_39;
#line 90
  t1 = tmp___35 + tmp___36;
#line 90
  S[3] += t0;
#line 90
  S[7] = t0 + t1;
#line 91
  tmp___37 = __dyc_funcallvar_40;
#line 91
  tmp___38 = __dyc_funcallvar_41;
#line 91
  t0 = (((S[6] + tmp___37) + tmp___38) + 310598401U) + W[9];
#line 91
  tmp___39 = __dyc_funcallvar_42;
#line 91
  tmp___40 = __dyc_funcallvar_43;
#line 91
  t1 = tmp___39 + tmp___40;
#line 91
  S[2] += t0;
#line 91
  S[6] = t0 + t1;
#line 92
  tmp___41 = __dyc_funcallvar_44;
#line 92
  tmp___42 = __dyc_funcallvar_45;
#line 92
  t0 = (((S[5] + tmp___41) + tmp___42) + 607225278U) + W[10];
#line 92
  tmp___43 = __dyc_funcallvar_46;
#line 92
  tmp___44 = __dyc_funcallvar_47;
#line 92
  t1 = tmp___43 + tmp___44;
#line 92
  S[1] += t0;
#line 92
  S[5] = t0 + t1;
#line 93
  tmp___45 = __dyc_funcallvar_48;
#line 93
  tmp___46 = __dyc_funcallvar_49;
#line 93
  t0 = (((S[4] + tmp___45) + tmp___46) + 1426881987U) + W[11];
#line 93
  tmp___47 = __dyc_funcallvar_50;
#line 93
  tmp___48 = __dyc_funcallvar_51;
#line 93
  t1 = tmp___47 + tmp___48;
#line 93
  S[0] += t0;
#line 93
  S[4] = t0 + t1;
#line 94
  tmp___49 = __dyc_funcallvar_52;
#line 94
  tmp___50 = __dyc_funcallvar_53;
#line 94
  t0 = (((S[3] + tmp___49) + tmp___50) + 1925078388U) + W[12];
#line 94
  tmp___51 = __dyc_funcallvar_54;
#line 94
  tmp___52 = __dyc_funcallvar_55;
#line 94
  t1 = tmp___51 + tmp___52;
#line 94
  S[7] += t0;
#line 94
  S[3] = t0 + t1;
#line 95
  tmp___53 = __dyc_funcallvar_56;
#line 95
  tmp___54 = __dyc_funcallvar_57;
#line 95
  t0 = (((S[2] + tmp___53) + tmp___54) + 2162078206U) + W[13];
#line 95
  tmp___55 = __dyc_funcallvar_58;
#line 95
  tmp___56 = __dyc_funcallvar_59;
#line 95
  t1 = tmp___55 + tmp___56;
#line 95
  S[6] += t0;
#line 95
  S[2] = t0 + t1;
#line 96
  tmp___57 = __dyc_funcallvar_60;
#line 96
  tmp___58 = __dyc_funcallvar_61;
#line 96
  t0 = (((S[1] + tmp___57) + tmp___58) + 2614888103U) + W[14];
#line 96
  tmp___59 = __dyc_funcallvar_62;
#line 96
  tmp___60 = __dyc_funcallvar_63;
#line 96
  t1 = tmp___59 + tmp___60;
#line 96
  S[5] += t0;
#line 96
  S[1] = t0 + t1;
#line 97
  tmp___61 = __dyc_funcallvar_64;
#line 97
  tmp___62 = __dyc_funcallvar_65;
#line 97
  t0 = (((S[0] + tmp___61) + tmp___62) + 3248222580U) + W[15];
#line 97
  tmp___63 = __dyc_funcallvar_66;
#line 97
  tmp___64 = __dyc_funcallvar_67;
#line 97
  t1 = tmp___63 + tmp___64;
#line 97
  S[4] += t0;
#line 97
  S[0] = t0 + t1;
#line 98
  tmp___65 = __dyc_funcallvar_68;
#line 98
  tmp___66 = __dyc_funcallvar_69;
#line 98
  t0 = (((S[7] + tmp___65) + tmp___66) + 3835390401U) + W[16];
#line 98
  tmp___67 = __dyc_funcallvar_70;
#line 98
  tmp___68 = __dyc_funcallvar_71;
#line 98
  t1 = tmp___67 + tmp___68;
#line 98
  S[3] += t0;
#line 98
  S[7] = t0 + t1;
#line 99
  tmp___69 = __dyc_funcallvar_72;
#line 99
  tmp___70 = __dyc_funcallvar_73;
#line 99
  t0 = (((S[6] + tmp___69) + tmp___70) + 4022224774U) + W[17];
#line 99
  tmp___71 = __dyc_funcallvar_74;
#line 99
  tmp___72 = __dyc_funcallvar_75;
#line 99
  t1 = tmp___71 + tmp___72;
#line 99
  S[2] += t0;
#line 99
  S[6] = t0 + t1;
#line 100
  tmp___73 = __dyc_funcallvar_76;
#line 100
  tmp___74 = __dyc_funcallvar_77;
#line 100
  t0 = (((S[5] + tmp___73) + tmp___74) + 264347078U) + W[18];
#line 100
  tmp___75 = __dyc_funcallvar_78;
#line 100
  tmp___76 = __dyc_funcallvar_79;
#line 100
  t1 = tmp___75 + tmp___76;
#line 100
  S[1] += t0;
#line 100
  S[5] = t0 + t1;
#line 101
  tmp___77 = __dyc_funcallvar_80;
#line 101
  tmp___78 = __dyc_funcallvar_81;
#line 101
  t0 = (((S[4] + tmp___77) + tmp___78) + 604807628U) + W[19];
#line 101
  tmp___79 = __dyc_funcallvar_82;
#line 101
  tmp___80 = __dyc_funcallvar_83;
#line 101
  t1 = tmp___79 + tmp___80;
#line 101
  S[0] += t0;
#line 101
  S[4] = t0 + t1;
#line 102
  tmp___81 = __dyc_funcallvar_84;
#line 102
  tmp___82 = __dyc_funcallvar_85;
#line 102
  t0 = (((S[3] + tmp___81) + tmp___82) + 770255983U) + W[20];
#line 102
  tmp___83 = __dyc_funcallvar_86;
#line 102
  tmp___84 = __dyc_funcallvar_87;
#line 102
  t1 = tmp___83 + tmp___84;
#line 102
  S[7] += t0;
#line 102
  S[3] = t0 + t1;
#line 103
  tmp___85 = __dyc_funcallvar_88;
#line 103
  tmp___86 = __dyc_funcallvar_89;
#line 103
  t0 = (((S[2] + tmp___85) + tmp___86) + 1249150122U) + W[21];
#line 103
  tmp___87 = __dyc_funcallvar_90;
#line 103
  tmp___88 = __dyc_funcallvar_91;
#line 103
  t1 = tmp___87 + tmp___88;
#line 103
  S[6] += t0;
#line 103
  S[2] = t0 + t1;
#line 104
  tmp___89 = __dyc_funcallvar_92;
#line 104
  tmp___90 = __dyc_funcallvar_93;
#line 104
  t0 = (((S[1] + tmp___89) + tmp___90) + 1555081692U) + W[22];
#line 104
  tmp___91 = __dyc_funcallvar_94;
#line 104
  tmp___92 = __dyc_funcallvar_95;
#line 104
  t1 = tmp___91 + tmp___92;
#line 104
  S[5] += t0;
#line 104
  S[1] = t0 + t1;
#line 105
  tmp___93 = __dyc_funcallvar_96;
#line 105
  tmp___94 = __dyc_funcallvar_97;
#line 105
  t0 = (((S[0] + tmp___93) + tmp___94) + 1996064986U) + W[23];
#line 105
  tmp___95 = __dyc_funcallvar_98;
#line 105
  tmp___96 = __dyc_funcallvar_99;
#line 105
  t1 = tmp___95 + tmp___96;
#line 105
  S[4] += t0;
#line 105
  S[0] = t0 + t1;
#line 106
  tmp___97 = __dyc_funcallvar_100;
#line 106
  tmp___98 = __dyc_funcallvar_101;
#line 106
  t0 = (((S[7] + tmp___97) + tmp___98) + 2554220882U) + W[24];
#line 106
  tmp___99 = __dyc_funcallvar_102;
#line 106
  tmp___100 = __dyc_funcallvar_103;
#line 106
  t1 = tmp___99 + tmp___100;
#line 106
  S[3] += t0;
#line 106
  S[7] = t0 + t1;
#line 107
  tmp___101 = __dyc_funcallvar_104;
#line 107
  tmp___102 = __dyc_funcallvar_105;
#line 107
  t0 = (((S[6] + tmp___101) + tmp___102) + 2821834349U) + W[25];
#line 107
  tmp___103 = __dyc_funcallvar_106;
#line 107
  tmp___104 = __dyc_funcallvar_107;
#line 107
  t1 = tmp___103 + tmp___104;
#line 107
  S[2] += t0;
#line 107
  S[6] = t0 + t1;
#line 108
  tmp___105 = __dyc_funcallvar_108;
#line 108
  tmp___106 = __dyc_funcallvar_109;
#line 108
  t0 = (((S[5] + tmp___105) + tmp___106) + 2952996808U) + W[26];
#line 108
  tmp___107 = __dyc_funcallvar_110;
#line 108
  tmp___108 = __dyc_funcallvar_111;
#line 108
  t1 = tmp___107 + tmp___108;
#line 108
  S[1] += t0;
#line 108
  S[5] = t0 + t1;
#line 109
  tmp___109 = __dyc_funcallvar_112;
#line 109
  tmp___110 = __dyc_funcallvar_113;
#line 109
  t0 = (((S[4] + tmp___109) + tmp___110) + 3210313671U) + W[27];
#line 109
  tmp___111 = __dyc_funcallvar_114;
#line 109
  tmp___112 = __dyc_funcallvar_115;
#line 109
  t1 = tmp___111 + tmp___112;
#line 109
  S[0] += t0;
#line 109
  S[4] = t0 + t1;
#line 110
  tmp___113 = __dyc_funcallvar_116;
#line 110
  tmp___114 = __dyc_funcallvar_117;
#line 110
  t0 = (((S[3] + tmp___113) + tmp___114) + 3336571891U) + W[28];
#line 110
  tmp___115 = __dyc_funcallvar_118;
#line 110
  tmp___116 = __dyc_funcallvar_119;
#line 110
  t1 = tmp___115 + tmp___116;
#line 110
  S[7] += t0;
#line 110
  S[3] = t0 + t1;
#line 111
  tmp___117 = __dyc_funcallvar_120;
#line 111
  tmp___118 = __dyc_funcallvar_121;
#line 111
  t0 = (((S[2] + tmp___117) + tmp___118) + 3584528711U) + W[29];
#line 111
  tmp___119 = __dyc_funcallvar_122;
#line 111
  tmp___120 = __dyc_funcallvar_123;
#line 111
  t1 = tmp___119 + tmp___120;
#line 111
  S[6] += t0;
#line 111
  S[2] = t0 + t1;
#line 112
  tmp___121 = __dyc_funcallvar_124;
#line 112
  tmp___122 = __dyc_funcallvar_125;
#line 112
  t0 = (((S[1] + tmp___121) + tmp___122) + 113926993U) + W[30];
#line 112
  tmp___123 = __dyc_funcallvar_126;
#line 112
  tmp___124 = __dyc_funcallvar_127;
#line 112
  t1 = tmp___123 + tmp___124;
#line 112
  S[5] += t0;
#line 112
  S[1] = t0 + t1;
#line 113
  tmp___125 = __dyc_funcallvar_128;
#line 113
  tmp___126 = __dyc_funcallvar_129;
#line 113
  t0 = (((S[0] + tmp___125) + tmp___126) + 338241895U) + W[31];
#line 113
  tmp___127 = __dyc_funcallvar_130;
#line 113
  tmp___128 = __dyc_funcallvar_131;
#line 113
  t1 = tmp___127 + tmp___128;
#line 113
  S[4] += t0;
#line 113
  S[0] = t0 + t1;
#line 114
  tmp___129 = __dyc_funcallvar_132;
#line 114
  tmp___130 = __dyc_funcallvar_133;
#line 114
  t0 = (((S[7] + tmp___129) + tmp___130) + 666307205U) + W[32];
#line 114
  tmp___131 = __dyc_funcallvar_134;
#line 114
  tmp___132 = __dyc_funcallvar_135;
#line 114
  t1 = tmp___131 + tmp___132;
#line 114
  S[3] += t0;
#line 114
  S[7] = t0 + t1;
#line 115
  tmp___133 = __dyc_funcallvar_136;
#line 115
  tmp___134 = __dyc_funcallvar_137;
#line 115
  t0 = (((S[6] + tmp___133) + tmp___134) + 773529912U) + W[33];
#line 115
  tmp___135 = __dyc_funcallvar_138;
#line 115
  tmp___136 = __dyc_funcallvar_139;
#line 115
  t1 = tmp___135 + tmp___136;
#line 115
  S[2] += t0;
#line 115
  S[6] = t0 + t1;
#line 116
  tmp___137 = __dyc_funcallvar_140;
#line 116
  tmp___138 = __dyc_funcallvar_141;
#line 116
  t0 = (((S[5] + tmp___137) + tmp___138) + 1294757372U) + W[34];
#line 116
  tmp___139 = __dyc_funcallvar_142;
#line 116
  tmp___140 = __dyc_funcallvar_143;
#line 116
  t1 = tmp___139 + tmp___140;
#line 116
  S[1] += t0;
#line 116
  S[5] = t0 + t1;
#line 117
  tmp___141 = __dyc_funcallvar_144;
#line 117
  tmp___142 = __dyc_funcallvar_145;
#line 117
  t0 = (((S[4] + tmp___141) + tmp___142) + 1396182291U) + W[35];
#line 117
  tmp___143 = __dyc_funcallvar_146;
#line 117
  tmp___144 = __dyc_funcallvar_147;
#line 117
  t1 = tmp___143 + tmp___144;
#line 117
  S[0] += t0;
#line 117
  S[4] = t0 + t1;
#line 118
  tmp___145 = __dyc_funcallvar_148;
#line 118
  tmp___146 = __dyc_funcallvar_149;
#line 118
  t0 = (((S[3] + tmp___145) + tmp___146) + 1695183700U) + W[36];
#line 118
  tmp___147 = __dyc_funcallvar_150;
#line 118
  tmp___148 = __dyc_funcallvar_151;
#line 118
  t1 = tmp___147 + tmp___148;
#line 118
  S[7] += t0;
#line 118
  S[3] = t0 + t1;
#line 119
  tmp___149 = __dyc_funcallvar_152;
#line 119
  tmp___150 = __dyc_funcallvar_153;
#line 119
  t0 = (((S[2] + tmp___149) + tmp___150) + 1986661051U) + W[37];
#line 119
  tmp___151 = __dyc_funcallvar_154;
#line 119
  tmp___152 = __dyc_funcallvar_155;
#line 119
  t1 = tmp___151 + tmp___152;
#line 119
  S[6] += t0;
#line 119
  S[2] = t0 + t1;
#line 120
  tmp___153 = __dyc_funcallvar_156;
#line 120
  tmp___154 = __dyc_funcallvar_157;
#line 120
  t0 = (((S[1] + tmp___153) + tmp___154) + 2177026350U) + W[38];
#line 120
  tmp___155 = __dyc_funcallvar_158;
#line 120
  tmp___156 = __dyc_funcallvar_159;
#line 120
  t1 = tmp___155 + tmp___156;
#line 120
  S[5] += t0;
#line 120
  S[1] = t0 + t1;
#line 121
  tmp___157 = __dyc_funcallvar_160;
#line 121
  tmp___158 = __dyc_funcallvar_161;
#line 121
  t0 = (((S[0] + tmp___157) + tmp___158) + 2456956037U) + W[39];
#line 121
  tmp___159 = __dyc_funcallvar_162;
#line 121
  tmp___160 = __dyc_funcallvar_163;
#line 121
  t1 = tmp___159 + tmp___160;
#line 121
  S[4] += t0;
#line 121
  S[0] = t0 + t1;
#line 122
  tmp___161 = __dyc_funcallvar_164;
#line 122
  tmp___162 = __dyc_funcallvar_165;
#line 122
  t0 = (((S[7] + tmp___161) + tmp___162) + 2730485921U) + W[40];
#line 122
  tmp___163 = __dyc_funcallvar_166;
#line 122
  tmp___164 = __dyc_funcallvar_167;
#line 122
  t1 = tmp___163 + tmp___164;
#line 122
  S[3] += t0;
#line 122
  S[7] = t0 + t1;
#line 123
  tmp___165 = __dyc_funcallvar_168;
#line 123
  tmp___166 = __dyc_funcallvar_169;
#line 123
  t0 = (((S[6] + tmp___165) + tmp___166) + 2820302411U) + W[41];
#line 123
  tmp___167 = __dyc_funcallvar_170;
#line 123
  tmp___168 = __dyc_funcallvar_171;
#line 123
  t1 = tmp___167 + tmp___168;
#line 123
  S[2] += t0;
#line 123
  S[6] = t0 + t1;
#line 124
  tmp___169 = __dyc_funcallvar_172;
#line 124
  tmp___170 = __dyc_funcallvar_173;
#line 124
  t0 = (((S[5] + tmp___169) + tmp___170) + 3259730800U) + W[42];
#line 124
  tmp___171 = __dyc_funcallvar_174;
#line 124
  tmp___172 = __dyc_funcallvar_175;
#line 124
  t1 = tmp___171 + tmp___172;
#line 124
  S[1] += t0;
#line 124
  S[5] = t0 + t1;
#line 125
  tmp___173 = __dyc_funcallvar_176;
#line 125
  tmp___174 = __dyc_funcallvar_177;
#line 125
  t0 = (((S[4] + tmp___173) + tmp___174) + 3345764771U) + W[43];
#line 125
  tmp___175 = __dyc_funcallvar_178;
#line 125
  tmp___176 = __dyc_funcallvar_179;
#line 125
  t1 = tmp___175 + tmp___176;
#line 125
  S[0] += t0;
#line 125
  S[4] = t0 + t1;
#line 126
  tmp___177 = __dyc_funcallvar_180;
#line 126
  tmp___178 = __dyc_funcallvar_181;
#line 126
  t0 = (((S[3] + tmp___177) + tmp___178) + 3516065817U) + W[44];
#line 126
  tmp___179 = __dyc_funcallvar_182;
#line 126
  tmp___180 = __dyc_funcallvar_183;
#line 126
  t1 = tmp___179 + tmp___180;
#line 126
  S[7] += t0;
#line 126
  S[3] = t0 + t1;
#line 127
  tmp___181 = __dyc_funcallvar_184;
#line 127
  tmp___182 = __dyc_funcallvar_185;
#line 127
  t0 = (((S[2] + tmp___181) + tmp___182) + 3600352804U) + W[45];
#line 127
  tmp___183 = __dyc_funcallvar_186;
#line 127
  tmp___184 = __dyc_funcallvar_187;
#line 127
  t1 = tmp___183 + tmp___184;
#line 127
  S[6] += t0;
#line 127
  S[2] = t0 + t1;
#line 128
  tmp___185 = __dyc_funcallvar_188;
#line 128
  tmp___186 = __dyc_funcallvar_189;
#line 128
  t0 = (((S[1] + tmp___185) + tmp___186) + 4094571909U) + W[46];
#line 128
  tmp___187 = __dyc_funcallvar_190;
#line 128
  tmp___188 = __dyc_funcallvar_191;
#line 128
  t1 = tmp___187 + tmp___188;
#line 128
  S[5] += t0;
#line 128
  S[1] = t0 + t1;
#line 129
  tmp___189 = __dyc_funcallvar_192;
#line 129
  tmp___190 = __dyc_funcallvar_193;
#line 129
  t0 = (((S[0] + tmp___189) + tmp___190) + 275423344U) + W[47];
#line 129
  tmp___191 = __dyc_funcallvar_194;
#line 129
  tmp___192 = __dyc_funcallvar_195;
#line 129
  t1 = tmp___191 + tmp___192;
#line 129
  S[4] += t0;
#line 129
  S[0] = t0 + t1;
#line 130
  tmp___193 = __dyc_funcallvar_196;
#line 130
  tmp___194 = __dyc_funcallvar_197;
#line 130
  t0 = (((S[7] + tmp___193) + tmp___194) + 430227734U) + W[48];
#line 130
  tmp___195 = __dyc_funcallvar_198;
#line 130
  tmp___196 = __dyc_funcallvar_199;
#line 130
  t1 = tmp___195 + tmp___196;
#line 130
  S[3] += t0;
#line 130
  S[7] = t0 + t1;
#line 131
  tmp___197 = __dyc_funcallvar_200;
#line 131
  tmp___198 = __dyc_funcallvar_201;
#line 131
  t0 = (((S[6] + tmp___197) + tmp___198) + 506948616U) + W[49];
#line 131
  tmp___199 = __dyc_funcallvar_202;
#line 131
  tmp___200 = __dyc_funcallvar_203;
#line 131
  t1 = tmp___199 + tmp___200;
#line 131
  S[2] += t0;
#line 131
  S[6] = t0 + t1;
#line 132
  tmp___201 = __dyc_funcallvar_204;
#line 132
  tmp___202 = __dyc_funcallvar_205;
#line 132
  t0 = (((S[5] + tmp___201) + tmp___202) + 659060556U) + W[50];
#line 132
  tmp___203 = __dyc_funcallvar_206;
#line 132
  tmp___204 = __dyc_funcallvar_207;
#line 132
  t1 = tmp___203 + tmp___204;
#line 132
  S[1] += t0;
#line 132
  S[5] = t0 + t1;
#line 133
  tmp___205 = __dyc_funcallvar_208;
#line 133
  tmp___206 = __dyc_funcallvar_209;
#line 133
  t0 = (((S[4] + tmp___205) + tmp___206) + 883997877U) + W[51];
#line 133
  tmp___207 = __dyc_funcallvar_210;
#line 133
  tmp___208 = __dyc_funcallvar_211;
#line 133
  t1 = tmp___207 + tmp___208;
#line 133
  S[0] += t0;
#line 133
  S[4] = t0 + t1;
#line 134
  tmp___209 = __dyc_funcallvar_212;
#line 134
  tmp___210 = __dyc_funcallvar_213;
#line 134
  t0 = (((S[3] + tmp___209) + tmp___210) + 958139571U) + W[52];
#line 134
  tmp___211 = __dyc_funcallvar_214;
#line 134
  tmp___212 = __dyc_funcallvar_215;
#line 134
  t1 = tmp___211 + tmp___212;
#line 134
  S[7] += t0;
#line 134
  S[3] = t0 + t1;
#line 135
  tmp___213 = __dyc_funcallvar_216;
#line 135
  tmp___214 = __dyc_funcallvar_217;
#line 135
  t0 = (((S[2] + tmp___213) + tmp___214) + 1322822218U) + W[53];
#line 135
  tmp___215 = __dyc_funcallvar_218;
#line 135
  tmp___216 = __dyc_funcallvar_219;
#line 135
  t1 = tmp___215 + tmp___216;
#line 135
  S[6] += t0;
#line 135
  S[2] = t0 + t1;
#line 136
  tmp___217 = __dyc_funcallvar_220;
#line 136
  tmp___218 = __dyc_funcallvar_221;
#line 136
  t0 = (((S[1] + tmp___217) + tmp___218) + 1537002063U) + W[54];
#line 136
  tmp___219 = __dyc_funcallvar_222;
#line 136
  tmp___220 = __dyc_funcallvar_223;
#line 136
  t1 = tmp___219 + tmp___220;
#line 136
  S[5] += t0;
#line 136
  S[1] = t0 + t1;
#line 137
  tmp___221 = __dyc_funcallvar_224;
#line 137
  tmp___222 = __dyc_funcallvar_225;
#line 137
  t0 = (((S[0] + tmp___221) + tmp___222) + 1747873779U) + W[55];
#line 137
  tmp___223 = __dyc_funcallvar_226;
#line 137
  tmp___224 = __dyc_funcallvar_227;
#line 137
  t1 = tmp___223 + tmp___224;
#line 137
  S[4] += t0;
#line 137
  S[0] = t0 + t1;
#line 138
  tmp___225 = __dyc_funcallvar_228;
#line 138
  tmp___226 = __dyc_funcallvar_229;
#line 138
  t0 = (((S[7] + tmp___225) + tmp___226) + 1955562222U) + W[56];
#line 138
  tmp___227 = __dyc_funcallvar_230;
#line 138
  tmp___228 = __dyc_funcallvar_231;
#line 138
  t1 = tmp___227 + tmp___228;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(t0);
  __dyc_printpre_byte(t1);
  __dyc_print_ptr__char(buf);
}
}
