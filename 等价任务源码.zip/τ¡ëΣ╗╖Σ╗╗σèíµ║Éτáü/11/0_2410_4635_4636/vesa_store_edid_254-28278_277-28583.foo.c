#include <dycfoo.h>
#include "../video-vesa.i.hd.c.h"
void __dyc_foo(void) 
{ struct boot_params boot_params ;
  u16 ax ;
  u16 bx ;
  u16 cx ;
  u16 dx ;
  u16 di ;

  {
  boot_params = __dyc_read_comp_35boot_params();
  ax = 0;
  bx = 0;
  cx = 0;
  dx = 0;
  di = 0;
#line 254
  ax = (unsigned short)20245;
#line 255
  bx = (unsigned short)0;
#line 256
  cx = (unsigned short)0;
#line 257
  di = (unsigned short)0;
#line 267
  if ((int )ax != 79) {
    goto __dyc_dummy_label;
  }
#line 273
  ax = (unsigned short)20245;
#line 274
  bx = (unsigned short)1;
#line 275
  cx = (unsigned short)0;
#line 276
  dx = (unsigned short)0;
#line 277
  di = (unsigned short )((unsigned long )(& boot_params.edid_info));
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(ax);
  __dyc_printpre_byte(bx);
  __dyc_printpre_byte(cx);
  __dyc_printpre_byte(dx);
  __dyc_printpre_byte(di);
}
}
