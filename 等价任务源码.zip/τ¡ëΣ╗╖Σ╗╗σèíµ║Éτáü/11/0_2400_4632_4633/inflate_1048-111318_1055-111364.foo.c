#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned int outcnt ;
  ulg bb ;
  unsigned int bk ;
  unsigned int hufts ;
  int e ;
  int r ;
  unsigned int h ;
  int __dyc_funcallvar_1 ;

  {
  e = __dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  outcnt = 0;
  bb = 0;
  bk = 0;
  hufts = 0;
  r = 0;
  h = 0;
#line 1048
  outcnt = 0U;
#line 1049
  bk = 0U;
#line 1050
  bb = 0UL;
#line 1054
  h = 0U;
#line 1055
  while (1) {
    while_50_continue: /* CIL Label */ ;
    {
#line 1056
    hufts = 0U;

#line 1058
    r = __dyc_funcallvar_1;
    }
#line 1058
    if (r != 0) {
      {

      }
      goto __dyc_dummy_label;
    }
    {

    }
#line 1063
    if (hufts > h) {
#line 1064
      h = hufts;
    }
#line 1055
    if (! (! e)) {
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(outcnt);
  __dyc_printpre_byte(bb);
  __dyc_printpre_byte(bk);
  __dyc_printpre_byte(hufts);
  __dyc_printpre_byte(h);
}
}
