#include <dycfoo.h>
#include "../splay.i.hd.c.h"
void __dyc_foo(void) 
{ struct curltime KEY_NOTUSED___0 ;
  int tmp___3 ;
  struct Curl_tree *removenode ;

  {
  KEY_NOTUSED___0 = (struct curltime  const  )__dyc_read_comp_77curltime();
  removenode = __dyc_read_ptr__comp_78Curl_tree();
  tmp___3 = 0;
#line 218
  if (! removenode) {
    goto __dyc_dummy_label;
  }
#line 221
  tmp___3 = -1;
#line 221
  if (KEY_NOTUSED___0.tv_sec > (time_t const   )removenode->key.tv_sec) {
#line 221
    tmp___3 = 1;
  } else {
#line 221
    if (KEY_NOTUSED___0.tv_usec < (int const   )removenode->key.tv_usec) {
#line 221
      tmp___3 = -1;
    } else {
#line 221
      if (KEY_NOTUSED___0.tv_usec > (int const   )removenode->key.tv_usec) {
#line 221
        tmp___3 = 1;
      } else {
#line 221
        tmp___3 = 0;
      }
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(tmp___3);
}
}
