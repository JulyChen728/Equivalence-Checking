#include <dycfoo.h>
#include "../video.i.hd.c.h"
void __dyc_foo(void) 
{ char entry_buf[4] ;
  int len ;
  int key ;
  int tmp ;

  {
  len = __dyc_readpre_byte();
  key = __dyc_readpre_byte();
  tmp = 0;
#line 264
  len --;
#line 266
  if (key <= 57) {
    goto _L;
  }
  _L___1: /* CIL Label */ 
#line 266
  if (key >= 65) {
#line 266
    if (key <= 90) {
      goto _L;
    } else {
      goto _L___0;
    }
  } else {
    _L___0: /* CIL Label */ 
#line 266
    if (key >= 97) {
#line 266
      if (key <= 122) {
        _L: /* CIL Label */ 
#line 269
        if ((unsigned long )len < sizeof(char [4])) {
          {
#line 270
          tmp = len;
#line 270
          len ++;
#line 270
          entry_buf[tmp] = (char )key;

          }
        }
      }
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(len);
}
}
