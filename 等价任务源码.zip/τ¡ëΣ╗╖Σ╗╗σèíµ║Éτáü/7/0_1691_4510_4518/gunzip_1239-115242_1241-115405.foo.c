#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ uch *inbuf ;
  unsigned int insize ;
  unsigned int inptr ;
  ulg orig_crc ;
  int v___13 ;
  int v___14 ;
  int tmp___66 ;
  unsigned int tmp___67 ;
  int v___15 ;
  int tmp___70 ;
  unsigned int tmp___71 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;

  {
  inbuf = __dyc_read_ptr__typdef_uch();
  insize = (unsigned int )__dyc_readpre_byte();
  inptr = (unsigned int )__dyc_readpre_byte();
  v___13 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  orig_crc = 0;
  v___14 = 0;
  tmp___66 = 0;
  tmp___67 = 0;
  v___15 = 0;
  tmp___70 = 0;
  tmp___71 = 0;
#line 1239
  orig_crc = (unsigned long )((unsigned char )v___13);
#line 1240
  if (inptr < insize) {
#line 1240
    tmp___67 = inptr;
#line 1240
    inptr ++;
#line 1240
    tmp___66 = (int )*(inbuf + tmp___67);
  } else {
    {
#line 1240
    tmp___66 = __dyc_funcallvar_18;
    }
  }
#line 1240
  v___14 = tmp___66;
#line 1240
  if (v___14 < 0) {
    goto __dyc_dummy_label;
  }
#line 1240
  orig_crc |= (unsigned long )((unsigned char )v___14) << 8;
#line 1241
  if (inptr < insize) {
#line 1241
    tmp___71 = inptr;
#line 1241
    inptr ++;
#line 1241
    tmp___70 = (int )*(inbuf + tmp___71);
  } else {
    {
#line 1241
    tmp___70 = __dyc_funcallvar_19;
    }
  }
#line 1241
  v___15 = tmp___70;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(inptr);
  __dyc_printpre_byte(orig_crc);
  __dyc_printpre_byte(v___15);
}
}
