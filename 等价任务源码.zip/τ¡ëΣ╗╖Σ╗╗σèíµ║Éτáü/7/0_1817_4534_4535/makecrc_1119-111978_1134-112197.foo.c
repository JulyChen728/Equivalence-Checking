#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ ulg crc_32_tab[256] ;
  ulg crc ;
  unsigned long c ;
  unsigned long e ;
  int i ;
  int k ;

  {
  e = (unsigned long )__dyc_readpre_byte();
  crc = 0;
  c = 0;
  i = 0;
  k = 0;
#line 1119
  crc_32_tab[0] = 0UL;
#line 1121
  i = 1;
#line 1121
  while (1) {
    while_53_continue: /* CIL Label */ ;
#line 1121
    if (! (i < 256)) {
      goto while_53_break;
    }
#line 1123
    c = 0UL;
#line 1124
    k = i | 256;
    {
#line 1124
    while (1) {
      while_54_continue: /* CIL Label */ ;
#line 1124
      if (! (k != 1)) {
        goto while_54_break;
      }
#line 1126
      if (c & 1UL) {
#line 1126
        c = (c >> 1) ^ e;
      } else {
#line 1126
        c >>= 1;
      }
#line 1127
      if (k & 1) {
#line 1128
        c ^= e;
      }
#line 1124
      k >>= 1;
    }
    while_54_break: /* CIL Label */ ;
    }
#line 1130
    crc_32_tab[i] = c;
#line 1121
    i ++;
  }
  while_53_break: /* CIL Label */ ;
#line 1134
  crc = 4294967295UL;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(crc);
}
}
