#include <dycfoo.h>
#include "../cpucheck.i.hd.c.h"
void __dyc_foo(void) 
{ struct cpu_features cpu ;
  u32 err_flags[8] ;
  int req_level ;
  int err ;
  int tmp___5 ;
  int *cpu_level_ptr ;
  int *req_level_ptr ;
  u32 **err_flags_ptr ;

  {
  cpu = __dyc_read_comp_36cpu_features();
  req_level = (int const   )__dyc_readpre_byte();
  err = __dyc_readpre_byte();
  cpu_level_ptr = __dyc_read_ptr__int();
  req_level_ptr = __dyc_read_ptr__int();
  err_flags_ptr = __dyc_read_ptr__ptr__typdef_u32();
  tmp___5 = 0;
#line 254
  if (err_flags_ptr) {
#line 255
    if (err) {
#line 255
      *err_flags_ptr = err_flags;
    } else {
#line 255
      *err_flags_ptr = (u32 *)((void *)0);
    }
  }
#line 256
  if (cpu_level_ptr) {
#line 257
    *cpu_level_ptr = cpu.level;
  }
#line 258
  if (req_level_ptr) {
#line 259
    *req_level_ptr = (int )req_level;
  }
#line 261
  if (cpu.level < (int )req_level) {
#line 261
    tmp___5 = -1;
  } else {
#line 261
    if (err) {
#line 261
      tmp___5 = -1;
    } else {
#line 261
      tmp___5 = 0;
    }
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(tmp___5);
}
}
