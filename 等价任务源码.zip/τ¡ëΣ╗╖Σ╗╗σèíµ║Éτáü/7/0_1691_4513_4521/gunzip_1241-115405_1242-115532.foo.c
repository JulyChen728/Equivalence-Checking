#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ uch *inbuf ;
  unsigned int insize ;
  unsigned int inptr ;
  ulg orig_crc ;
  int v___15 ;
  int tmp___70 ;
  unsigned int tmp___71 ;
  int v___16 ;
  int tmp___74 ;
  unsigned int tmp___75 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;

  {
  inbuf = __dyc_read_ptr__typdef_uch();
  insize = (unsigned int )__dyc_readpre_byte();
  inptr = (unsigned int )__dyc_readpre_byte();
  orig_crc = (ulg )__dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  v___15 = 0;
  tmp___70 = 0;
  tmp___71 = 0;
  v___16 = 0;
  tmp___74 = 0;
  tmp___75 = 0;
#line 1241
  if (inptr < insize) {
#line 1241
    tmp___71 = inptr;
#line 1241
    inptr ++;
#line 1241
    tmp___70 = (int )*(inbuf + tmp___71);
  } else {
    {
#line 1241
    tmp___70 = __dyc_funcallvar_19;
    }
  }
#line 1241
  v___15 = tmp___70;
#line 1241
  if (v___15 < 0) {
    goto __dyc_dummy_label;
  }
#line 1241
  orig_crc |= (unsigned long )((unsigned char )v___15) << 16;
#line 1242
  if (inptr < insize) {
#line 1242
    tmp___75 = inptr;
#line 1242
    inptr ++;
#line 1242
    tmp___74 = (int )*(inbuf + tmp___75);
  } else {
    {
#line 1242
    tmp___74 = __dyc_funcallvar_20;
    }
  }
#line 1242
  v___16 = tmp___74;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(inptr);
  __dyc_printpre_byte(orig_crc);
  __dyc_printpre_byte(v___16);
}
}
