#include <dycfoo.h>
#include "../a20.i.hd.c.h"
void __dyc_foo(void) 
{ int loops ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___4 ;
  int __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;

  {
  loops = __dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___4 = 0;
#line 133
  tmp___4 = loops;
#line 133
  loops --;
#line 133
  if (! tmp___4) {
    goto __dyc_dummy_label;
  }
#line 136
  tmp = __dyc_funcallvar_1;
#line 136
  if (tmp) {
    goto __dyc_dummy_label;
  }

#line 141
  tmp___0 = __dyc_funcallvar_2;
#line 141
  if (tmp___0) {
    goto __dyc_dummy_label;
  }

#line 146
  tmp___1 = __dyc_funcallvar_3;
#line 146
  if (tmp___1) {
    goto __dyc_dummy_label;
  }

#line 150
  tmp___2 = __dyc_funcallvar_4;
#line 150
  if (tmp___2) {
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(loops);
}
}
