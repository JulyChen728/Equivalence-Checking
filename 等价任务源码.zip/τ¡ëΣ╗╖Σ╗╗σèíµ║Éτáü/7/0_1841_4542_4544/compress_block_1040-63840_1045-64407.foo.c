#include <dycfoo.h>
#include "../deftree.i.hd.c.h"
void __dyc_foo(void) 
{ int const   extra_lbits[29] ;
  int base_length[29] ;
  unsigned int dist ;
  int lc ;
  unsigned int code ;
  int extra ;
  int len___1 ;
  int val___1 ;
  int tmp___4 ;
  int tmp___5 ;
  deflate_state *s ;

  {
  dist = (unsigned int )__dyc_readpre_byte();
  lc = __dyc_readpre_byte();
  code = (unsigned int )__dyc_readpre_byte();
  s = __dyc_read_ptr__typdef_deflate_state();
  extra = 0;
  len___1 = 0;
  val___1 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
#line 1040
  extra = (int )extra_lbits[code];
#line 1041
  if (extra != 0) {
#line 1042
    lc -= base_length[code];
#line 1043
    len___1 = extra;
#line 1043
    if (s->bi_valid > (int )(16UL * sizeof(char )) - len___1) {
#line 1043
      val___1 = lc;
#line 1043
      s->bi_buf = (unsigned short )((int )s->bi_buf | (val___1 << s->bi_valid));
#line 1043
      tmp___4 = s->pending;
#line 1043
      (s->pending) ++;
#line 1043
      *(s->pending_buf + tmp___4) = (unsigned char )((int )s->bi_buf & 255);
#line 1043
      tmp___5 = s->pending;
#line 1043
      (s->pending) ++;
#line 1043
      *(s->pending_buf + tmp___5) = (unsigned char )((int )s->bi_buf >> 8);
#line 1043
      s->bi_buf = (unsigned short )((int )((unsigned short )val___1) >> (16UL * sizeof(char ) - (unsigned long )s->bi_valid));
#line 1043
      s->bi_valid = (int )((unsigned long )s->bi_valid + ((unsigned long )len___1 - 16UL * sizeof(char )));
    } else {
#line 1043
      s->bi_buf = (unsigned short )((int )s->bi_buf | (lc << s->bi_valid));
#line 1043
      s->bi_valid += len___1;
    }
  }
#line 1045
  dist --;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(dist);
}
}
