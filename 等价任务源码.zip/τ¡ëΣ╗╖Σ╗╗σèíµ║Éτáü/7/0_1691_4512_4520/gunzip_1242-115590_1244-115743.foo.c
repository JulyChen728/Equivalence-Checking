#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ uch *inbuf ;
  unsigned int insize ;
  unsigned int inptr ;
  ulg orig_crc ;
  ulg orig_len ;
  int v___16 ;
  int v___17 ;
  int tmp___78 ;
  unsigned int tmp___79 ;
  int __dyc_funcallvar_21 ;

  {
  inbuf = __dyc_read_ptr__typdef_uch();
  insize = (unsigned int )__dyc_readpre_byte();
  inptr = (unsigned int )__dyc_readpre_byte();
  orig_crc = (ulg )__dyc_readpre_byte();
  v___16 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  orig_len = 0;
  v___17 = 0;
  tmp___78 = 0;
  tmp___79 = 0;
#line 1242
  if (v___16 < 0) {
    goto __dyc_dummy_label;
  }
#line 1242
  orig_crc |= (unsigned long )((unsigned char )v___16) << 24;
#line 1244
  if (inptr < insize) {
#line 1244
    tmp___79 = inptr;
#line 1244
    inptr ++;
#line 1244
    tmp___78 = (int )*(inbuf + tmp___79);
  } else {
    {
#line 1244
    tmp___78 = __dyc_funcallvar_21;
    }
  }
#line 1244
  v___17 = tmp___78;
#line 1244
  if (v___17 < 0) {
    goto __dyc_dummy_label;
  }
#line 1244
  orig_len = (unsigned long )((unsigned char )v___17);
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(inptr);
  __dyc_printpre_byte(orig_crc);
  __dyc_printpre_byte(orig_len);
}
}
