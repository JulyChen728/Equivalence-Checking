#include <dycfoo.h>
#include "../video-vesa.i.hd.c.h"
void __dyc_foo(void) 
{ struct vesa_general_info vginfo ;
  struct vesa_mode_info vminfo ;
  u16 ax ;
  u16 cx ;
  u16 di ;
  u16 mode ;
  addr_t mode_ptr ;
  struct mode_info *mi ;
  int nmodes ;
  bool tmp___0 ;
  char *tmp___1 ;
  char *tmp___2 ;
  u16 __dyc_funcallvar_2 ;
  bool __dyc_funcallvar_3 ;
  char *__dyc_funcallvar_4 ;
  char *__dyc_funcallvar_5 ;

  {
  vginfo = __dyc_read_comp_39vesa_general_info();
  vminfo = __dyc_read_comp_40vesa_mode_info();
  nmodes = __dyc_readpre_byte();
  __dyc_funcallvar_2 = (u16 )__dyc_readpre_byte();
  __dyc_funcallvar_3 = (bool )__dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_read_ptr__char();
  __dyc_funcallvar_5 = __dyc_read_ptr__char();
  ax = 0;
  cx = 0;
  di = 0;
  mode = 0;
  mode_ptr = 0;
  mi = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
#line 55
  mode_ptr = (unsigned int )vginfo.video_mode_ptr.off;
#line 57
  while (1) {
    while_0_continue: /* CIL Label */ ;
    {
#line 57
    mode = __dyc_funcallvar_2;
    }
#line 57
    if (! ((int )mode != 65535)) {
      goto while_0_break;
    }
    {
#line 58
    mode_ptr += 2U;
#line 60
    tmp___0 = __dyc_funcallvar_3;
    }
#line 60
    if (! tmp___0) {
      goto while_0_break;
    }
#line 63
    if ((int )mode & -512) {
      goto while_0_continue;
    }
    {

#line 68
    ax = (unsigned short)20225;
#line 69
    cx = mode;
#line 70
    di = (unsigned short )((unsigned long )(& vminfo));

    }
#line 75
    if ((int )ax != 79) {
      goto while_0_continue;
    }
#line 78
    if (((int )vminfo.mode_attr & 21) == 5) {
      {
#line 81
      tmp___1 = __dyc_funcallvar_4;
#line 81
      mi = (struct mode_info *)tmp___1;
#line 82
      mi->mode = (unsigned short )((int )mode + 512);
#line 83
      mi->x = (unsigned char )vminfo.h_res;
#line 84
      mi->y = (unsigned char )vminfo.v_res;
#line 85
      nmodes ++;
      }
    } else {
#line 86
      if (((int )vminfo.mode_attr & 153) == 153) {
        {
#line 93
        tmp___2 = __dyc_funcallvar_5;
#line 93
        mi = (struct mode_info *)tmp___2;
#line 94
        mi->mode = (unsigned short )((int )mode + 512);
#line 95
        mi->y = (unsigned char)0;
#line 95
        mi->x = mi->y;
#line 96
        nmodes ++;
        }
      }
    }
  }
  while_0_break: /* CIL Label */ ;
  goto __dyc_dummy_label;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(cx);
  __dyc_printpre_byte(di);
  __dyc_printpre_byte(mode_ptr);
  __dyc_printpre_byte(nmodes);
}
}
