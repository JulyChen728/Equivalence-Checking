#include <dycfoo.h>
#include "../inffast.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned char *out ;
  unsigned int write ;
  unsigned int op ;
  unsigned int len ;
  unsigned int dist ;
  unsigned char *from ;

  {
  out = (unsigned char *)__dyc_read_ptr__char();
  write = (unsigned int )__dyc_readpre_byte();
  len = (unsigned int )__dyc_readpre_byte();
  dist = (unsigned int )__dyc_readpre_byte();
  from = (unsigned char *)__dyc_read_ptr__char();
  op = 0;
#line 209
  if (write < len) {
#line 210
    op = write;
#line 211
    len -= op;
    {
#line 212
    while (1) {
      while_3_continue: /* CIL Label */ ;
#line 213
      out ++;
#line 213
      from ++;
#line 213
      *out = *from;
#line 212
      op --;
#line 212
      if (! op) {
        goto while_3_break;
      }
    }
    while_3_break: /* CIL Label */ ;
    }
#line 215
    from = out - dist;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(len);
  __dyc_print_ptr__char(from);
}
}
