#include <dycfoo.h>
#include "../early_printk.i.hd.c.h"
void __dyc_foo(void) 
{ int early_serial_base ;
  int bases[2] ;
  char *e ;
  unsigned int port ;
  unsigned long tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  char *s ;
  unsigned long __dyc_funcallvar_3 ;
  unsigned long __dyc_funcallvar_4 ;

  {
  e = __dyc_read_ptr__char();
  tmp___0 = __dyc_readpre_byte();
  s = __dyc_read_ptr__char();
  __dyc_funcallvar_3 = (unsigned long )__dyc_readpre_byte();
  __dyc_funcallvar_4 = (unsigned long )__dyc_readpre_byte();
  early_serial_base = 0;
  port = 0;
  tmp = 0;
  tmp___1 = 0;
#line 116
  if (! tmp___0) {
#line 117
    s += 4;
  }
#line 118
  tmp___1 = __dyc_funcallvar_3;
#line 118
  port = (unsigned int )tmp___1;
#line 119
  if (port > 1U) {
#line 120
    port = 0U;
  } else {
#line 119
    if ((unsigned long )s == (unsigned long )e) {
#line 120
      port = 0U;
    }
  }
#line 121
  early_serial_base = bases[port];
#line 112
  tmp = __dyc_funcallvar_4;
#line 112
  early_serial_base = (int )tmp;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(early_serial_base);
  __dyc_print_ptr__char(s);
}
}
