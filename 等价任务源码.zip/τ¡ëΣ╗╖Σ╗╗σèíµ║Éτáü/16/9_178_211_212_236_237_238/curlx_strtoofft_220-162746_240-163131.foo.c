#include <dycfoo.h>
#include "../strtoofft.i.hd.c.h"
void __dyc_foo(void) 
{ char *end ;
  curl_off_t number ;
  int *tmp ;
  int tmp___0 ;
  int *tmp___1 ;
  char const   *str ;
  char **endp ;
  curl_off_t *num ;
  int __dyc_funcallvar_2 ;
  long __dyc_funcallvar_3 ;
  int *__dyc_funcallvar_4 ;

  {
  end = __dyc_read_ptr__char();
  tmp = __dyc_read_ptr__int();
  str = (char const   *)__dyc_read_ptr__char();
  endp = __dyc_read_ptr__ptr__char();
  num = __dyc_read_ptr__typdef_curl_off_t();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_read_ptr__int();
  number = 0;
  tmp___0 = 0;
  tmp___1 = 0;
#line 220
  *tmp = 0;
#line 221
  *num = 0L;
#line 223
  while (1) {
    while_0_continue: /* CIL Label */ ;
#line 223
    if (*str) {
      {
#line 223
      tmp___0 = __dyc_funcallvar_2;
      }
#line 223
      if (! tmp___0) {
        goto while_0_break;
      }
    } else {
      goto while_0_break;
    }
#line 224
    str ++;
  }
  while_0_break: /* CIL Label */ ;
#line 225
  if (45 == (int )*str) {
#line 226
    if (endp) {
#line 227
      *endp = (char *)str;
    }
    goto __dyc_dummy_label;
  }
#line 230
  number = __dyc_funcallvar_3;
#line 231
  if (endp) {
#line 232
    *endp = end;
  }
#line 233
  tmp___1 = __dyc_funcallvar_4;
#line 233
  if (*tmp___1 == 34) {
    goto __dyc_dummy_label;
  } else {
#line 236
    if ((unsigned long )str == (unsigned long )end) {
      goto __dyc_dummy_label;
    }
  }
#line 240
  *num = number;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(number);
}
}
