#include <dycfoo.h>
#include "../socketpair.i.hd.c.h"
void __dyc_foo(void) 
{ union __anonunion_a_74 a ;
  union __anonunion_a_74 a2 ;
  curl_socklen_t addrlen ;
  int tmp___5 ;
  int tmp___6 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;

  {
  a = __dyc_read_comp_100__anonunion_a_74();
  a2 = __dyc_read_comp_100__anonunion_a_74();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  addrlen = 0;
  tmp___5 = 0;
  tmp___6 = 0;
#line 114
  addrlen = (unsigned int )sizeof(struct sockaddr_in );
#line 115
  tmp___5 = __dyc_funcallvar_11;
#line 115
  if (tmp___5 == -1) {
    goto __dyc_dummy_label;
  } else {
#line 115
    if (addrlen < (curl_socklen_t )((int )sizeof(struct sockaddr_in ))) {
      goto __dyc_dummy_label;
    }
  }
#line 118
  addrlen = (unsigned int )sizeof(struct sockaddr_in );
#line 119
  tmp___6 = __dyc_funcallvar_12;
#line 119
  if (tmp___6 == -1) {
    goto __dyc_dummy_label;
  } else {
#line 119
    if (addrlen < (curl_socklen_t )((int )sizeof(struct sockaddr_in ))) {
      goto __dyc_dummy_label;
    }
  }
#line 122
  if ((int )a.inaddr.sin_family != (int )a2.inaddr.sin_family) {
    goto __dyc_dummy_label;
  } else {
#line 122
    if (a.inaddr.sin_addr.s_addr != a2.inaddr.sin_addr.s_addr) {
      goto __dyc_dummy_label;
    } else {
#line 122
      if ((int )a.inaddr.sin_port != (int )a2.inaddr.sin_port) {
        goto __dyc_dummy_label;
      }
    }
  }

  goto __dyc_dummy_label;



  goto __dyc_dummy_label;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(addrlen);
}
}
