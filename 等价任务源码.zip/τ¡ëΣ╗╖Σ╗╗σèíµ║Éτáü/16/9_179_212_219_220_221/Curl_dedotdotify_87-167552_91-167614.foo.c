#include <dycfoo.h>
#include "../dotdot.i.hd.c.h"
void __dyc_foo(void) 
{ char *clone ;
  size_t clen ;
  char *out ;
  char *outptr ;
  char *queryp ;
  char *tmp___1 ;
  char *tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  char *__dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;

  {
  clone = __dyc_read_ptr__char();
  clen = (size_t )__dyc_readpre_byte();
  out = __dyc_read_ptr__char();
  outptr = __dyc_read_ptr__char();
  __dyc_funcallvar_4 = __dyc_read_ptr__char();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  queryp = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
#line 87
  queryp = __dyc_funcallvar_4;
#line 88
  if (queryp) {
#line 89
    *queryp = (char)0;
  }
#line 91
  while (1) {
    while_0_continue: /* CIL Label */ ;
    {
#line 96
    tmp___10 = __dyc_funcallvar_5;
    }
#line 96
    if (tmp___10) {
      {
#line 100
      tmp___9 = __dyc_funcallvar_6;
      }
#line 100
      if (tmp___9) {
        {
#line 108
        tmp___8 = __dyc_funcallvar_7;
        }
#line 108
        if (tmp___8) {
          {
#line 112
          tmp___7 = __dyc_funcallvar_8;
          }
#line 112
          if (tmp___7) {
            {
#line 123
            tmp___6 = __dyc_funcallvar_9;
            }
#line 123
            if (tmp___6) {
              {
#line 134
              tmp___5 = __dyc_funcallvar_10;
              }
#line 134
              if (tmp___5) {
                {
#line 150
                tmp___3 = __dyc_funcallvar_11;
                }
#line 150
                if (tmp___3) {
                  {
#line 150
                  tmp___4 = __dyc_funcallvar_12;
                  }
#line 150
                  if (tmp___4) {
                    {
#line 161
                    while (1) {
                      while_1_continue: /* CIL Label */ ;
#line 162
                      tmp___1 = outptr;
#line 162
                      outptr ++;
#line 162
                      tmp___2 = clone;
#line 162
                      clone ++;
#line 162
                      *tmp___1 = *tmp___2;
#line 163
                      clen --;
#line 161
                      if (*clone) {
#line 161
                        if (! ((int )*clone != 47)) {
                          goto while_1_break;
                        }
                      } else {
                        goto while_1_break;
                      }
                    }
                    while_1_break: /* CIL Label */ ;
                    }
#line 165
                    *outptr = (char)0;
                  } else {
#line 151
                    *clone = (char)0;
#line 152
                    *out = (char)0;
                  }
                } else {
#line 151
                  *clone = (char)0;
#line 152
                  *out = (char)0;
                }
              } else {
#line 135
                *(clone + 2) = (char )'/';
#line 136
                clone += 2;
#line 137
                clen -= 2UL;
                {
#line 139
                while (1) {
                  while_2_continue: /* CIL Label */ ;
#line 139
                  if (! ((unsigned long )outptr > (unsigned long )out)) {
                    goto while_2_break;
                  }
#line 140
                  outptr --;
#line 141
                  if ((int )*outptr == 47) {
                    goto while_2_break;
                  }
                }
                while_2_break: /* CIL Label */ ;
                }
#line 144
                *outptr = (char)0;
              }
            } else {
#line 124
              clone += 3;
#line 125
              clen -= 3UL;
              {
#line 127
              while (1) {
                while_3_continue: /* CIL Label */ ;
#line 127
                if (! ((unsigned long )outptr > (unsigned long )out)) {
                  goto while_3_break;
                }
#line 128
                outptr --;
#line 129
                if ((int )*outptr == 47) {
                  goto while_3_break;
                }
              }
              while_3_break: /* CIL Label */ ;
              }
#line 132
              *outptr = (char)0;
            }
          } else {
#line 113
            *(clone + 1) = (char )'/';
#line 114
            clone ++;
#line 115
            clen --;
          }
        } else {
#line 109
          clone += 2;
#line 110
          clen -= 2UL;
        }
      } else {
#line 101
        clone += 3;
#line 102
        clen -= 3UL;
      }
    } else {
#line 97
      clone += 2;
#line 98
      clen -= 2UL;
    }
#line 91
    if (! *clone) {
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(clen);
}
}
