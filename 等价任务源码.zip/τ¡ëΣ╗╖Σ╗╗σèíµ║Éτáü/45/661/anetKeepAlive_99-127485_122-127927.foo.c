#include <dycfoo.h>
#include "../anet.i.hd.c.h"
void __dyc_foo(void) 
{ int val ;
  int *tmp ;
  char *tmp___0 ;
  int tmp___1 ;
  int *tmp___2 ;
  char *tmp___3 ;
  int tmp___4 ;
  int *tmp___5 ;
  char *tmp___6 ;
  int tmp___7 ;
  int interval ;
  int *__dyc_funcallvar_2 ;
  char *__dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int *__dyc_funcallvar_5 ;
  char *__dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int *__dyc_funcallvar_8 ;
  char *__dyc_funcallvar_9 ;

  {
  tmp___1 = __dyc_readpre_byte();
  interval = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_read_ptr__int();
  __dyc_funcallvar_3 = __dyc_read_ptr__char();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_read_ptr__int();
  __dyc_funcallvar_6 = __dyc_read_ptr__char();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_read_ptr__int();
  __dyc_funcallvar_9 = __dyc_read_ptr__char();
  val = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
#line 99
  if (tmp___1 == -1) {
    {
#line 101
    tmp = __dyc_funcallvar_2;
#line 101
    tmp___0 = __dyc_funcallvar_3;

    }
    goto __dyc_dummy_label;
  }
#line 111
  val = interval;
#line 112
  tmp___4 = __dyc_funcallvar_4;
#line 112
  if (tmp___4 < 0) {
    {
#line 113
    tmp___2 = __dyc_funcallvar_5;
#line 113
    tmp___3 = __dyc_funcallvar_6;

    }
    goto __dyc_dummy_label;
  }
#line 120
  val = interval / 3;
#line 121
  if (val == 0) {
#line 121
    val = 1;
  }
#line 122
  tmp___7 = __dyc_funcallvar_7;
#line 122
  if (tmp___7 < 0) {
    {
#line 123
    tmp___5 = __dyc_funcallvar_8;
#line 123
    tmp___6 = __dyc_funcallvar_9;

    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(val);
  __dyc_print_ptr__int(tmp);
  __dyc_print_ptr__char(tmp___0);
  __dyc_print_ptr__int(tmp___2);
  __dyc_print_ptr__char(tmp___3);
  __dyc_print_ptr__int(tmp___5);
  __dyc_print_ptr__char(tmp___6);
}
}
