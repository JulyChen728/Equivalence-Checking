#include <dycfoo.h>
#include "../ldebug.i.hd.c.h"
void __dyc_foo(void) 
{ lu_byte const __attribute__((__visibility__("hidden")))  luaP_opmodes[38] ;
  int pc ;
  int last ;
  int tmp ;
  Instruction i ;
  OpCode op ;
  int a ;
  int b ;
  int c ;
  int tmp___0 ;
  int tmp___1 ;
  int dest ;
  int j ;
  Instruction d ;
  int dest___0 ;
  int __attribute__((__visibility__("hidden")))  tmp___2 ;
  int nup ;
  int j___0 ;
  OpCode op1 ;
  int __attribute__((__visibility__("hidden")))  tmp___3 ;
  Proto const   *pt ;
  int lastpc ;
  int reg ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __attribute__((__visibility__("hidden")))  __dyc_funcallvar_4 ;
  int __attribute__((__visibility__("hidden")))  __dyc_funcallvar_5 ;

  {
  tmp = __dyc_readpre_byte();
  pt = (Proto const   *)__dyc_read_ptr__typdef_Proto();
  lastpc = __dyc_readpre_byte();
  reg = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = (int __attribute__((__visibility__("hidden")))  )__dyc_readpre_byte();
  __dyc_funcallvar_5 = (int __attribute__((__visibility__("hidden")))  )__dyc_readpre_byte();
  pc = 0;
  last = 0;
  i = 0;
  op = 0;
  a = 0;
  b = 0;
  c = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  dest = 0;
  j = 0;
  d = 0;
  dest___0 = 0;
  tmp___2 = 0;
  nup = 0;
  j___0 = 0;
  op1 = 0;
  tmp___3 = 0;
#line 321
  if (! tmp) {
    goto __dyc_dummy_label;
  }
#line 322
  pc = 0;
#line 322
  while (1) {
    while_6_continue: /* CIL Label */ ;
#line 322
    if (! (pc < lastpc)) {
      goto while_6_break;
    }
#line 323
    i = *(pt->code + pc);
#line 324
    op = (enum __anonenum_OpCode_13 )(i & ~ (4294967295U << 6));
#line 325
    a = (int )((i >> 6) & ~ (4294967295U << 8));
#line 326
    b = 0;
#line 327
    c = 0;
#line 328
    if (! ((int )op < 38)) {
      goto __dyc_dummy_label;
    }
#line 329
    if (! (a < (int )pt->maxstacksize)) {
      goto __dyc_dummy_label;
    }
#line 331
    if ((int )((enum OpMode )((int const __attribute__((__visibility__("hidden")))  )luaP_opmodes[op] & (int const __attribute__((__visibility__("hidden")))  )3)) == 0) {
      goto switch_7_0;
    } else {
#line 338
      if ((int )((enum OpMode )((int const __attribute__((__visibility__("hidden")))  )luaP_opmodes[op] & (int const __attribute__((__visibility__("hidden")))  )3)) == 1) {
        goto switch_7_1;
      } else {
#line 343
        if ((int )((enum OpMode )((int const __attribute__((__visibility__("hidden")))  )luaP_opmodes[op] & (int const __attribute__((__visibility__("hidden")))  )3)) == 2) {
          goto switch_7_2;
        } else {
#line 330
          if (0) {
            switch_7_0: /* CIL Label */ 
            {
#line 332
            b = (int )((i >> 23) & ~ (4294967295U << 9));
#line 333
            c = (int )((i >> 14) & ~ (4294967295U << 9));
#line 334
            tmp___0 = __dyc_funcallvar_2;
            }
#line 334
            if (! tmp___0) {
              goto __dyc_dummy_label;
            }
            {
#line 335
            tmp___1 = __dyc_funcallvar_3;
            }
#line 335
            if (! tmp___1) {
              goto __dyc_dummy_label;
            }
            goto switch_7_break;
            switch_7_1: /* CIL Label */ 
#line 339
            b = (int )((i >> 14) & ~ (4294967295U << 18));
#line 340
            if ((int )((enum OpArgMask )(((int const __attribute__((__visibility__("hidden")))  )luaP_opmodes[op] >> 4) & (int const __attribute__((__visibility__("hidden")))  )3)) == 3) {
#line 340
              if (! (b < (int )pt->sizek)) {
                goto __dyc_dummy_label;
              }
            }
            goto switch_7_break;
            switch_7_2: /* CIL Label */ 
#line 344
            b = (int )((i >> 14) & ~ (4294967295U << 18)) - (((1 << 18) - 1) >> 1);
#line 345
            if ((int )((enum OpArgMask )(((int const __attribute__((__visibility__("hidden")))  )luaP_opmodes[op] >> 4) & (int const __attribute__((__visibility__("hidden")))  )3)) == 2) {
#line 346
              dest = (pc + 1) + b;
#line 347
              if (0 <= dest) {
#line 347
                if (! (dest < (int )pt->sizecode)) {
                  goto __dyc_dummy_label;
                }
              } else {
                goto __dyc_dummy_label;
              }
#line 348
              if (dest > 0) {
#line 354
                j = 0;
                {
#line 354
                while (1) {
                  while_8_continue: /* CIL Label */ ;
#line 354
                  if (! (j < dest)) {
                    goto while_8_break;
                  }
#line 355
                  d = *(pt->code + ((dest - 1) - j));
#line 356
                  if ((int )((enum __anonenum_OpCode_13 )(d & ~ (4294967295U << 6))) == 34) {
#line 356
                    if (! ((int )((d >> 14) & ~ (4294967295U << 9)) == 0)) {
                      goto while_8_break;
                    }
                  } else {
                    goto while_8_break;
                  }
#line 354
                  j ++;
                }
                while_8_break: /* CIL Label */ ;
                }
#line 360
                if (! ((j & 1) == 0)) {
                  goto __dyc_dummy_label;
                }
              }
            }
            goto switch_7_break;
          } else {
            switch_7_break: /* CIL Label */ ;
          }
        }
      }
    }
#line 366
    if ((int const __attribute__((__visibility__("hidden")))  )luaP_opmodes[op] & (int const __attribute__((__visibility__("hidden")))  )(1 << 6)) {
#line 367
      if (a == reg) {
#line 367
        last = pc;
      }
    }
#line 369
    if ((int const __attribute__((__visibility__("hidden")))  )luaP_opmodes[op] & (int const __attribute__((__visibility__("hidden")))  )(1 << 7)) {
#line 370
      if (! (pc + 2 < (int )pt->sizecode)) {
        goto __dyc_dummy_label;
      }
#line 371
      if (! ((int )((enum __anonenum_OpCode_13 )(*(pt->code + (pc + 1)) & ~ (4294967295U << 6))) == 22)) {
        goto __dyc_dummy_label;
      }
    }
#line 374
    if ((int )op == 2) {
      goto switch_9_2;
    } else {
#line 382
      if ((int )op == 3) {
        goto switch_9_3;
      } else {
#line 387
        if ((int )op == 4) {
          goto switch_9_4;
        } else {
#line 388
          if ((int )op == 8) {
            goto switch_9_4;
          } else {
#line 392
            if ((int )op == 5) {
              goto switch_9_5;
            } else {
#line 393
              if ((int )op == 7) {
                goto switch_9_5;
              } else {
#line 397
                if ((int )op == 11) {
                  goto switch_9_11;
                } else {
#line 402
                  if ((int )op == 21) {
                    goto switch_9_21;
                  } else {
#line 406
                    if ((int )op == 33) {
                      goto switch_9_33;
                    } else {
#line 412
                      if ((int )op == 31) {
                        goto switch_9_31;
                      } else {
#line 413
                        if ((int )op == 32) {
                          goto switch_9_31;
                        } else {
#line 416
                          if ((int )op == 22) {
                            goto switch_9_22;
                          } else {
#line 423
                            if ((int )op == 28) {
                              goto switch_9_28;
                            } else {
#line 424
                              if ((int )op == 29) {
                                goto switch_9_28;
                              } else {
#line 437
                                if ((int )op == 30) {
                                  goto switch_9_30;
                                } else {
#line 442
                                  if ((int )op == 34) {
                                    goto switch_9_34;
                                  } else {
#line 450
                                    if ((int )op == 36) {
                                      goto switch_9_36;
                                    } else {
#line 463
                                      if ((int )op == 37) {
                                        goto switch_9_37;
                                      } else {
                                        {
                                        goto switch_9_default;
#line 373
                                        if (0) {
                                          switch_9_2: /* CIL Label */ 
#line 375
                                          if (c == 1) {
#line 376
                                            if (! (pc + 2 < (int )pt->sizecode)) {
                                              goto __dyc_dummy_label;
                                            }
#line 377
                                            if (! ((int )((enum __anonenum_OpCode_13 )(*(pt->code + (pc + 1)) & ~ (4294967295U << 6))) != 34)) {
#line 377
                                              if (! ((int )((*(pt->code + (pc + 1)) >> 14) & ~ (4294967295U << 9)) != 0)) {
                                                goto __dyc_dummy_label;
                                              }
                                            }
                                          }
                                          goto switch_9_break;
                                          switch_9_3: /* CIL Label */ 
#line 383
                                          if (a <= reg) {
#line 383
                                            if (reg <= b) {
#line 384
                                              last = pc;
                                            }
                                          }
                                          goto switch_9_break;
                                          switch_9_4: /* CIL Label */ 
                                          switch_9_8: /* CIL Label */ 
#line 389
                                          if (! (b < (int )pt->nups)) {
                                            goto __dyc_dummy_label;
                                          }
                                          goto switch_9_break;
                                          switch_9_5: /* CIL Label */ 
                                          switch_9_7: /* CIL Label */ 
#line 394
                                          if (! ((pt->k + b)->tt == 4)) {
                                            goto __dyc_dummy_label;
                                          }
                                          goto switch_9_break;
                                          switch_9_11: /* CIL Label */ 
#line 398
                                          if (! (a + 1 < (int )pt->maxstacksize)) {
                                            goto __dyc_dummy_label;
                                          }
#line 399
                                          if (reg == a + 1) {
#line 399
                                            last = pc;
                                          }
                                          goto switch_9_break;
                                          switch_9_21: /* CIL Label */ 
#line 403
                                          if (! (b < c)) {
                                            goto __dyc_dummy_label;
                                          }
                                          goto switch_9_break;
                                          switch_9_33: /* CIL Label */ 
#line 407
                                          if (! (c >= 1)) {
                                            goto __dyc_dummy_label;
                                          }
#line 408
                                          if (! ((a + 2) + c < (int )pt->maxstacksize)) {
                                            goto __dyc_dummy_label;
                                          }
#line 409
                                          if (reg >= a + 2) {
#line 409
                                            last = pc;
                                          }
                                          goto switch_9_break;
                                          switch_9_31: /* CIL Label */ 
                                          switch_9_32: /* CIL Label */ 
#line 414
                                          if (! (a + 3 < (int )pt->maxstacksize)) {
                                            goto __dyc_dummy_label;
                                          }
                                          switch_9_22: /* CIL Label */ 
#line 417
                                          dest___0 = (pc + 1) + b;
#line 419
                                          if (reg != (1 << 8) - 1) {
#line 419
                                            if (pc < dest___0) {
#line 419
                                              if (dest___0 <= lastpc) {
#line 420
                                                pc += b;
                                              }
                                            }
                                          }
                                          goto switch_9_break;
                                          switch_9_28: /* CIL Label */ 
                                          switch_9_29: /* CIL Label */ 
#line 425
                                          if (b != 0) {
#line 426
                                            if (! ((a + b) - 1 < (int )pt->maxstacksize)) {
                                              goto __dyc_dummy_label;
                                            }
                                          }
#line 428
                                          c --;
#line 429
                                          if (c == -1) {
                                            {
#line 430
                                            tmp___2 = __dyc_funcallvar_4;
                                            }
#line 430
                                            if (! tmp___2) {
                                              goto __dyc_dummy_label;
                                            }
                                          } else {
#line 432
                                            if (c != 0) {
#line 433
                                              if (! ((a + c) - 1 < (int )pt->maxstacksize)) {
                                                goto __dyc_dummy_label;
                                              }
                                            }
                                          }
#line 434
                                          if (reg >= a) {
#line 434
                                            last = pc;
                                          }
                                          goto switch_9_break;
                                          switch_9_30: /* CIL Label */ 
#line 438
                                          b --;
#line 439
                                          if (b > 0) {
#line 439
                                            if (! ((a + b) - 1 < (int )pt->maxstacksize)) {
                                              goto __dyc_dummy_label;
                                            }
                                          }
                                          goto switch_9_break;
                                          switch_9_34: /* CIL Label */ 
#line 443
                                          if (b > 0) {
#line 443
                                            if (! (a + b < (int )pt->maxstacksize)) {
                                              goto __dyc_dummy_label;
                                            }
                                          }
#line 444
                                          if (c == 0) {
#line 445
                                            pc ++;
#line 446
                                            if (! (pc < (int )(pt->sizecode - 1))) {
                                              goto __dyc_dummy_label;
                                            }
                                          }
                                          goto switch_9_break;
                                          switch_9_36: /* CIL Label */ 
#line 452
                                          if (! (b < (int )pt->sizep)) {
                                            goto __dyc_dummy_label;
                                          }
#line 453
                                          nup = (int )(*(pt->p + b))->nups;
#line 454
                                          if (! (pc + nup < (int )pt->sizecode)) {
                                            goto __dyc_dummy_label;
                                          }
#line 455
                                          j___0 = 1;
                                          {
#line 455
                                          while (1) {
                                            while_10_continue: /* CIL Label */ ;
#line 455
                                            if (! (j___0 <= nup)) {
                                              goto while_10_break;
                                            }
#line 456
                                            op1 = (enum __anonenum_OpCode_13 )(*(pt->code + (pc + j___0)) & ~ (4294967295U << 6));
#line 457
                                            if (! ((int )op1 == 4)) {
#line 457
                                              if (! ((int )op1 == 0)) {
                                                goto __dyc_dummy_label;
                                              }
                                            }
#line 455
                                            j___0 ++;
                                          }
                                          while_10_break: /* CIL Label */ ;
                                          }
#line 459
                                          if (reg != (1 << 8) - 1) {
#line 460
                                            pc += nup;
                                          }
                                          goto switch_9_break;
                                          switch_9_37: /* CIL Label */ 
#line 464
                                          if ((int const   )pt->is_vararg & 2) {
#line 464
                                            if (! (! ((int const   )pt->is_vararg & 4))) {
                                              goto __dyc_dummy_label;
                                            }
                                          } else {
                                            goto __dyc_dummy_label;
                                          }
#line 466
                                          b --;
#line 467
                                          if (b == -1) {
                                            {
#line 467
                                            tmp___3 = __dyc_funcallvar_5;
                                            }
#line 467
                                            if (! tmp___3) {
                                              goto __dyc_dummy_label;
                                            }
                                          }
#line 468
                                          if (! ((a + b) - 1 < (int )pt->maxstacksize)) {
                                            goto __dyc_dummy_label;
                                          }
                                          goto switch_9_break;
                                          switch_9_default: /* CIL Label */ ;
                                          goto switch_9_break;
                                        } else {
                                          switch_9_break: /* CIL Label */ ;
                                        }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
#line 322
    pc ++;
  }
  while_6_break: /* CIL Label */ ;
  goto __dyc_dummy_label;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(last);
  __dyc_printpre_byte(a);
  __dyc_printpre_byte(b);
  __dyc_printpre_byte(c);
  __dyc_printpre_byte(dest___0);
}
}
