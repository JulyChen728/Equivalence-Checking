#include <dycfoo.h>
#include "../lvm.i.hd.c.h"
void __dyc_foo(void) 
{ LClosure *cl ;
  Instruction const   *pc ;
  int n ;
  Closure *ncl ;
  int nup ;
  int j ;
  UpVal __attribute__((__visibility__("hidden")))  *tmp___47 ;
  UpVal __attribute__((__visibility__("hidden")))  *__dyc_funcallvar_19 ;

  {
  cl = __dyc_read_ptr__typdef_LClosure();
  pc = (Instruction const   *)__dyc_read_ptr__typdef_Instruction();
  n = __dyc_readpre_byte();
  ncl = __dyc_read_ptr__typdef_Closure();
  nup = __dyc_readpre_byte();
  j = __dyc_readpre_byte();
  __dyc_funcallvar_19 = (UpVal __attribute__((__visibility__("hidden")))  *)__dyc_read_ptr__typdef_UpVal();
  tmp___47 = 0;
#line 712
  n --;
  while_16_continue: /* CIL Label */ ;
#line 731
  if (! (j < nup)) {
    goto __dyc_dummy_label;
  }
#line 732
  if ((int )((enum __anonenum_OpCode_36 )(*pc & (unsigned int const   )(~ (4294967295U << 6)))) == 4) {
#line 733
    ncl->l.upvals[j] = cl->upvals[(int )((*pc >> 23) & (unsigned int const   )(~ (4294967295U << 9)))];
  } else {
    {
#line 736
    tmp___47 = __dyc_funcallvar_19;
#line 736
    ncl->l.upvals[j] = (UpVal *)tmp___47;
    }
  }
#line 731
  j ++;
#line 731
  pc ++;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__typdef_Instruction(pc);
  __dyc_printpre_byte(n);
}
}
