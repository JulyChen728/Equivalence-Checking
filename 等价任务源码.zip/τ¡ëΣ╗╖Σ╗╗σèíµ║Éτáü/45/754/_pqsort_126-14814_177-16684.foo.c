#include <dycfoo.h>
#include "../pqsort.i.hd.c.h"
void __dyc_foo(void) 
{ char *pa ;
  char *pb ;
  char *pc ;
  char *pd ;
  char *pm ;
  char *pn ;
  size_t r ;
  int swaptype ;
  int cmp_result ;
  long t___0 ;
  long t___1 ;
  long t___2 ;
  long t___3 ;
  void *_l ;
  void *_r ;
  void *_l___0 ;
  void *_r___0 ;
  void *a ;
  size_t n ;
  size_t es ;
  void *lrange ;
  void *rrange ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;

  {
  pm = __dyc_read_ptr__char();
  swaptype = __dyc_readpre_byte();
  a = __dyc_read_ptr__void();
  n = (size_t )__dyc_readpre_byte();
  es = (size_t )__dyc_readpre_byte();
  lrange = __dyc_read_ptr__void();
  rrange = __dyc_read_ptr__void();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  pa = 0;
  pb = 0;
  pc = 0;
  pd = 0;
  pn = 0;
  r = 0;
  cmp_result = 0;
  t___0 = 0;
  t___1 = 0;
  t___2 = 0;
  t___3 = 0;
  _l = 0;
  _r = 0;
  _l___0 = 0;
  _r___0 = 0;
#line 126
  if (swaptype == 0) {
#line 126
    t___0 = *((long *)a);
#line 126
    *((long *)a) = *((long *)((void *)pm));
#line 126
    *((long *)((void *)pm)) = t___0;
  } else {
    {

    }
  }
#line 127
  pb = (char *)a + es;
#line 127
  pa = pb;
#line 129
  pd = (char *)a + (n - 1UL) * es;
#line 129
  pc = pd;
#line 130
  while (1) {
    while_4_continue: /* CIL Label */ ;
    {
#line 131
    while (1) {
      while_5_continue: /* CIL Label */ ;
#line 131
      if ((unsigned long )pb <= (unsigned long )pc) {
        {
#line 131
        cmp_result = __dyc_funcallvar_6;
        }
#line 131
        if (! (cmp_result <= 0)) {
          goto while_5_break;
        }
      } else {
        goto while_5_break;
      }
#line 132
      if (cmp_result == 0) {
#line 133
        if (swaptype == 0) {
#line 133
          t___1 = *((long *)((void *)pa));
#line 133
          *((long *)((void *)pa)) = *((long *)((void *)pb));
#line 133
          *((long *)((void *)pb)) = t___1;
        } else {
          {

          }
        }
#line 134
        pa += es;
      }
#line 136
      pb += es;
    }
    while_5_break: /* CIL Label */ ;
    }
    {
#line 138
    while (1) {
      while_6_continue: /* CIL Label */ ;
#line 138
      if ((unsigned long )pb <= (unsigned long )pc) {
        {
#line 138
        cmp_result = __dyc_funcallvar_7;
        }
#line 138
        if (! (cmp_result >= 0)) {
          goto while_6_break;
        }
      } else {
        goto while_6_break;
      }
#line 139
      if (cmp_result == 0) {
#line 140
        if (swaptype == 0) {
#line 140
          t___2 = *((long *)((void *)pc));
#line 140
          *((long *)((void *)pc)) = *((long *)((void *)pd));
#line 140
          *((long *)((void *)pd)) = t___2;
        } else {
          {

          }
        }
#line 141
        pd -= es;
      }
#line 143
      pc -= es;
    }
    while_6_break: /* CIL Label */ ;
    }
#line 145
    if ((unsigned long )pb > (unsigned long )pc) {
      goto while_4_break;
    }
#line 147
    if (swaptype == 0) {
#line 147
      t___3 = *((long *)((void *)pb));
#line 147
      *((long *)((void *)pb)) = *((long *)((void *)pc));
#line 147
      *((long *)((void *)pc)) = t___3;
    } else {
      {

      }
    }
#line 148
    pb += es;
#line 149
    pc -= es;
  }
  while_4_break: /* CIL Label */ ;
#line 152
  pn = (char *)a + n * es;
#line 153
  if (pa - (char *)a < pb - pa) {
#line 153
    r = (unsigned long )(pa - (char *)a);
  } else {
#line 153
    r = (unsigned long )(pb - pa);
  }
#line 154
  if (r > 0UL) {
    {

    }
  }
#line 155
  if ((unsigned long )(pd - pc) < (size_t )(pn - pd) - es) {
#line 155
    r = (unsigned long )(pd - pc);
  } else {
#line 155
    r = (size_t )(pn - pd) - es;
  }
#line 156
  if (r > 0UL) {
    {

    }
  }
#line 157
  r = (unsigned long )(pb - pa);
#line 157
  if (r > es) {
#line 158
    _l = a;
#line 158
    _r = (void *)(((unsigned char *)a + r) - 1);
#line 159
    if ((unsigned long )lrange < (unsigned long )_l) {
#line 159
      if (! ((unsigned long )rrange < (unsigned long )_l)) {
        goto _L;
      }
    } else {
      _L: /* CIL Label */ 
#line 159
      if ((unsigned long )lrange > (unsigned long )_r) {
#line 159
        if (! ((unsigned long )rrange > (unsigned long )_r)) {
          {

          }
        }
      } else {
        {

        }
      }
    }
  }
#line 163
  r = (unsigned long )(pd - pc);
#line 163
  if (r > es) {
#line 167
    a = (void *)(pn - r);
#line 168
    n = r / es;
#line 170
    _l___0 = a;
#line 171
    _r___0 = (void *)(((unsigned char *)a + r) - 1);
#line 172
    if ((unsigned long )lrange < (unsigned long )_l___0) {
#line 172
      if (! ((unsigned long )rrange < (unsigned long )_l___0)) {
        goto _L___0;
      }
    } else {
      _L___0: /* CIL Label */ 
#line 172
      if ((unsigned long )lrange > (unsigned long )_r___0) {
#line 172
        if (! ((unsigned long )rrange > (unsigned long )_r___0)) {
          goto __dyc_dummy_label;
        }
      } else {
        goto __dyc_dummy_label;
      }
    }
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__void(_r);
  __dyc_print_ptr__void(_r___0);
  __dyc_printpre_byte(n);
}
}
