#include <dycfoo.h>
#include "../liolib.i.hd.c.h"
void __dyc_foo(void) 
{ int nargs ;
  int tmp ;
  int status ;
  lua_Number tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  size_t l ;
  char const   *s ;
  char const   *tmp___3 ;
  size_t tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int arg ;
  int __dyc_funcallvar_2 ;
  lua_Number __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  char const   *__dyc_funcallvar_5 ;
  size_t __dyc_funcallvar_6 ;

  {
  tmp = __dyc_readpre_byte();
  l = (size_t )__dyc_readpre_byte();
  arg = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = (lua_Number )__dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_6 = (size_t )__dyc_readpre_byte();
  nargs = 0;
  status = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  s = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
#line 414
  nargs = tmp - 1;
#line 415
  status = 1;
#line 416
  while (1) {
    while_4_continue: /* CIL Label */ ;
#line 416
    tmp___7 = nargs;
#line 416
    nargs --;
#line 416
    if (! tmp___7) {
      goto __dyc_dummy_label;
    }
    {
#line 417
    tmp___6 = __dyc_funcallvar_2;
    }
#line 417
    if (tmp___6 == 3) {
#line 419
      if (status) {
        {
#line 419
        tmp___0 = __dyc_funcallvar_3;
#line 419
        tmp___1 = __dyc_funcallvar_4;
        }
#line 419
        if (tmp___1 > 0) {
#line 419
          tmp___2 = 1;
        } else {
#line 419
          tmp___2 = 0;
        }
      } else {
#line 419
        tmp___2 = 0;
      }
#line 419
      status = tmp___2;
    } else {
      {
#line 424
      tmp___3 = __dyc_funcallvar_5;
#line 424
      s = tmp___3;
      }
#line 425
      if (status) {
        {
#line 425
        tmp___4 = __dyc_funcallvar_6;
        }
#line 425
        if (tmp___4 == l) {
#line 425
          tmp___5 = 1;
        } else {
#line 425
          tmp___5 = 0;
        }
      } else {
#line 425
        tmp___5 = 0;
      }
#line 425
      status = tmp___5;
    }
#line 416
    arg ++;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(nargs);
  __dyc_printpre_byte(status);
  __dyc_printpre_byte(tmp___0);
  __dyc_print_ptr__char(s);
  __dyc_printpre_byte(arg);
}
}
