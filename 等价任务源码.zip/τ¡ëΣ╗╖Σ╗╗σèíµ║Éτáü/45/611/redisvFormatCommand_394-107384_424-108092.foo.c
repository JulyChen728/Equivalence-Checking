#include <dycfoo.h>
#include "../hiredis.i.hd.c.h"
void __dyc_foo(void) 
{ char *cmd ;
  int pos ;
  sds curarg ;
  int argc ;
  int totlen ;
  int error_type ;
  int j ;
  uint32_t tmp___29 ;
  void *tmp___30 ;
  size_t tmp___31 ;
  int tmp___32 ;
  size_t tmp___33 ;
  size_t tmp___34 ;
  int tmp___35 ;
  int tmp___36 ;
  char **target ;
  uint32_t __dyc_funcallvar_24 ;
  void *__dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;
  size_t __dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  size_t __dyc_funcallvar_29 ;
  size_t __dyc_funcallvar_30 ;

  {
  argc = __dyc_readpre_byte();
  totlen = __dyc_readpre_byte();
  target = __dyc_read_ptr__ptr__char();
  __dyc_funcallvar_24 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_read_ptr__void();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  __dyc_funcallvar_27 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_30 = (size_t )__dyc_readpre_byte();
  cmd = 0;
  pos = 0;
  curarg = 0;
  error_type = 0;
  j = 0;
  tmp___29 = 0;
  tmp___30 = 0;
  tmp___31 = 0;
  tmp___32 = 0;
  tmp___33 = 0;
  tmp___34 = 0;
  tmp___35 = 0;
  tmp___36 = 0;
#line 394
  curarg = (char *)((void *)0);
#line 397
  tmp___29 = __dyc_funcallvar_24;
#line 397
  totlen = (int )((uint32_t )totlen + ((1U + tmp___29) + 2U));
#line 400
  tmp___30 = __dyc_funcallvar_25;
#line 400
  cmd = (char *)tmp___30;
#line 401
  if ((unsigned long )cmd == (unsigned long )((void *)0)) {
    goto memory_err;
  }
#line 403
  pos = __dyc_funcallvar_26;
#line 404
  j = 0;
#line 404
  while (1) {
    while_9_continue: /* CIL Label */ ;
#line 404
    if (! (j < argc)) {
      goto while_9_break;
    }
    {
#line 405
    tmp___31 = __dyc_funcallvar_27;
#line 405
    tmp___32 = __dyc_funcallvar_28;
#line 405
    pos += tmp___32;
#line 406
    tmp___33 = __dyc_funcallvar_29;

#line 407
    tmp___34 = __dyc_funcallvar_30;
#line 407
    pos = (int )((size_t )pos + tmp___34);

#line 409
    tmp___35 = pos;
#line 409
    pos ++;
#line 409
    *(cmd + tmp___35) = (char )'\r';
#line 410
    tmp___36 = pos;
#line 410
    pos ++;
#line 410
    *(cmd + tmp___36) = (char )'\n';
#line 404
    j ++;
    }
  }
  while_9_break: /* CIL Label */ ;
#line 412
  if (! (pos == totlen)) {
    {

    }
  }
#line 413
  *(cmd + pos) = (char )'\000';

#line 416
  *target = cmd;
  goto __dyc_dummy_label;
  format_err: 
#line 420
  error_type = -2;
  goto __dyc_dummy_label;
  memory_err: 
#line 424
  error_type = -1;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__char(curarg);
  __dyc_printpre_byte(totlen);
  __dyc_printpre_byte(error_type);
  __dyc_printpre_byte(tmp___31);
  __dyc_printpre_byte(tmp___33);
}
}
