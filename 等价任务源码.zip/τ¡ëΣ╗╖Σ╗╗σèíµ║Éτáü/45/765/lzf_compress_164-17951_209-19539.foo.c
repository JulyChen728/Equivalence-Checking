#include <dycfoo.h>
#include "../lzf_c.i.hd.c.h"
void __dyc_foo(void) 
{ u8 const   *ip ;
  u8 *op ;
  u8 const   *in_end ;
  u8 *out_end ;
  u8 const   *ref ;
  unsigned long off ;
  int lit ;
  unsigned int len ;
  unsigned int maxlen ;
  long tmp ;
  long tmp___0 ;
  u8 *tmp___1 ;
  u8 *tmp___2 ;
  u8 *tmp___3 ;
  long __dyc_funcallvar_1 ;
  long __dyc_funcallvar_2 ;

  {
  ip = (u8 const   *)__dyc_read_ptr__typdef_u8();
  op = __dyc_read_ptr__typdef_u8();
  in_end = (u8 const   *)__dyc_read_ptr__typdef_u8();
  out_end = __dyc_read_ptr__typdef_u8();
  ref = (u8 const   *)__dyc_read_ptr__typdef_u8();
  off = (unsigned long )__dyc_readpre_byte();
  lit = __dyc_readpre_byte();
  __dyc_funcallvar_1 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_2 = (long )__dyc_readpre_byte();
  len = 0;
  maxlen = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
#line 163
  len = 2U;
#line 164
  maxlen = (unsigned int )(in_end - ip) - len;
#line 165
  if (maxlen > (unsigned int )((1 << 8) + (1 << 3))) {
#line 165
    maxlen = (unsigned int )((1 << 8) + (1 << 3));
  } else {
#line 165
    maxlen = maxlen;
  }
#line 167
  tmp = __dyc_funcallvar_1;
#line 167
  if (tmp) {
#line 168
    if ((unsigned long )(((op - ! lit) + 3) + 1) >= (unsigned long )out_end) {
      goto __dyc_dummy_label;
    }
  }
#line 171
  *(op + (- lit - 1)) = (unsigned char )(lit - 1);
#line 172
  op -= ! lit;
#line 174
  while (1) {
    while_1_continue: /* CIL Label */ ;
    {
#line 176
    tmp___0 = __dyc_funcallvar_2;
    }
#line 176
    if (tmp___0) {
#line 178
      len ++;
#line 178
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 179
      len ++;
#line 179
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 180
      len ++;
#line 180
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 181
      len ++;
#line 181
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 183
      len ++;
#line 183
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 184
      len ++;
#line 184
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 185
      len ++;
#line 185
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 186
      len ++;
#line 186
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 188
      len ++;
#line 188
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 189
      len ++;
#line 189
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 190
      len ++;
#line 190
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 191
      len ++;
#line 191
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 193
      len ++;
#line 193
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 194
      len ++;
#line 194
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 195
      len ++;
#line 195
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
#line 196
      len ++;
#line 196
      if ((int const   )*(ref + len) != (int const   )*(ip + len)) {
        goto while_1_break;
      }
    }
    {
#line 199
    while (1) {
      while_2_continue: /* CIL Label */ ;
#line 200
      len ++;
#line 199
      if (len < maxlen) {
#line 199
        if (! ((int const   )*(ref + len) == (int const   )*(ip + len))) {
          goto while_2_break;
        }
      } else {
        goto while_2_break;
      }
    }
    while_2_break: /* CIL Label */ ;
    }
    goto while_1_break;
  }
  while_1_break: /* CIL Label */ ;
#line 206
  len -= 2U;
#line 207
  ip ++;
#line 209
  if (len < 7U) {
#line 211
    tmp___1 = op;
#line 211
    op ++;
#line 211
    *tmp___1 = (unsigned char )((off >> 8) + (unsigned long )(len << 5));
  } else {
#line 215
    tmp___2 = op;
#line 215
    op ++;
#line 215
    *tmp___2 = (unsigned char )((off >> 8) + (unsigned long )(7 << 5));
#line 216
    tmp___3 = op;
#line 216
    op ++;
#line 216
    *tmp___3 = (unsigned char )(len - 7U);
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__typdef_u8(ip);
  __dyc_print_ptr__typdef_u8(op);
  __dyc_printpre_byte(maxlen);
}
}
