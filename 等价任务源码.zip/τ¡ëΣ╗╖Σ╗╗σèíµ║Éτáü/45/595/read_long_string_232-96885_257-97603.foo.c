#include <dycfoo.h>
#include "../llex.i.hd.c.h"
void __dyc_foo(void) 
{ int cont ;
  char const   *tmp___5 ;
  char const   *tmp___9 ;
  int __attribute__((__visibility__("hidden")))  tmp___10 ;
  size_t tmp___11 ;
  int tmp___12 ;
  char const   *tmp___16 ;
  int __attribute__((__visibility__("hidden")))  tmp___17 ;
  size_t tmp___18 ;
  int tmp___19 ;
  LexState *ls ;
  SemInfo *seminfo ;
  int sep ;
  int __dyc_funcallvar_2 ;
  int __attribute__((__visibility__("hidden")))  __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __attribute__((__visibility__("hidden")))  __dyc_funcallvar_5 ;

  {
  cont = __dyc_readpre_byte();
  ls = __dyc_read_ptr__typdef_LexState();
  seminfo = __dyc_read_ptr__typdef_SemInfo();
  sep = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = (int __attribute__((__visibility__("hidden")))  )__dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = (int __attribute__((__visibility__("hidden")))  )__dyc_readpre_byte();
  tmp___5 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  tmp___16 = 0;
  tmp___17 = 0;
  tmp___18 = 0;
  tmp___19 = 0;
  switch_7_neg_1: /* CIL Label */ 
#line 232
  if (seminfo) {
#line 232
    tmp___5 = "unfinished long string";
  } else {
#line 232
    tmp___5 = "unfinished long comment";
  }

  goto __dyc_dummy_label;
#line 237
  tmp___12 = __dyc_funcallvar_2;
#line 237
  if (tmp___12 == sep) {
    {

#line 238
    tmp___11 = (ls->z)->n;
#line 238
    ((ls->z)->n) --;
    }
#line 238
    if (tmp___11 > 0UL) {
#line 238
      tmp___9 = (ls->z)->p;
#line 238
      ((ls->z)->p) ++;
#line 238
      ls->current = (int )((unsigned char )*tmp___9);
    } else {
      {
#line 238
      tmp___10 = __dyc_funcallvar_3;
#line 238
      ls->current = (int )tmp___10;
      }
    }
#line 239
    cont ++;
#line 241
    if (sep == 0) {
      {

      }
    }
  }
  goto __dyc_dummy_label;
#line 249
  tmp___19 = __dyc_funcallvar_4;
#line 249
  if (tmp___19 == sep) {
    {

#line 250
    tmp___18 = (ls->z)->n;
#line 250
    ((ls->z)->n) --;
    }
#line 250
    if (tmp___18 > 0UL) {
#line 250
      tmp___16 = (ls->z)->p;
#line 250
      ((ls->z)->p) ++;
#line 250
      ls->current = (int )((unsigned char )*tmp___16);
    } else {
      {
#line 250
      tmp___17 = __dyc_funcallvar_5;
#line 250
      ls->current = (int )tmp___17;
      }
    }
    goto __dyc_dummy_label;
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(cont);
  __dyc_print_ptr__char(tmp___5);
}
}
