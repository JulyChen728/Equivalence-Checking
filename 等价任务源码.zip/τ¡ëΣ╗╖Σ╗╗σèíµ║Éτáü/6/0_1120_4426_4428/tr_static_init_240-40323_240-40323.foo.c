#include <dycfoo.h>
#include "../deftree.i.hd.c.h"
void __dyc_foo(void) 
{ int const   extra_lbits[29] ;
  uch length_code[256] ;
  int base_length[29] ;
  int n ;
  int length ;
  int code ;
  int tmp ;

  {
  length = __dyc_readpre_byte();
  code = __dyc_readpre_byte();
  n = 0;
  tmp = 0;
#line 240
  if (! (code < 28)) {
    goto __dyc_dummy_label;
  }
#line 241
  base_length[code] = length;
#line 242
  n = 0;
#line 242
  while (1) {
    while_2_continue: /* CIL Label */ ;
#line 242
    if (! (n < 1 << extra_lbits[code])) {
      goto while_2_break;
    }
#line 243
    tmp = length;
#line 243
    length ++;
#line 243
    length_code[tmp] = (unsigned char )code;
#line 242
    n ++;
  }
  while_2_break: /* CIL Label */ ;
#line 240
  code ++;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(length);
  __dyc_printpre_byte(code);
}
}
