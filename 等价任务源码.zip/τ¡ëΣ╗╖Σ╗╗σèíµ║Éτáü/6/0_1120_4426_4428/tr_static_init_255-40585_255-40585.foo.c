#include <dycfoo.h>
#include "../deftree.i.hd.c.h"
void __dyc_foo(void) 
{ int const   extra_dbits[30] ;
  uch dist_code[512] ;
  int base_dist[30] ;
  int n ;
  int code ;
  int dist ;
  int tmp___0 ;

  {
  code = __dyc_readpre_byte();
  dist = __dyc_readpre_byte();
  n = 0;
  tmp___0 = 0;
#line 255
  if (! (code < 16)) {
    goto __dyc_dummy_label;
  }
#line 256
  base_dist[code] = dist;
#line 257
  n = 0;
#line 257
  while (1) {
    while_4_continue: /* CIL Label */ ;
#line 257
    if (! (n < 1 << extra_dbits[code])) {
      goto while_4_break;
    }
#line 258
    tmp___0 = dist;
#line 258
    dist ++;
#line 258
    dist_code[tmp___0] = (unsigned char )code;
#line 257
    n ++;
  }
  while_4_break: /* CIL Label */ ;
#line 255
  code ++;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(code);
  __dyc_printpre_byte(dist);
}
}
