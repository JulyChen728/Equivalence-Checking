#include <dycfoo.h>
#include "../deftree.i.hd.c.h"
void __dyc_foo(void) 
{ int const   extra_dbits[30] ;
  uch dist_code[512] ;
  int base_dist[30] ;
  int n ;
  int code ;
  int dist ;
  int tmp___1 ;

  {
  code = __dyc_readpre_byte();
  dist = __dyc_readpre_byte();
  n = 0;
  tmp___1 = 0;
#line 263
  if (! (code < 30)) {
    goto __dyc_dummy_label;
  }
#line 264
  base_dist[code] = dist << 7;
#line 265
  n = 0;
#line 265
  while (1) {
    while_6_continue: /* CIL Label */ ;
#line 265
    if (! (n < 1 << (extra_dbits[code] - 7))) {
      goto while_6_break;
    }
#line 266
    tmp___1 = dist;
#line 266
    dist ++;
#line 266
    dist_code[256 + tmp___1] = (unsigned char )code;
#line 265
    n ++;
  }
  while_6_break: /* CIL Label */ ;
#line 263
  code ++;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(code);
  __dyc_printpre_byte(dist);
}
}
