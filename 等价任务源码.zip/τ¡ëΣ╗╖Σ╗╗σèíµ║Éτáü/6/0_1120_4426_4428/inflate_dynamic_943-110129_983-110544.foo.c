#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ int dbits ;
  int i ;
  int bd ;
  int ret ;
  int tmp___39 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;

  {
  dbits = (int const   )__dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  i = 0;
  bd = 0;
  ret = 0;
  tmp___39 = 0;
#line 943
  bd = (int )dbits;
#line 944
  i = __dyc_funcallvar_12;
#line 944
  if (i != 0) {
#line 947
    if (i == 1) {
      {


      }
    }
    {

#line 956
    ret = i;
    }
    goto __dyc_dummy_label;
  }
#line 964
  tmp___39 = __dyc_funcallvar_13;
#line 964
  if (tmp___39) {
#line 965
    ret = 1;
    goto __dyc_dummy_label;
  }


#line 976
  ret = 0;

  goto __dyc_dummy_label;
  underrun: 
#line 982
  ret = 4;
  goto __dyc_dummy_label;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(bd);
  __dyc_printpre_byte(ret);
}
}
