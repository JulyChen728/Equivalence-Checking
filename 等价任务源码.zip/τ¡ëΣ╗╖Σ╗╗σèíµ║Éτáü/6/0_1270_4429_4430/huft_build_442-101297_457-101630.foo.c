#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned int hufts ;
  int h ;
  unsigned int j ;
  struct huft *q ;
  unsigned int z ;
  struct huft **u ;
  int ret ;
  void *tmp___4 ;
  struct huft **t ;
  void *__dyc_funcallvar_2 ;

  {
  hufts = (unsigned int )__dyc_readpre_byte();
  h = __dyc_readpre_byte();
  j = (unsigned int )__dyc_readpre_byte();
  u = __dyc_read_ptr__ptr__comp_59huft();
  t = __dyc_read_ptr__ptr__comp_59huft();
  __dyc_funcallvar_2 = __dyc_read_ptr__void();
  q = 0;
  z = 0;
  ret = 0;
  tmp___4 = 0;
#line 442
  z = (unsigned int )(1 << j);
#line 445
  tmp___4 = __dyc_funcallvar_2;
#line 445
  q = (struct huft *)tmp___4;
#line 445
  if ((unsigned long )q == (unsigned long )((struct huft *)((void *)0))) {
#line 448
    if (h) {
      {

      }
    }
#line 450
    ret = 3;
    goto __dyc_dummy_label;
  }
#line 454
  hufts += z + 1U;
#line 455
  *t = q + 1;
#line 456
  t = & q->v.t;
#line 456
  *t = (struct huft *)((void *)0);
#line 457
  q ++;
#line 457
  *(u + h) = q;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(hufts);
  __dyc_printpre_byte(z);
  __dyc_printpre_byte(ret);
}
}
