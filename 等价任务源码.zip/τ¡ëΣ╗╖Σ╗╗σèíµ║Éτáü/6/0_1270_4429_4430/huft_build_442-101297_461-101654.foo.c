#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned int hufts ;
  int h ;
  unsigned int i ;
  unsigned int j ;
  int l ;
  struct huft *q ;
  struct huft r ;
  int w ;
  unsigned int z ;
  unsigned int *x ;
  struct huft **u ;
  int ret ;
  void *tmp___4 ;
  struct huft **t ;
  void *__dyc_funcallvar_2 ;

  {
  hufts = (unsigned int )__dyc_readpre_byte();
  h = __dyc_readpre_byte();
  i = (unsigned int )__dyc_readpre_byte();
  j = (unsigned int )__dyc_readpre_byte();
  l = __dyc_readpre_byte();
  w = __dyc_readpre_byte();
  x = __dyc_read_ptr__int();
  u = __dyc_read_ptr__ptr__comp_59huft();
  t = __dyc_read_ptr__ptr__comp_59huft();
  __dyc_funcallvar_2 = __dyc_read_ptr__void();
  q = 0;
  memset(& r, 0, sizeof(struct huft ));
  z = 0;
  ret = 0;
  tmp___4 = 0;
#line 442
  z = (unsigned int )(1 << j);
#line 445
  tmp___4 = __dyc_funcallvar_2;
#line 445
  q = (struct huft *)tmp___4;
#line 445
  if ((unsigned long )q == (unsigned long )((struct huft *)((void *)0))) {
#line 448
    if (h) {
      {

      }
    }
#line 450
    ret = 3;
    goto __dyc_dummy_label;
  }
#line 454
  hufts += z + 1U;
#line 455
  *t = q + 1;
#line 456
  t = & q->v.t;
#line 456
  *t = (struct huft *)((void *)0);
#line 457
  q ++;
#line 457
  *(u + h) = q;
#line 461
  if (h) {
#line 463
    *(x + h) = i;
#line 464
    r.b = (unsigned char )l;
#line 465
    r.e = (unsigned char )(16U + j);
#line 466
    r.v.t = q;
#line 467
    j = i >> (w - l);
#line 468
    *(*(u + (h - 1)) + j) = r;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(hufts);
  __dyc_printpre_byte(z);
  __dyc_printpre_byte(ret);
}
}
