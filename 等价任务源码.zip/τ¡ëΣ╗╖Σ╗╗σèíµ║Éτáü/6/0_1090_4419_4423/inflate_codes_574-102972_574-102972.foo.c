#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ uch *inbuf ;
  unsigned int insize ;
  unsigned int inptr ;
  ulg b ;
  unsigned int k ;
  int v ;
  int tmp___1 ;
  unsigned int tmp___2 ;
  int bl ;
  int __dyc_funcallvar_1 ;

  {
  inbuf = __dyc_read_ptr__typdef_uch();
  insize = (unsigned int )__dyc_readpre_byte();
  inptr = (unsigned int )__dyc_readpre_byte();
  b = (ulg )__dyc_readpre_byte();
  k = (unsigned int )__dyc_readpre_byte();
  bl = __dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  v = 0;
  tmp___1 = 0;
  tmp___2 = 0;
#line 574
  while (1) {
    while_15_continue: /* CIL Label */ ;
#line 574
    if (! (k < (unsigned int )bl)) {
      goto __dyc_dummy_label;
    }
#line 574
    if (inptr < insize) {
#line 574
      tmp___2 = inptr;
#line 574
      inptr ++;
#line 574
      tmp___1 = (int )*(inbuf + tmp___2);
    } else {
      {
#line 574
      tmp___1 = __dyc_funcallvar_1;
      }
    }
#line 574
    v = tmp___1;
#line 574
    if (v < 0) {
      goto __dyc_dummy_label;
    }
#line 574
    b |= (unsigned long )((unsigned char )v) << k;
#line 574
    k += 8U;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(inptr);
  __dyc_printpre_byte(b);
}
}
