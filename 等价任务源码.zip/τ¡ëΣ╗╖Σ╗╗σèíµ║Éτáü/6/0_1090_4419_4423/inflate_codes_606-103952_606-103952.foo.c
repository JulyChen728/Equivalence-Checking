#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ uch *inbuf ;
  unsigned int insize ;
  unsigned int inptr ;
  ulg b ;
  unsigned int k ;
  int v___2 ;
  int tmp___14 ;
  unsigned int tmp___15 ;
  int bd ;
  int __dyc_funcallvar_4 ;

  {
  inbuf = __dyc_read_ptr__typdef_uch();
  insize = (unsigned int )__dyc_readpre_byte();
  inptr = (unsigned int )__dyc_readpre_byte();
  b = (ulg )__dyc_readpre_byte();
  k = (unsigned int )__dyc_readpre_byte();
  bd = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  v___2 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
#line 606
  while (1) {
    while_19_continue: /* CIL Label */ ;
#line 606
    if (! (k < (unsigned int )bd)) {
      goto __dyc_dummy_label;
    }
#line 606
    if (inptr < insize) {
#line 606
      tmp___15 = inptr;
#line 606
      inptr ++;
#line 606
      tmp___14 = (int )*(inbuf + tmp___15);
    } else {
      {
#line 606
      tmp___14 = __dyc_funcallvar_4;
      }
    }
#line 606
    v___2 = tmp___14;
#line 606
    if (v___2 < 0) {
      goto __dyc_dummy_label;
    }
#line 606
    b |= (unsigned long )((unsigned char )v___2) << k;
#line 606
    k += 8U;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(inptr);
  __dyc_printpre_byte(b);
}
}
