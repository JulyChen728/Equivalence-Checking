#include <dycfoo.h>
#include "../printf.i.hd.c.h"
void __dyc_foo(void) 
{ char tmp[66] ;
  char const   *digits ;
  int i ;
  int tmp___0 ;
  int tmp___1 ;
  int __res ;
  long num ;
  int base ;

  {
  digits = (char const   *)__dyc_read_ptr__char();
  num = (long )__dyc_readpre_byte();
  base = __dyc_readpre_byte();
  i = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  __res = 0;
#line 79
  i = 0;
#line 80
  if (num == 0L) {
#line 81
    tmp___0 = i;
#line 81
    i ++;
#line 81
    tmp[tmp___0] = (char )'0';
  } else {
    {
#line 83
    while (1) {
      while_1_continue: /* CIL Label */ ;
#line 83
      if (! (num != 0L)) {
        goto while_1_break;
      }
#line 84
      tmp___1 = i;
#line 84
      i ++;
#line 84
      __res = (int )((unsigned long )num % (unsigned long )((unsigned int )base));
#line 84
      num = (long )((unsigned long )num / (unsigned long )((unsigned int )base));
#line 84
      tmp[tmp___1] = (char )*(digits + __res);
    }
    while_1_break: /* CIL Label */ ;
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(i);
}
}
