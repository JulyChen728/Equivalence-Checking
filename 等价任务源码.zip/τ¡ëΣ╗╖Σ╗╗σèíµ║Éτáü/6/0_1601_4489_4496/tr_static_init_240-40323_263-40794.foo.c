#include <dycfoo.h>
#include "../deftree.i.hd.c.h"
void __dyc_foo(void) 
{ int const   extra_lbits[29] ;
  int const   extra_dbits[30] ;
  uch dist_code[512] ;
  uch length_code[256] ;
  int base_length[29] ;
  int base_dist[30] ;
  int n ;
  int length ;
  int code ;
  int dist ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  length = __dyc_readpre_byte();
  code = __dyc_readpre_byte();
  n = 0;
  dist = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
#line 240
  while (1) {
    while_1_continue: /* CIL Label */ ;
#line 240
    if (! (code < 28)) {
      goto while_1_break;
    }
#line 241
    base_length[code] = length;
#line 242
    n = 0;
    {
#line 242
    while (1) {
      while_2_continue: /* CIL Label */ ;
#line 242
      if (! (n < 1 << extra_lbits[code])) {
        goto while_2_break;
      }
#line 243
      tmp = length;
#line 243
      length ++;
#line 243
      length_code[tmp] = (unsigned char )code;
#line 242
      n ++;
    }
    while_2_break: /* CIL Label */ ;
    }
#line 240
    code ++;
  }
  while_1_break: /* CIL Label */ ;
#line 251
  length_code[length - 1] = (unsigned char )code;
#line 254
  dist = 0;
#line 255
  code = 0;
#line 255
  while (1) {
    while_3_continue: /* CIL Label */ ;
#line 255
    if (! (code < 16)) {
      goto while_3_break;
    }
#line 256
    base_dist[code] = dist;
#line 257
    n = 0;
    {
#line 257
    while (1) {
      while_4_continue: /* CIL Label */ ;
#line 257
      if (! (n < 1 << extra_dbits[code])) {
        goto while_4_break;
      }
#line 258
      tmp___0 = dist;
#line 258
      dist ++;
#line 258
      dist_code[tmp___0] = (unsigned char )code;
#line 257
      n ++;
    }
    while_4_break: /* CIL Label */ ;
    }
#line 255
    code ++;
  }
  while_3_break: /* CIL Label */ ;
#line 262
  dist >>= 7;
#line 263
  while (1) {
    while_5_continue: /* CIL Label */ ;
#line 263
    if (! (code < 30)) {
      goto __dyc_dummy_label;
    }
#line 264
    base_dist[code] = dist << 7;
#line 265
    n = 0;
    {
#line 265
    while (1) {
      while_6_continue: /* CIL Label */ ;
#line 265
      if (! (n < 1 << (extra_dbits[code] - 7))) {
        goto while_6_break;
      }
#line 266
      tmp___1 = dist;
#line 266
      dist ++;
#line 266
      dist_code[256 + tmp___1] = (unsigned char )code;
#line 265
      n ++;
    }
    while_6_break: /* CIL Label */ ;
    }
#line 263
    code ++;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(dist);
}
}
