#include <dycfoo.h>
#include "../cmdline.i.hd.c.h"
void __dyc_foo(void) 
{ struct boot_params boot_params ;
  u32 cmdline_ptr ;
  addr_t cptr ;
  char c ;
  int len ;
  char const   *opptr ;
  char *bufptr ;
  enum __anonenum_state_22 state ;
  int tmp ;
  char const   *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  char *tmp___3 ;
  int tmp___4 ;
  addr_t tmp___5 ;
  u8 tmp___6 ;
  char const   *option ;
  char *buffer ;
  int bufsize ;
  u8 __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;

  {
  boot_params = __dyc_read_comp_35boot_params();
  option = (char const   *)__dyc_read_ptr__char();
  buffer = __dyc_read_ptr__char();
  bufsize = __dyc_readpre_byte();
  __dyc_funcallvar_1 = (u8 )__dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  cmdline_ptr = 0;
  cptr = 0;
  c = 0;
  len = 0;
  opptr = 0;
  bufptr = 0;
  state = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
#line 34
  cmdline_ptr = boot_params.hdr.cmd_line_ptr;
#line 37
  len = -1;
#line 38
  opptr = (char const   *)((void *)0);
#line 39
  bufptr = buffer;
#line 40
  state = 0;
#line 47
  if (! cmdline_ptr) {
    goto __dyc_dummy_label;
  } else {
#line 47
    if (cmdline_ptr >= 1048576U) {
      goto __dyc_dummy_label;
    }
  }
#line 50
  cptr = cmdline_ptr & 15U;

#line 53
  while (1) {
    while_0_continue: /* CIL Label */ ;
#line 53
    if (cptr < 65536U) {
      {
#line 53
      tmp___5 = cptr;
#line 53
      cptr ++;
#line 53
      tmp___6 = __dyc_funcallvar_1;
#line 53
      c = (char )tmp___6;
      }
#line 53
      if (! c) {
        goto __dyc_dummy_label;
      }
    } else {
      goto __dyc_dummy_label;
    }
#line 55
    if ((int )state == 0) {
      goto switch_1_0;
    } else {
#line 64
      if ((int )state == 1) {
        goto switch_1_1;
      } else {
#line 76
        if ((int )state == 2) {
          goto switch_1_2;
        } else {
#line 81
          if ((int )state == 3) {
            goto switch_1_3;
          } else {
#line 54
            if (0) {
              switch_1_0: /* CIL Label */ 
              {
#line 56
              tmp = __dyc_funcallvar_2;
              }
#line 56
              if (tmp) {
                goto switch_1_break;
              }
#line 60
              state = 1;
#line 61
              opptr = option;
              switch_1_1: /* CIL Label */ 
#line 65
              if ((int )c == 61) {
#line 65
                if (! *opptr) {
#line 66
                  len = 0;
#line 67
                  bufptr = buffer;
#line 68
                  state = 3;
                } else {
                  goto _L;
                }
              } else {
                _L: /* CIL Label */ 
                {
#line 69
                tmp___1 = __dyc_funcallvar_3;
                }
#line 69
                if (tmp___1) {
#line 70
                  state = 0;
                } else {
#line 71
                  tmp___0 = opptr;
#line 71
                  opptr ++;
#line 71
                  if ((int )c != (int )*tmp___0) {
#line 72
                    state = 2;
                  }
                }
              }
              goto switch_1_break;
              switch_1_2: /* CIL Label */ 
              {
#line 77
              tmp___2 = __dyc_funcallvar_4;
              }
#line 77
              if (tmp___2) {
#line 78
                state = 0;
              }
              goto switch_1_break;
              switch_1_3: /* CIL Label */ 
              {
#line 82
              tmp___4 = __dyc_funcallvar_5;
              }
#line 82
              if (tmp___4) {
#line 83
                state = 0;
              } else {
#line 85
                if (len < bufsize - 1) {
#line 86
                  tmp___3 = bufptr;
#line 86
                  bufptr ++;
#line 86
                  *tmp___3 = c;
                }
#line 87
                len ++;
              }
              goto switch_1_break;
            } else {
              switch_1_break: /* CIL Label */ ;
            }
          }
        }
      }
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(cptr);
  __dyc_printpre_byte(len);
  __dyc_print_ptr__char(opptr);
  __dyc_print_ptr__char(bufptr);
  __dyc_printpre_byte(state);
  __dyc_printpre_byte(tmp___5);
}
}
