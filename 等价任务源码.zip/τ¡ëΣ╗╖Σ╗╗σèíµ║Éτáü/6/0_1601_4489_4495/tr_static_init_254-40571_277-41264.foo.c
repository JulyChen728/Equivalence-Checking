#include <dycfoo.h>
#include "../deftree.i.hd.c.h"
void __dyc_foo(void) 
{ int const   extra_dbits[30] ;
  ct_data static_ltree[288] ;
  uch dist_code[512] ;
  uch length_code[256] ;
  int base_dist[30] ;
  int n ;
  int bits ;
  int length ;
  int code ;
  int dist ;
  ush bl_count[16] ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;

  {
  length = __dyc_readpre_byte();
  code = __dyc_readpre_byte();
  n = 0;
  bits = 0;
  dist = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
#line 251
  length_code[length - 1] = (unsigned char )code;
#line 254
  dist = 0;
#line 255
  code = 0;
#line 255
  while (1) {
    while_3_continue: /* CIL Label */ ;
#line 255
    if (! (code < 16)) {
      goto while_3_break;
    }
#line 256
    base_dist[code] = dist;
#line 257
    n = 0;
    {
#line 257
    while (1) {
      while_4_continue: /* CIL Label */ ;
#line 257
      if (! (n < 1 << extra_dbits[code])) {
        goto while_4_break;
      }
#line 258
      tmp___0 = dist;
#line 258
      dist ++;
#line 258
      dist_code[tmp___0] = (unsigned char )code;
#line 257
      n ++;
    }
    while_4_break: /* CIL Label */ ;
    }
#line 255
    code ++;
  }
  while_3_break: /* CIL Label */ ;
#line 262
  dist >>= 7;
#line 263
  while (1) {
    while_5_continue: /* CIL Label */ ;
#line 263
    if (! (code < 30)) {
      goto while_5_break;
    }
#line 264
    base_dist[code] = dist << 7;
#line 265
    n = 0;
    {
#line 265
    while (1) {
      while_6_continue: /* CIL Label */ ;
#line 265
      if (! (n < 1 << (extra_dbits[code] - 7))) {
        goto while_6_break;
      }
#line 266
      tmp___1 = dist;
#line 266
      dist ++;
#line 266
      dist_code[256 + tmp___1] = (unsigned char )code;
#line 265
      n ++;
    }
    while_6_break: /* CIL Label */ ;
    }
#line 263
    code ++;
  }
  while_5_break: /* CIL Label */ ;
#line 272
  bits = 0;
#line 272
  while (1) {
    while_7_continue: /* CIL Label */ ;
#line 272
    if (! (bits <= 15)) {
      goto while_7_break;
    }
#line 272
    bl_count[bits] = (unsigned short)0;
#line 272
    bits ++;
  }
  while_7_break: /* CIL Label */ ;
#line 273
  n = 0;
#line 274
  while (1) {
    while_8_continue: /* CIL Label */ ;
#line 274
    if (! (n <= 143)) {
      goto while_8_break;
    }
#line 274
    tmp___2 = n;
#line 274
    n ++;
#line 274
    static_ltree[tmp___2].dl.len = (unsigned short)8;
#line 274
    bl_count[8] = (ush )((int )bl_count[8] + 1);
  }
  while_8_break: /* CIL Label */ ;
#line 275
  while (1) {
    while_9_continue: /* CIL Label */ ;
#line 275
    if (! (n <= 255)) {
      goto while_9_break;
    }
#line 275
    tmp___3 = n;
#line 275
    n ++;
#line 275
    static_ltree[tmp___3].dl.len = (unsigned short)9;
#line 275
    bl_count[9] = (ush )((int )bl_count[9] + 1);
  }
  while_9_break: /* CIL Label */ ;
#line 276
  while (1) {
    while_10_continue: /* CIL Label */ ;
#line 276
    if (! (n <= 279)) {
      goto while_10_break;
    }
#line 276
    tmp___4 = n;
#line 276
    n ++;
#line 276
    static_ltree[tmp___4].dl.len = (unsigned short)7;
#line 276
    bl_count[7] = (ush )((int )bl_count[7] + 1);
  }
  while_10_break: /* CIL Label */ ;
#line 277
  while (1) {
    while_11_continue: /* CIL Label */ ;
#line 277
    if (! (n <= 287)) {
      goto __dyc_dummy_label;
    }
#line 277
    tmp___5 = n;
#line 277
    n ++;
#line 277
    static_ltree[tmp___5].dl.len = (unsigned short)8;
#line 277
    bl_count[8] = (ush )((int )bl_count[8] + 1);
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(dist);
}
}
