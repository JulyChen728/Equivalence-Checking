#include <dycfoo.h>
#include "../inflate.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned char const   *next ;
  unsigned int have ;
  unsigned long hold ;
  unsigned int bits ;
  unsigned char const   *tmp___0 ;

  {
  next = (unsigned char const   *)__dyc_read_ptr__char();
  have = (unsigned int )__dyc_readpre_byte();
  hold = (unsigned long )__dyc_readpre_byte();
  bits = (unsigned int )__dyc_readpre_byte();
  tmp___0 = 0;
#line 393
  hold = 0UL;
#line 393
  bits = 0U;
  goto __dyc_dummy_label;
  while_11_continue: /* CIL Label */ ;
#line 396
  while (1) {
    while_12_continue: /* CIL Label */ ;
#line 396
    if (! (bits < 32U)) {
      goto while_12_break;
    }
    {
#line 396
    while (1) {
      while_13_continue: /* CIL Label */ ;
#line 396
      if (have == 0U) {
        goto __dyc_dummy_label;
      }
#line 396
      have --;
#line 396
      tmp___0 = next;
#line 396
      next ++;
#line 396
      hold += (unsigned long )*tmp___0 << bits;
#line 396
      bits += 8U;
      goto while_13_break;
    }
    while_13_break: /* CIL Label */ ;
    }
  }
  while_12_break: /* CIL Label */ ;
  goto __dyc_dummy_label;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__char(next);
  __dyc_printpre_byte(have);
  __dyc_printpre_byte(hold);
  __dyc_printpre_byte(bits);
}
}
