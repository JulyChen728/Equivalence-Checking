#include <dycfoo.h>
#include "../inflate.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned char const   *next ;
  unsigned int have ;
  unsigned int left ;
  unsigned long hold ;
  unsigned int bits ;
  unsigned int copy ;

  {
  next = (unsigned char const   *)__dyc_read_ptr__char();
  have = (unsigned int )__dyc_readpre_byte();
  left = (unsigned int )__dyc_readpre_byte();
  copy = (unsigned int )__dyc_readpre_byte();
  hold = 0;
  bits = 0;
#line 444
  hold = 0UL;
#line 444
  bits = 0U;
  goto __dyc_dummy_label;
#line 449
  if (copy > have) {
#line 449
    copy = have;
  }
#line 450
  if (copy > left) {
#line 450
    copy = left;
  }
#line 451
  if (copy == 0U) {
    goto __dyc_dummy_label;
  }

#line 453
  have -= copy;
#line 454
  next += copy;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__char(next);
  __dyc_printpre_byte(have);
  __dyc_printpre_byte(hold);
  __dyc_printpre_byte(bits);
}
}
