#include <dycfoo.h>
#include "../printf.i.hd.c.h"
void __dyc_foo(void) 
{ char c ;
  char sign ;
  char tmp[66] ;
  char const   *digits ;
  int i ;
  int tmp___0 ;
  int tmp___1 ;
  int __res ;
  char *tmp___2 ;
  int tmp___3 ;
  char *str ;
  long num ;
  int base ;
  int size ;
  int precision ;
  int type ;

  {
  digits = (char const   *)__dyc_read_ptr__char();
  str = __dyc_read_ptr__char();
  num = (long )__dyc_readpre_byte();
  base = __dyc_readpre_byte();
  size = __dyc_readpre_byte();
  precision = __dyc_readpre_byte();
  type = __dyc_readpre_byte();
  c = 0;
  sign = 0;
  i = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  __res = 0;
  tmp___2 = 0;
  tmp___3 = 0;
#line 56
  if (base < 2) {
    goto __dyc_dummy_label;
  } else {
#line 56
    if (base > 36) {
      goto __dyc_dummy_label;
    }
  }
#line 58
  if (type & 1) {
#line 58
    c = (char )'0';
  } else {
#line 58
    c = (char )' ';
  }
#line 59
  sign = (char)0;
#line 60
  if (type & 2) {
#line 61
    if (num < 0L) {
#line 62
      sign = (char )'-';
#line 63
      num = - num;
#line 64
      size --;
    } else {
#line 65
      if (type & 4) {
#line 66
        sign = (char )'+';
#line 67
        size --;
      } else {
#line 68
        if (type & 8) {
#line 69
          sign = (char )' ';
#line 70
          size --;
        }
      }
    }
  }
#line 73
  if (type & 32) {
#line 74
    if (base == 16) {
#line 75
      size -= 2;
    } else {
#line 76
      if (base == 8) {
#line 77
        size --;
      }
    }
  }
#line 79
  i = 0;
#line 80
  if (num == 0L) {
#line 81
    tmp___0 = i;
#line 81
    i ++;
#line 81
    tmp[tmp___0] = (char )'0';
  } else {
    {
#line 83
    while (1) {
      while_1_continue: /* CIL Label */ ;
#line 83
      if (! (num != 0L)) {
        goto while_1_break;
      }
#line 84
      tmp___1 = i;
#line 84
      i ++;
#line 84
      __res = (int )((unsigned long )num % (unsigned long )((unsigned int )base));
#line 84
      num = (long )((unsigned long )num / (unsigned long )((unsigned int )base));
#line 84
      tmp[tmp___1] = (char )*(digits + __res);
    }
    while_1_break: /* CIL Label */ ;
    }
  }
#line 85
  if (i > precision) {
#line 86
    precision = i;
  }
#line 87
  size -= precision;
#line 88
  if (! (type & 17)) {
    {
#line 89
    while (1) {
      while_2_continue: /* CIL Label */ ;
#line 89
      tmp___3 = size;
#line 89
      size --;
#line 89
      if (! (tmp___3 > 0)) {
        goto while_2_break;
      }
#line 90
      tmp___2 = str;
#line 90
      str ++;
#line 90
      *tmp___2 = (char )' ';
    }
    while_2_break: /* CIL Label */ ;
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(c);
  __dyc_printpre_byte(sign);
  __dyc_print_ptr__char(str);
  __dyc_printpre_byte(size);
}
}
