#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ uch *inbuf ;
  unsigned int insize ;
  unsigned int inptr ;
  unsigned int nl ;
  unsigned int nd ;
  ulg b ;
  unsigned int k ;
  int v ;
  int tmp___2 ;
  unsigned int tmp___3 ;
  int v___0 ;
  int tmp___6 ;
  unsigned int tmp___7 ;
  int v___1 ;
  int tmp___10 ;
  unsigned int tmp___11 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;

  {
  inbuf = __dyc_read_ptr__typdef_uch();
  insize = (unsigned int )__dyc_readpre_byte();
  inptr = (unsigned int )__dyc_readpre_byte();
  b = (ulg )__dyc_readpre_byte();
  k = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  nl = 0;
  nd = 0;
  v = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  v___0 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  v___1 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
#line 820
  while (1) {
    while_34_continue: /* CIL Label */ ;
#line 820
    if (! (k < 5U)) {
      goto while_34_break;
    }
#line 820
    if (inptr < insize) {
#line 820
      tmp___3 = inptr;
#line 820
      inptr ++;
#line 820
      tmp___2 = (int )*(inbuf + tmp___3);
    } else {
      {
#line 820
      tmp___2 = __dyc_funcallvar_2;
      }
    }
#line 820
    v = tmp___2;
#line 820
    if (v < 0) {
      goto __dyc_dummy_label;
    }
#line 820
    b |= (unsigned long )((unsigned char )v) << k;
#line 820
    k += 8U;
  }
  while_34_break: /* CIL Label */ ;
#line 821
  nl = 257U + ((unsigned int )b & 31U);
#line 822
  b >>= 5;
#line 822
  k -= 5U;
#line 823
  while (1) {
    while_35_continue: /* CIL Label */ ;
#line 823
    if (! (k < 5U)) {
      goto while_35_break;
    }
#line 823
    if (inptr < insize) {
#line 823
      tmp___7 = inptr;
#line 823
      inptr ++;
#line 823
      tmp___6 = (int )*(inbuf + tmp___7);
    } else {
      {
#line 823
      tmp___6 = __dyc_funcallvar_3;
      }
    }
#line 823
    v___0 = tmp___6;
#line 823
    if (v___0 < 0) {
      goto __dyc_dummy_label;
    }
#line 823
    b |= (unsigned long )((unsigned char )v___0) << k;
#line 823
    k += 8U;
  }
  while_35_break: /* CIL Label */ ;
#line 824
  nd = 1U + ((unsigned int )b & 31U);
#line 825
  b >>= 5;
#line 825
  k -= 5U;
#line 826
  while (1) {
    while_36_continue: /* CIL Label */ ;
#line 826
    if (! (k < 4U)) {
      goto __dyc_dummy_label;
    }
#line 826
    if (inptr < insize) {
#line 826
      tmp___11 = inptr;
#line 826
      inptr ++;
#line 826
      tmp___10 = (int )*(inbuf + tmp___11);
    } else {
      {
#line 826
      tmp___10 = __dyc_funcallvar_4;
      }
    }
#line 826
    v___1 = tmp___10;
#line 826
    if (v___1 < 0) {
      goto __dyc_dummy_label;
    }
#line 826
    b |= (unsigned long )((unsigned char )v___1) << k;
#line 826
    k += 8U;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(inptr);
  __dyc_printpre_byte(nl);
  __dyc_printpre_byte(nd);
  __dyc_printpre_byte(b);
}
}
