#include <dycfoo.h>
#include "../simple-object-elf.i.hd.c.h"
void __dyc_foo(void) 
{ struct simple_object_elf_write *eow ;
  struct simple_object_elf_attributes *attrs ;
  size_t ehdr_size ;
  size_t shdr_size ;
  simple_object_write_section *section ;
  unsigned int shnum ;
  size_t shdr_offset ;
  size_t sh_offset ;
  unsigned int first_sh_size ;
  unsigned int first_sh_link ;
  size_t sh_name ;
  unsigned char zero ;
  unsigned int secnum ;
  int tmp___0 ;
  size_t mask ;
  size_t new_sh_offset ;
  size_t sh_size ;
  struct simple_object_write_section_buffer *buffer ;
  unsigned int sh_type ;
  unsigned int sh_flags ;
  off_t sh_addr ;
  unsigned int sh_link ;
  unsigned int sh_info ;
  size_t sh_addralign ;
  size_t sh_entsize ;
  ulong_type tmp___5 ;
  ulong_type tmp___6 ;
  ulong_type tmp___9 ;
  ulong_type tmp___10 ;
  size_t write___0 ;
  int tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  size_t tmp___22 ;
  size_t tmp___23 ;
  int tmp___24 ;
  int tmp___25 ;
  size_t len ;
  size_t tmp___26 ;
  int tmp___27 ;
  size_t tmp___28 ;
  int tmp___29 ;
  simple_object_write *sobj ;
  int __dyc_funcallvar_2 ;
  unsigned int __dyc_funcallvar_3 ;
  unsigned int __dyc_funcallvar_4 ;
  ulong_type __dyc_funcallvar_5 ;
  ulong_type __dyc_funcallvar_6 ;
  ulong_type __dyc_funcallvar_7 ;
  ulong_type __dyc_funcallvar_8 ;
  unsigned int __dyc_funcallvar_9 ;
  unsigned int __dyc_funcallvar_10 ;
  unsigned int __dyc_funcallvar_11 ;
  unsigned int __dyc_funcallvar_12 ;
  ulong_type __dyc_funcallvar_13 ;
  ulong_type __dyc_funcallvar_14 ;
  ulong_type __dyc_funcallvar_15 ;
  ulong_type __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  size_t __dyc_funcallvar_20 ;
  size_t __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  size_t __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  size_t __dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;

  {
  eow = __dyc_read_ptr__comp_62simple_object_elf_write();
  attrs = __dyc_read_ptr__comp_61simple_object_elf_attributes();
  ehdr_size = (size_t )__dyc_readpre_byte();
  shdr_size = (size_t )__dyc_readpre_byte();
  sobj = __dyc_read_ptr__typdef_simple_object_write();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_4 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_5 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_6 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_7 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_8 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_9 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_10 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_11 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_12 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_13 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_14 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_15 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_16 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_21 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  section = 0;
  shnum = 0;
  shdr_offset = 0;
  sh_offset = 0;
  first_sh_size = 0;
  first_sh_link = 0;
  sh_name = 0;
  zero = 0;
  secnum = 0;
  tmp___0 = 0;
  mask = 0;
  new_sh_offset = 0;
  sh_size = 0;
  buffer = 0;
  sh_type = 0;
  sh_flags = 0;
  sh_addr = 0;
  sh_link = 0;
  sh_info = 0;
  sh_addralign = 0;
  sh_entsize = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  write___0 = 0;
  tmp___19 = 0;
  tmp___20 = 0;
  tmp___21 = 0;
  tmp___22 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  len = 0;
  tmp___26 = 0;
  tmp___27 = 0;
  tmp___28 = 0;
  tmp___29 = 0;
#line 929
  shnum = 0U;
#line 930
  section = sobj->sections;
#line 930
  while (1) {
    while_4_continue: /* CIL Label */ ;
#line 930
    if (! ((unsigned long )section != (unsigned long )((void *)0))) {
      goto while_4_break;
    }
#line 931
    shnum ++;
#line 930
    section = section->next;
  }
  while_4_break: /* CIL Label */ ;
#line 932
  if (shnum == 0U) {
    goto __dyc_dummy_label;
  }
#line 936
  shnum += 2U;
#line 938
  shdr_offset = ehdr_size;
#line 939
  sh_offset = shdr_offset + (size_t )shnum * shdr_size;
#line 941
  if (shnum < 65280U) {
#line 942
    first_sh_size = 0U;
  } else {
#line 944
    first_sh_size = shnum;
  }
#line 945
  if (shnum - 1U < 65280U) {
#line 946
    first_sh_link = 0U;
  } else {
#line 948
    first_sh_link = shnum - 1U;
  }
#line 949
  tmp___0 = __dyc_funcallvar_2;
#line 949
  if (! tmp___0) {
    goto __dyc_dummy_label;
  }
#line 954
  shdr_offset += shdr_size;
#line 956
  sh_name = 1UL;
#line 957
  secnum = 0U;
#line 958
  section = sobj->sections;
#line 958
  while (1) {
    while_5_continue: /* CIL Label */ ;
#line 958
    if (! ((unsigned long )section != (unsigned long )((void *)0))) {
      goto while_5_break;
    }
#line 964
    sh_type = 1U;
#line 965
    sh_flags = 0U;
#line 966
    sh_addr = (off_t )0;
#line 967
    sh_link = 0U;
#line 968
    sh_info = 0U;
#line 969
    sh_addralign = (size_t )(1U << section->align);
#line 970
    sh_entsize = (size_t )0;
#line 971
    if (eow->shdrs) {
#line 973
      if ((int )attrs->ei_class == 1) {
        {
#line 973
        sh_type = __dyc_funcallvar_3;
        }
      } else {
        {
#line 973
        sh_type = __dyc_funcallvar_4;
        }
      }
#line 976
      if ((int )attrs->ei_class == 1) {
        {
#line 976
        tmp___5 = __dyc_funcallvar_5;
#line 976
        sh_flags = (unsigned int )tmp___5;
        }
      } else {
        {
#line 976
        tmp___6 = __dyc_funcallvar_6;
#line 976
        sh_flags = (unsigned int )tmp___6;
        }
      }
#line 979
      if ((int )attrs->ei_class == 1) {
        {
#line 979
        tmp___9 = __dyc_funcallvar_7;
#line 979
        sh_addr = (long )tmp___9;
        }
      } else {
        {
#line 979
        tmp___10 = __dyc_funcallvar_8;
#line 979
        sh_addr = (long )tmp___10;
        }
      }
#line 982
      if ((int )attrs->ei_class == 1) {
        {
#line 982
        sh_link = __dyc_funcallvar_9;
        }
      } else {
        {
#line 982
        sh_link = __dyc_funcallvar_10;
        }
      }
#line 985
      if ((int )attrs->ei_class == 1) {
        {
#line 985
        sh_info = __dyc_funcallvar_11;
        }
      } else {
        {
#line 985
        sh_info = __dyc_funcallvar_12;
        }
      }
#line 988
      if ((int )attrs->ei_class == 1) {
        {
#line 988
        sh_addralign = __dyc_funcallvar_13;
        }
      } else {
        {
#line 988
        sh_addralign = __dyc_funcallvar_14;
        }
      }
#line 991
      if ((int )attrs->ei_class == 1) {
        {
#line 991
        sh_entsize = __dyc_funcallvar_15;
        }
      } else {
        {
#line 991
        sh_entsize = __dyc_funcallvar_16;
        }
      }
#line 994
      secnum ++;
    }
#line 997
    mask = sh_addralign - 1UL;
#line 998
    new_sh_offset = sh_offset + mask;
#line 999
    new_sh_offset &= ~ mask;
    {
#line 1000
    while (1) {
      while_6_continue: /* CIL Label */ ;
#line 1000
      if (! (new_sh_offset > sh_offset)) {
        goto while_6_break;
      }
      {

#line 1006
      write___0 = new_sh_offset - sh_offset;
      }
#line 1007
      if (write___0 > sizeof(unsigned char [16])) {
#line 1008
        write___0 = sizeof(unsigned char [16]);
      }
      {
#line 1009
      tmp___19 = __dyc_funcallvar_17;
      }
#line 1009
      if (! tmp___19) {
        goto __dyc_dummy_label;
      }
#line 1012
      sh_offset += write___0;
    }
    while_6_break: /* CIL Label */ ;
    }
#line 1015
    sh_size = 0UL;
#line 1016
    buffer = section->buffers;
    {
#line 1016
    while (1) {
      while_7_continue: /* CIL Label */ ;
#line 1016
      if (! ((unsigned long )buffer != (unsigned long )((void *)0))) {
        goto while_7_break;
      }
      {
#line 1018
      tmp___20 = __dyc_funcallvar_18;
      }
#line 1018
      if (! tmp___20) {
        goto __dyc_dummy_label;
      }
#line 1023
      sh_size += buffer->size;
#line 1016
      buffer = buffer->next;
    }
    while_7_break: /* CIL Label */ ;
    }
    {
#line 1026
    tmp___21 = __dyc_funcallvar_19;
    }
#line 1026
    if (! tmp___21) {
      goto __dyc_dummy_label;
    }
    {
#line 1034
    shdr_offset += shdr_size;
#line 1035
    tmp___22 = __dyc_funcallvar_20;
#line 1035
    sh_name += tmp___22 + 1UL;
#line 1036
    sh_offset += sh_size;
#line 958
    section = section->next;
    }
  }
  while_5_break: /* CIL Label */ ;
#line 1039
  tmp___23 = __dyc_funcallvar_21;
#line 1039
  tmp___24 = __dyc_funcallvar_22;
#line 1039
  if (! tmp___24) {
    goto __dyc_dummy_label;
  }
#line 1046
  zero = (unsigned char)0;
#line 1047
  tmp___25 = __dyc_funcallvar_23;
#line 1047
  if (! tmp___25) {
    goto __dyc_dummy_label;
  }
#line 1050
  sh_offset ++;
#line 1052
  section = sobj->sections;
#line 1052
  while (1) {
    while_8_continue: /* CIL Label */ ;
#line 1052
    if (! ((unsigned long )section != (unsigned long )((void *)0))) {
      goto while_8_break;
    }
    {
#line 1056
    tmp___26 = __dyc_funcallvar_24;
#line 1056
    len = tmp___26 + 1UL;
#line 1057
    tmp___27 = __dyc_funcallvar_25;
    }
#line 1057
    if (! tmp___27) {
      goto __dyc_dummy_label;
    }
#line 1061
    sh_offset += len;
#line 1052
    section = section->next;
  }
  while_8_break: /* CIL Label */ ;
#line 1064
  tmp___28 = __dyc_funcallvar_26;
#line 1064
  tmp___29 = __dyc_funcallvar_27;
#line 1064
  if (! tmp___29) {
    goto __dyc_dummy_label;
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(shdr_offset);
  __dyc_printpre_byte(sh_offset);
  __dyc_printpre_byte(first_sh_size);
  __dyc_printpre_byte(first_sh_link);
  __dyc_printpre_byte(sh_name);
  __dyc_printpre_byte(zero);
  __dyc_printpre_byte(secnum);
  __dyc_printpre_byte(sh_size);
  __dyc_printpre_byte(sh_type);
  __dyc_printpre_byte(sh_flags);
  __dyc_printpre_byte(sh_addr);
  __dyc_printpre_byte(sh_link);
  __dyc_printpre_byte(sh_info);
  __dyc_printpre_byte(sh_entsize);
  __dyc_printpre_byte(write___0);
  __dyc_printpre_byte(tmp___23);
  __dyc_printpre_byte(len);
  __dyc_printpre_byte(tmp___28);
}
}
