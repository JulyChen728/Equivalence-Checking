#include <dycfoo.h>
#include "../regex.i.hd.c.h"
void __dyc_foo(void) 
{ char str[7] ;
  boolean is_alnum ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___43 ;
  int tmp___48 ;
  int tmp___49 ;
  int tmp___50 ;
  int tmp___51 ;
  boolean is_alpha ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___61 ;
  int tmp___66 ;
  int tmp___67 ;
  int tmp___68 ;
  int tmp___69 ;
  boolean is_blank ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___79 ;
  int tmp___84 ;
  int tmp___85 ;
  int tmp___86 ;
  int tmp___87 ;
  boolean is_cntrl ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___97 ;
  int tmp___102 ;
  int tmp___103 ;
  int tmp___104 ;
  int tmp___105 ;
  boolean is_digit ;
  size_t __s1_len___3 ;
  size_t __s2_len___3 ;
  int tmp___115 ;
  int tmp___120 ;
  int tmp___121 ;
  int tmp___122 ;
  int tmp___123 ;
  boolean is_graph ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___133 ;
  int tmp___138 ;
  int tmp___139 ;
  int tmp___140 ;
  int tmp___141 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;
  int __dyc_funcallvar_30 ;
  int __dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  int __dyc_funcallvar_33 ;
  int __dyc_funcallvar_34 ;
  int __dyc_funcallvar_35 ;
  int __dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  int __dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;

  {
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  __dyc_funcallvar_31 = __dyc_readpre_byte();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_readpre_byte();
  __dyc_funcallvar_36 = __dyc_readpre_byte();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_readpre_byte();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  is_alnum = 0;
  __s1_len = 0;
  __s2_len = 0;
  tmp___43 = 0;
  tmp___48 = 0;
  tmp___49 = 0;
  tmp___50 = 0;
  tmp___51 = 0;
  is_alpha = 0;
  __s1_len___0 = 0;
  __s2_len___0 = 0;
  tmp___61 = 0;
  tmp___66 = 0;
  tmp___67 = 0;
  tmp___68 = 0;
  tmp___69 = 0;
  is_blank = 0;
  __s1_len___1 = 0;
  __s2_len___1 = 0;
  tmp___79 = 0;
  tmp___84 = 0;
  tmp___85 = 0;
  tmp___86 = 0;
  tmp___87 = 0;
  is_cntrl = 0;
  __s1_len___2 = 0;
  __s2_len___2 = 0;
  tmp___97 = 0;
  tmp___102 = 0;
  tmp___103 = 0;
  tmp___104 = 0;
  tmp___105 = 0;
  is_digit = 0;
  __s1_len___3 = 0;
  __s2_len___3 = 0;
  tmp___115 = 0;
  tmp___120 = 0;
  tmp___121 = 0;
  tmp___122 = 0;
  tmp___123 = 0;
  is_graph = 0;
  __s1_len___4 = 0;
  __s2_len___4 = 0;
  tmp___133 = 0;
  tmp___138 = 0;
  tmp___139 = 0;
  tmp___140 = 0;
  tmp___141 = 0;
#line 3212
  str[0] = (char )'\000';
#line 3255
  if (0) {
    {
#line 3255
    tmp___49 = __dyc_funcallvar_17;
#line 3255
    __s1_len = (unsigned long )tmp___49;
#line 3255
    tmp___50 = __dyc_funcallvar_18;
#line 3255
    __s2_len = (unsigned long )tmp___50;
    }
#line 3255
    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
      goto _L___4;
    } else {
#line 3255
      if (__s1_len >= 4UL) {
        _L___4: /* CIL Label */ 
#line 3255
        if (! ((unsigned long )((void const   *)("alnum" + 1)) - (unsigned long )((void const   *)"alnum") == 1UL)) {
#line 3255
          tmp___51 = 1;
        } else {
#line 3255
          if (__s2_len >= 4UL) {
#line 3255
            tmp___51 = 1;
          } else {
#line 3255
            tmp___51 = 0;
          }
        }
      } else {
#line 3255
        tmp___51 = 0;
      }
    }
#line 3255
    if (tmp___51) {
      {
#line 3255
      tmp___43 = __dyc_funcallvar_19;
      }
    } else {
      {
#line 3255
      tmp___48 = __dyc_funcallvar_20;
#line 3255
      tmp___43 = tmp___48;
      }
    }
  } else {
    {
#line 3255
    tmp___48 = __dyc_funcallvar_21;
#line 3255
    tmp___43 = tmp___48;
    }
  }
#line 3255
  is_alnum = (boolean )(tmp___43 == 0);
#line 3256
  if (0) {
    {
#line 3256
    tmp___67 = __dyc_funcallvar_22;
#line 3256
    __s1_len___0 = (unsigned long )tmp___67;
#line 3256
    tmp___68 = __dyc_funcallvar_23;
#line 3256
    __s2_len___0 = (unsigned long )tmp___68;
    }
#line 3256
    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
      goto _L___6;
    } else {
#line 3256
      if (__s1_len___0 >= 4UL) {
        _L___6: /* CIL Label */ 
#line 3256
        if (! ((unsigned long )((void const   *)("alpha" + 1)) - (unsigned long )((void const   *)"alpha") == 1UL)) {
#line 3256
          tmp___69 = 1;
        } else {
#line 3256
          if (__s2_len___0 >= 4UL) {
#line 3256
            tmp___69 = 1;
          } else {
#line 3256
            tmp___69 = 0;
          }
        }
      } else {
#line 3256
        tmp___69 = 0;
      }
    }
#line 3256
    if (tmp___69) {
      {
#line 3256
      tmp___61 = __dyc_funcallvar_24;
      }
    } else {
      {
#line 3256
      tmp___66 = __dyc_funcallvar_25;
#line 3256
      tmp___61 = tmp___66;
      }
    }
  } else {
    {
#line 3256
    tmp___66 = __dyc_funcallvar_26;
#line 3256
    tmp___61 = tmp___66;
    }
  }
#line 3256
  is_alpha = (boolean )(tmp___61 == 0);
#line 3257
  if (0) {
    {
#line 3257
    tmp___85 = __dyc_funcallvar_27;
#line 3257
    __s1_len___1 = (unsigned long )tmp___85;
#line 3257
    tmp___86 = __dyc_funcallvar_28;
#line 3257
    __s2_len___1 = (unsigned long )tmp___86;
    }
#line 3257
    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
      goto _L___8;
    } else {
#line 3257
      if (__s1_len___1 >= 4UL) {
        _L___8: /* CIL Label */ 
#line 3257
        if (! ((unsigned long )((void const   *)("blank" + 1)) - (unsigned long )((void const   *)"blank") == 1UL)) {
#line 3257
          tmp___87 = 1;
        } else {
#line 3257
          if (__s2_len___1 >= 4UL) {
#line 3257
            tmp___87 = 1;
          } else {
#line 3257
            tmp___87 = 0;
          }
        }
      } else {
#line 3257
        tmp___87 = 0;
      }
    }
#line 3257
    if (tmp___87) {
      {
#line 3257
      tmp___79 = __dyc_funcallvar_29;
      }
    } else {
      {
#line 3257
      tmp___84 = __dyc_funcallvar_30;
#line 3257
      tmp___79 = tmp___84;
      }
    }
  } else {
    {
#line 3257
    tmp___84 = __dyc_funcallvar_31;
#line 3257
    tmp___79 = tmp___84;
    }
  }
#line 3257
  is_blank = (boolean )(tmp___79 == 0);
#line 3258
  if (0) {
    {
#line 3258
    tmp___103 = __dyc_funcallvar_32;
#line 3258
    __s1_len___2 = (unsigned long )tmp___103;
#line 3258
    tmp___104 = __dyc_funcallvar_33;
#line 3258
    __s2_len___2 = (unsigned long )tmp___104;
    }
#line 3258
    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
      goto _L___10;
    } else {
#line 3258
      if (__s1_len___2 >= 4UL) {
        _L___10: /* CIL Label */ 
#line 3258
        if (! ((unsigned long )((void const   *)("cntrl" + 1)) - (unsigned long )((void const   *)"cntrl") == 1UL)) {
#line 3258
          tmp___105 = 1;
        } else {
#line 3258
          if (__s2_len___2 >= 4UL) {
#line 3258
            tmp___105 = 1;
          } else {
#line 3258
            tmp___105 = 0;
          }
        }
      } else {
#line 3258
        tmp___105 = 0;
      }
    }
#line 3258
    if (tmp___105) {
      {
#line 3258
      tmp___97 = __dyc_funcallvar_34;
      }
    } else {
      {
#line 3258
      tmp___102 = __dyc_funcallvar_35;
#line 3258
      tmp___97 = tmp___102;
      }
    }
  } else {
    {
#line 3258
    tmp___102 = __dyc_funcallvar_36;
#line 3258
    tmp___97 = tmp___102;
    }
  }
#line 3258
  is_cntrl = (boolean )(tmp___97 == 0);
#line 3259
  if (0) {
    {
#line 3259
    tmp___121 = __dyc_funcallvar_37;
#line 3259
    __s1_len___3 = (unsigned long )tmp___121;
#line 3259
    tmp___122 = __dyc_funcallvar_38;
#line 3259
    __s2_len___3 = (unsigned long )tmp___122;
    }
#line 3259
    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
      goto _L___12;
    } else {
#line 3259
      if (__s1_len___3 >= 4UL) {
        _L___12: /* CIL Label */ 
#line 3259
        if (! ((unsigned long )((void const   *)("digit" + 1)) - (unsigned long )((void const   *)"digit") == 1UL)) {
#line 3259
          tmp___123 = 1;
        } else {
#line 3259
          if (__s2_len___3 >= 4UL) {
#line 3259
            tmp___123 = 1;
          } else {
#line 3259
            tmp___123 = 0;
          }
        }
      } else {
#line 3259
        tmp___123 = 0;
      }
    }
#line 3259
    if (tmp___123) {
      {
#line 3259
      tmp___115 = __dyc_funcallvar_39;
      }
    } else {
      {
#line 3259
      tmp___120 = __dyc_funcallvar_40;
#line 3259
      tmp___115 = tmp___120;
      }
    }
  } else {
    {
#line 3259
    tmp___120 = __dyc_funcallvar_41;
#line 3259
    tmp___115 = tmp___120;
    }
  }
#line 3259
  is_digit = (boolean )(tmp___115 == 0);
#line 3260
  if (0) {
    {
#line 3260
    tmp___139 = __dyc_funcallvar_42;
#line 3260
    __s1_len___4 = (unsigned long )tmp___139;
#line 3260
    tmp___140 = __dyc_funcallvar_43;
#line 3260
    __s2_len___4 = (unsigned long )tmp___140;
    }
#line 3260
    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
      goto _L___14;
    } else {
#line 3260
      if (__s1_len___4 >= 4UL) {
        _L___14: /* CIL Label */ 
#line 3260
        if (! ((unsigned long )((void const   *)("graph" + 1)) - (unsigned long )((void const   *)"graph") == 1UL)) {
#line 3260
          tmp___141 = 1;
        } else {
#line 3260
          if (__s2_len___4 >= 4UL) {
#line 3260
            tmp___141 = 1;
          } else {
#line 3260
            tmp___141 = 0;
          }
        }
      } else {
#line 3260
        tmp___141 = 0;
      }
    }
#line 3260
    if (tmp___141) {
      {
#line 3260
      tmp___133 = __dyc_funcallvar_44;
      }
    } else {
      {
#line 3260
      tmp___138 = __dyc_funcallvar_45;
#line 3260
      tmp___133 = tmp___138;
      }
    }
  } else {
    {
#line 3260
    tmp___138 = __dyc_funcallvar_46;
#line 3260
    tmp___133 = tmp___138;
    }
  }
#line 3260
  is_graph = (boolean )(tmp___133 == 0);
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(is_alnum);
  __dyc_printpre_byte(__s1_len);
  __dyc_printpre_byte(__s2_len);
  __dyc_printpre_byte(is_alpha);
  __dyc_printpre_byte(__s1_len___0);
  __dyc_printpre_byte(__s2_len___0);
  __dyc_printpre_byte(is_blank);
  __dyc_printpre_byte(__s1_len___1);
  __dyc_printpre_byte(__s2_len___1);
  __dyc_printpre_byte(is_cntrl);
  __dyc_printpre_byte(__s1_len___2);
  __dyc_printpre_byte(__s2_len___2);
  __dyc_printpre_byte(is_digit);
  __dyc_printpre_byte(__s1_len___3);
  __dyc_printpre_byte(__s2_len___3);
  __dyc_printpre_byte(is_graph);
  __dyc_printpre_byte(__s1_len___4);
  __dyc_printpre_byte(__s2_len___4);
}
}
