#include <dycfoo.h>
#include "../cp-demangle.i.hd.c.h"
void __dyc_foo(void) 
{ char const   *code ;
  struct demangle_component *right ;
  struct demangle_component *tmp___56 ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___66 ;
  int tmp___71 ;
  int tmp___72 ;
  int tmp___73 ;
  int tmp___74 ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___84 ;
  int tmp___89 ;
  int tmp___90 ;
  int tmp___91 ;
  int tmp___92 ;
  int tmp___102 ;
  int tmp___107 ;
  struct d_info *di ;
  int __dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  int __dyc_funcallvar_50 ;
  int __dyc_funcallvar_51 ;
  int __dyc_funcallvar_52 ;
  int __dyc_funcallvar_53 ;
  int __dyc_funcallvar_54 ;
  int __dyc_funcallvar_55 ;
  int __dyc_funcallvar_56 ;
  int __dyc_funcallvar_57 ;
  struct demangle_component *__dyc_funcallvar_58 ;
  struct demangle_component *__dyc_funcallvar_59 ;
  struct demangle_component *__dyc_funcallvar_60 ;
  struct demangle_component *__dyc_funcallvar_61 ;
  struct demangle_component *__dyc_funcallvar_62 ;

  {
  code = (char const   *)__dyc_read_ptr__char();
  tmp___107 = __dyc_readpre_byte();
  di = __dyc_read_ptr__comp_60d_info();
  __dyc_funcallvar_48 = __dyc_readpre_byte();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_readpre_byte();
  __dyc_funcallvar_51 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  __dyc_funcallvar_53 = __dyc_readpre_byte();
  __dyc_funcallvar_54 = __dyc_readpre_byte();
  __dyc_funcallvar_55 = __dyc_readpre_byte();
  __dyc_funcallvar_56 = __dyc_readpre_byte();
  __dyc_funcallvar_57 = __dyc_readpre_byte();
  __dyc_funcallvar_58 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_59 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_60 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_61 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_62 = __dyc_read_ptr__comp_46demangle_component();
  right = 0;
  tmp___56 = 0;
  __s1_len___1 = 0;
  __s2_len___1 = 0;
  tmp___66 = 0;
  tmp___71 = 0;
  tmp___72 = 0;
  tmp___73 = 0;
  tmp___74 = 0;
  __s1_len___2 = 0;
  __s2_len___2 = 0;
  tmp___84 = 0;
  tmp___89 = 0;
  tmp___90 = 0;
  tmp___91 = 0;
  tmp___92 = 0;
  tmp___102 = 0;
#line 3458
  tmp___102 = tmp___107;
#line 3460
  if (0) {
    {
#line 3460
    tmp___72 = __dyc_funcallvar_48;
#line 3460
    __s1_len___1 = (unsigned long )tmp___72;
#line 3460
    tmp___73 = __dyc_funcallvar_49;
#line 3460
    __s2_len___1 = (unsigned long )tmp___73;
    }
#line 3460
    if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
      goto _L___6;
    } else {
#line 3460
      if (__s1_len___1 >= 4UL) {
        _L___6: /* CIL Label */ 
#line 3460
        if (! ((unsigned long )((void const   *)("dt" + 1)) - (unsigned long )((void const   *)"dt") == 1UL)) {
#line 3460
          tmp___74 = 1;
        } else {
#line 3460
          if (__s2_len___1 >= 4UL) {
#line 3460
            tmp___74 = 1;
          } else {
#line 3460
            tmp___74 = 0;
          }
        }
      } else {
#line 3460
        tmp___74 = 0;
      }
    }
#line 3460
    if (tmp___74) {
      {
#line 3460
      tmp___66 = __dyc_funcallvar_50;
      }
    } else {
      {
#line 3460
      tmp___71 = __dyc_funcallvar_51;
#line 3460
      tmp___66 = tmp___71;
      }
    }
  } else {
    {
#line 3460
    tmp___71 = __dyc_funcallvar_52;
#line 3460
    tmp___66 = tmp___71;
    }
  }
#line 3460
  if (tmp___66) {
#line 3460
    if (0) {
      {
#line 3460
      tmp___90 = __dyc_funcallvar_53;
#line 3460
      __s1_len___2 = (unsigned long )tmp___90;
#line 3460
      tmp___91 = __dyc_funcallvar_54;
#line 3460
      __s2_len___2 = (unsigned long )tmp___91;
      }
#line 3460
      if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
        goto _L___8;
      } else {
#line 3460
        if (__s1_len___2 >= 4UL) {
          _L___8: /* CIL Label */ 
#line 3460
          if (! ((unsigned long )((void const   *)("pt" + 1)) - (unsigned long )((void const   *)"pt") == 1UL)) {
#line 3460
            tmp___92 = 1;
          } else {
#line 3460
            if (__s2_len___2 >= 4UL) {
#line 3460
              tmp___92 = 1;
            } else {
#line 3460
              tmp___92 = 0;
            }
          }
        } else {
#line 3460
          tmp___92 = 0;
        }
      }
#line 3460
      if (tmp___92) {
        {
#line 3460
        tmp___84 = __dyc_funcallvar_55;
        }
      } else {
        {
#line 3460
        tmp___89 = __dyc_funcallvar_56;
#line 3460
        tmp___84 = tmp___89;
        }
      }
    } else {
      {
#line 3460
      tmp___89 = __dyc_funcallvar_57;
#line 3460
      tmp___84 = tmp___89;
      }
    }
#line 3460
    if (tmp___84) {
      {
#line 3468
      right = __dyc_funcallvar_58;
      }
    } else {
      _L___9: /* CIL Label */ 
      {
#line 3462
      right = __dyc_funcallvar_59;
      }
#line 3463
      if ((int const   )*(di->n) == 73) {
        {
#line 3464
        tmp___56 = __dyc_funcallvar_60;
#line 3464
        right = __dyc_funcallvar_61;
        }
      }
    }
  } else {
    goto _L___9;
  }
#line 3459
  right = __dyc_funcallvar_62;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__comp_46demangle_component(right);
  __dyc_print_ptr__comp_46demangle_component(tmp___56);
  __dyc_printpre_byte(__s1_len___1);
  __dyc_printpre_byte(__s2_len___1);
  __dyc_printpre_byte(__s1_len___2);
  __dyc_printpre_byte(__s2_len___2);
  __dyc_printpre_byte(tmp___102);
}
}
