#include <dycfoo.h>
#include "../simple-object-mach-o.i.hd.c.h"
void __dyc_foo(void) 
{ struct simple_object_mach_o_read *omr ;
  size_t sechdrsize ;
  size_t segname_offset ;
  unsigned int nsects ;
  unsigned char *secdata ;
  unsigned int i ;
  unsigned int gnu_sections_found ;
  unsigned int strtab_index ;
  unsigned int index_index ;
  unsigned int nametab_index ;
  unsigned int sections_index ;
  char *strtab ;
  char *nametab ;
  size_t strtab_size ;
  unsigned int n_wrapped_sects ;
  off_t wrapper_sect_offset ;
  unsigned char const   *sechdr ;
  char namebuf[34] ;
  char *name ;
  off_t secoffset ;
  size_t secsize ;
  int l ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___106 ;
  int tmp___111 ;
  int tmp___112 ;
  int tmp___113 ;
  int tmp___114 ;
  unsigned int j ;
  unsigned int subsect_offset ;
  unsigned int subsect_length ;
  unsigned int name_offset ;
  int tmp___115 ;
  unsigned long stringoffset ;
  int tmp___116 ;
  size_t tmp___117 ;
  int tmp___118 ;
  char const   **errmsg ;
  int *err ;
  int __dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  unsigned int __dyc_funcallvar_41 ;
  unsigned int __dyc_funcallvar_42 ;
  unsigned int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;
  size_t __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;

  {
  omr = __dyc_read_ptr__comp_58simple_object_mach_o_read();
  sechdrsize = (size_t )__dyc_readpre_byte();
  segname_offset = (size_t )__dyc_readpre_byte();
  nsects = (unsigned int )__dyc_readpre_byte();
  secdata = (unsigned char *)__dyc_read_ptr__char();
  i = (unsigned int )__dyc_readpre_byte();
  gnu_sections_found = (unsigned int )__dyc_readpre_byte();
  strtab_index = (unsigned int )__dyc_readpre_byte();
  index_index = (unsigned int )__dyc_readpre_byte();
  nametab_index = (unsigned int )__dyc_readpre_byte();
  sections_index = (unsigned int )__dyc_readpre_byte();
  strtab = __dyc_read_ptr__char();
  nametab = __dyc_read_ptr__char();
  strtab_size = (size_t )__dyc_readpre_byte();
  n_wrapped_sects = (unsigned int )__dyc_readpre_byte();
  wrapper_sect_offset = (off_t )__dyc_readpre_byte();
  stringoffset = (unsigned long )__dyc_readpre_byte();
  errmsg = (char const   **)__dyc_read_ptr__ptr__char();
  err = __dyc_read_ptr__int();
  __dyc_funcallvar_36 = __dyc_readpre_byte();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_42 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_43 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  sechdr = 0;
  name = 0;
  secoffset = 0;
  secsize = 0;
  l = 0;
  __s1_len___4 = 0;
  __s2_len___4 = 0;
  tmp___106 = 0;
  tmp___111 = 0;
  tmp___112 = 0;
  tmp___113 = 0;
  tmp___114 = 0;
  j = 0;
  subsect_offset = 0;
  subsect_length = 0;
  name_offset = 0;
  tmp___115 = 0;
  tmp___116 = 0;
  tmp___117 = 0;
  tmp___118 = 0;
#line 613
  if (! (i < nsects)) {
    goto __dyc_dummy_label;
  }
#line 622
  sechdr = (unsigned char const   *)(secdata + (size_t )i * sechdrsize);
#line 626
  if ((gnu_sections_found & 8U) != 0U) {
#line 626
    if (i == strtab_index) {
      goto __Cont___0;
    }
  }
#line 632
  if (0) {
    {
#line 632
    tmp___112 = __dyc_funcallvar_36;
#line 632
    __s1_len___4 = (unsigned long )tmp___112;
#line 632
    tmp___113 = __dyc_funcallvar_37;
#line 632
    __s2_len___4 = (unsigned long )tmp___113;
    }
#line 632
    if (! ((unsigned long )((void const   *)(((char *)sechdr + segname_offset) + 1)) - (unsigned long )((void const   *)((char *)sechdr + segname_offset)) == 1UL)) {
      goto _L___10;
    } else {
#line 632
      if (__s1_len___4 >= 4UL) {
        _L___10: /* CIL Label */ 
#line 632
        if (! ((unsigned long )((void const   *)(omr->segment_name + 1)) - (unsigned long )((void const   *)omr->segment_name) == 1UL)) {
#line 632
          tmp___114 = 1;
        } else {
#line 632
          if (__s2_len___4 >= 4UL) {
#line 632
            tmp___114 = 1;
          } else {
#line 632
            tmp___114 = 0;
          }
        }
      } else {
#line 632
        tmp___114 = 0;
      }
    }
#line 632
    if (tmp___114) {
      {
#line 632
      tmp___106 = __dyc_funcallvar_38;
      }
    } else {
      {
#line 632
      tmp___111 = __dyc_funcallvar_39;
#line 632
      tmp___106 = tmp___111;
      }
    }
  } else {
    {
#line 632
    tmp___111 = __dyc_funcallvar_40;
#line 632
    tmp___106 = tmp___111;
    }
  }
#line 632
  if (tmp___106 != 0) {
    goto __Cont___0;
  }
#line 637
  if ((gnu_sections_found & 7U) != 0U) {
#line 639
    if (i == nametab_index) {
      goto __Cont___0;
    } else {
#line 639
      if (i == index_index) {
        goto __Cont___0;
      }
    }
#line 642
    if (i == sections_index) {
#line 645
      j = 0U;
      {
#line 645
      while (1) {
        while_2_continue: /* CIL Label */ ;
#line 645
        if (! (j < n_wrapped_sects)) {
          goto while_2_break;
        }
        {
#line 648
        subsect_offset = __dyc_funcallvar_41;
#line 649
        subsect_length = __dyc_funcallvar_42;
#line 650
        name_offset = __dyc_funcallvar_43;
#line 653
        secoffset = wrapper_sect_offset + (off_t )subsect_offset;
#line 654
        secsize = (unsigned long )subsect_length;
#line 655
        name = nametab + name_offset;
#line 657
        tmp___115 = __dyc_funcallvar_44;
        }
#line 657
        if (! tmp___115) {
          {
#line 659
          *errmsg = (char const   *)((void *)0);
#line 660
          *err = 0;




          }
          goto __dyc_dummy_label;
        }
#line 645
        j ++;
      }
      while_2_break: /* CIL Label */ ;
      }
      goto __Cont___0;
    }
  }
#line 672
  if ((gnu_sections_found & 8U) != 0U) {
    {

#line 675
    namebuf[16] = (char )'\000';
#line 677
    name = namebuf;
    }
#line 678
    if ((unsigned long )strtab != (unsigned long )((void *)0)) {
#line 678
      if ((int )*(name + 0) == 95) {
#line 678
        if ((int )*(name + 1) == 95) {
          {
#line 682
          tmp___116 = __dyc_funcallvar_45;
          }
#line 682
          if (tmp___116 == 1) {
#line 684
            if (stringoffset >= strtab_size) {
              {
#line 686
              *errmsg = "section name offset out of range";
#line 687
              *err = 0;




              }
              goto __dyc_dummy_label;
            }
#line 695
            name = strtab + stringoffset;
          }
        }
      }
    }
  } else {
    {
#line 703
    name = namebuf;

#line 705
    namebuf[16] = (char )'\000';
#line 706
    tmp___117 = __dyc_funcallvar_46;
#line 706
    l = (int )tmp___117;
#line 707
    namebuf[l] = (char )',';

#line 710
    namebuf[(l + 1) + 16] = (char )'\000';
    }
  }

#line 716
  tmp___118 = __dyc_funcallvar_47;
#line 716
  if (! tmp___118) {
    {
#line 718
    *errmsg = (char const   *)((void *)0);
#line 719
    *err = 0;




    }
    goto __dyc_dummy_label;
  }
  __Cont___0: /* CIL Label */ 
#line 613
  i ++;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(i);
  __dyc_print_ptr__char(sechdr);
  __dyc_print_ptr__char(name);
  __dyc_printpre_byte(secoffset);
  __dyc_printpre_byte(secsize);
  __dyc_printpre_byte(__s1_len___4);
  __dyc_printpre_byte(__s2_len___4);
}
}
