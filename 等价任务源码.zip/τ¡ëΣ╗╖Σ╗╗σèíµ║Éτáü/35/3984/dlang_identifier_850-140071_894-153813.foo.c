#include <dycfoo.h>
#include "../d-demangle.i.hd.c.h"
void __dyc_foo(void) 
{ long len ;
  int tmp___45 ;
  int tmp___46 ;
  int tmp___68 ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___78 ;
  int tmp___83 ;
  int tmp___84 ;
  int tmp___85 ;
  int tmp___86 ;
  int tmp___110 ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___120 ;
  int tmp___125 ;
  int tmp___126 ;
  int tmp___127 ;
  int tmp___128 ;
  int tmp___152 ;
  size_t __s1_len___6 ;
  size_t __s2_len___6 ;
  int tmp___162 ;
  int tmp___167 ;
  int tmp___168 ;
  int tmp___169 ;
  int tmp___170 ;
  int tmp___194 ;
  int tmp___215 ;
  int tmp___237 ;
  size_t __s1_len___10 ;
  size_t __s2_len___10 ;
  int tmp___247 ;
  int tmp___252 ;
  int tmp___253 ;
  int tmp___254 ;
  int tmp___255 ;
  int tmp___279 ;
  size_t __s1_len___12 ;
  size_t __s2_len___12 ;
  int tmp___289 ;
  int tmp___294 ;
  int tmp___295 ;
  int tmp___296 ;
  int tmp___297 ;
  char const   *mangled ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;
  int __dyc_funcallvar_30 ;
  int __dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  int __dyc_funcallvar_33 ;
  int __dyc_funcallvar_34 ;
  int __dyc_funcallvar_35 ;
  int __dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  int __dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;
  int __dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  int __dyc_funcallvar_50 ;
  int __dyc_funcallvar_51 ;
  int __dyc_funcallvar_52 ;

  {
  len = (long )__dyc_readpre_byte();
  tmp___194 = __dyc_readpre_byte();
  mangled = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  __dyc_funcallvar_31 = __dyc_readpre_byte();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_readpre_byte();
  __dyc_funcallvar_36 = __dyc_readpre_byte();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_readpre_byte();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = __dyc_readpre_byte();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_readpre_byte();
  __dyc_funcallvar_51 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  tmp___45 = 0;
  tmp___46 = 0;
  tmp___68 = 0;
  __s1_len___2 = 0;
  __s2_len___2 = 0;
  tmp___78 = 0;
  tmp___83 = 0;
  tmp___84 = 0;
  tmp___85 = 0;
  tmp___86 = 0;
  tmp___110 = 0;
  __s1_len___4 = 0;
  __s2_len___4 = 0;
  tmp___120 = 0;
  tmp___125 = 0;
  tmp___126 = 0;
  tmp___127 = 0;
  tmp___128 = 0;
  tmp___152 = 0;
  __s1_len___6 = 0;
  __s2_len___6 = 0;
  tmp___162 = 0;
  tmp___167 = 0;
  tmp___168 = 0;
  tmp___169 = 0;
  tmp___170 = 0;
  tmp___215 = 0;
  tmp___237 = 0;
  __s1_len___10 = 0;
  __s2_len___10 = 0;
  tmp___247 = 0;
  tmp___252 = 0;
  tmp___253 = 0;
  tmp___254 = 0;
  tmp___255 = 0;
  tmp___279 = 0;
  __s1_len___12 = 0;
  __s2_len___12 = 0;
  tmp___289 = 0;
  tmp___294 = 0;
  tmp___295 = 0;
  tmp___296 = 0;
  tmp___297 = 0;
#line 850
  if (tmp___194 == 0) {
    {

#line 854
    mangled += len;
    }
    goto __dyc_dummy_label;
  } else {
#line 857
    if (0) {
#line 857
      if (0) {
        {
#line 857
        tmp___168 = __dyc_funcallvar_20;
#line 857
        __s1_len___6 = (unsigned long )tmp___168;
#line 857
        tmp___169 = __dyc_funcallvar_21;
#line 857
        __s2_len___6 = (unsigned long )tmp___169;
        }
#line 857
        if (! ((unsigned long )((void const   *)(mangled + 1)) - (unsigned long )((void const   *)mangled) == 1UL)) {
          goto _L___14;
        } else {
#line 857
          if (__s1_len___6 >= 4UL) {
            _L___14: /* CIL Label */ 
#line 857
            if (! ((unsigned long )((void const   *)("__dtor" + 1)) - (unsigned long )((void const   *)"__dtor") == 1UL)) {
#line 857
              tmp___170 = 1;
            } else {
#line 857
              if (__s2_len___6 >= 4UL) {
#line 857
                tmp___170 = 1;
              } else {
#line 857
                tmp___170 = 0;
              }
            }
          } else {
#line 857
            tmp___170 = 0;
          }
        }
#line 857
        if (tmp___170) {
          {
#line 857
          tmp___162 = __dyc_funcallvar_22;
          }
        } else {
          {
#line 857
          tmp___167 = __dyc_funcallvar_23;
#line 857
          tmp___162 = tmp___167;
          }
        }
      } else {
        {
#line 857
        tmp___167 = __dyc_funcallvar_24;
#line 857
        tmp___162 = tmp___167;
        }
      }
#line 857
      tmp___152 = tmp___162;
    } else {
      {
#line 857
      tmp___152 = __dyc_funcallvar_25;
      }
    }
#line 857
    if (tmp___152 == 0) {
      {

#line 861
      mangled += len;
      }
      goto __dyc_dummy_label;
    } else {
#line 864
      if (0) {
#line 864
        if (0) {
          {
#line 864
          tmp___126 = __dyc_funcallvar_26;
#line 864
          __s1_len___4 = (unsigned long )tmp___126;
#line 864
          tmp___127 = __dyc_funcallvar_27;
#line 864
          __s2_len___4 = (unsigned long )tmp___127;
          }
#line 864
          if (! ((unsigned long )((void const   *)(mangled + 1)) - (unsigned long )((void const   *)mangled) == 1UL)) {
            goto _L___10;
          } else {
#line 864
            if (__s1_len___4 >= 4UL) {
              _L___10: /* CIL Label */ 
#line 864
              if (! ((unsigned long )((void const   *)("__initZ" + 1)) - (unsigned long )((void const   *)"__initZ") == 1UL)) {
#line 864
                tmp___128 = 1;
              } else {
#line 864
                if (__s2_len___4 >= 4UL) {
#line 864
                  tmp___128 = 1;
                } else {
#line 864
                  tmp___128 = 0;
                }
              }
            } else {
#line 864
              tmp___128 = 0;
            }
          }
#line 864
          if (tmp___128) {
            {
#line 864
            tmp___120 = __dyc_funcallvar_28;
            }
          } else {
            {
#line 864
            tmp___125 = __dyc_funcallvar_29;
#line 864
            tmp___120 = tmp___125;
            }
          }
        } else {
          {
#line 864
          tmp___125 = __dyc_funcallvar_30;
#line 864
          tmp___120 = tmp___125;
          }
        }
#line 864
        tmp___110 = tmp___120;
      } else {
        {
#line 864
        tmp___110 = __dyc_funcallvar_31;
        }
      }
#line 864
      if (tmp___110 == 0) {
        {

#line 868
        tmp___45 = __dyc_funcallvar_32;

#line 869
        mangled += len;
        }
        goto __dyc_dummy_label;
      } else {
#line 872
        if (0) {
#line 872
          if (0) {
            {
#line 872
            tmp___84 = __dyc_funcallvar_33;
#line 872
            __s1_len___2 = (unsigned long )tmp___84;
#line 872
            tmp___85 = __dyc_funcallvar_34;
#line 872
            __s2_len___2 = (unsigned long )tmp___85;
            }
#line 872
            if (! ((unsigned long )((void const   *)(mangled + 1)) - (unsigned long )((void const   *)mangled) == 1UL)) {
              goto _L___6;
            } else {
#line 872
              if (__s1_len___2 >= 4UL) {
                _L___6: /* CIL Label */ 
#line 872
                if (! ((unsigned long )((void const   *)("__vtblZ" + 1)) - (unsigned long )((void const   *)"__vtblZ") == 1UL)) {
#line 872
                  tmp___86 = 1;
                } else {
#line 872
                  if (__s2_len___2 >= 4UL) {
#line 872
                    tmp___86 = 1;
                  } else {
#line 872
                    tmp___86 = 0;
                  }
                }
              } else {
#line 872
                tmp___86 = 0;
              }
            }
#line 872
            if (tmp___86) {
              {
#line 872
              tmp___78 = __dyc_funcallvar_35;
              }
            } else {
              {
#line 872
              tmp___83 = __dyc_funcallvar_36;
#line 872
              tmp___78 = tmp___83;
              }
            }
          } else {
            {
#line 872
            tmp___83 = __dyc_funcallvar_37;
#line 872
            tmp___78 = tmp___83;
            }
          }
#line 872
          tmp___68 = tmp___78;
        } else {
          {
#line 872
          tmp___68 = __dyc_funcallvar_38;
          }
        }
#line 872
        if (tmp___68 == 0) {
          {

#line 876
          tmp___46 = __dyc_funcallvar_39;

#line 877
          mangled += len;
          }
          goto __dyc_dummy_label;
        }
      }
    }
  }
  goto __dyc_dummy_label;
  switch_14_7: /* CIL Label */ 
#line 883
  if (0) {
#line 883
    if (0) {
      {
#line 883
      tmp___253 = __dyc_funcallvar_40;
#line 883
      __s1_len___10 = (unsigned long )tmp___253;
#line 883
      tmp___254 = __dyc_funcallvar_41;
#line 883
      __s2_len___10 = (unsigned long )tmp___254;
      }
#line 883
      if (! ((unsigned long )((void const   *)(mangled + 1)) - (unsigned long )((void const   *)mangled) == 1UL)) {
        goto _L___22;
      } else {
#line 883
        if (__s1_len___10 >= 4UL) {
          _L___22: /* CIL Label */ 
#line 883
          if (! ((unsigned long )((void const   *)("__ClassZ" + 1)) - (unsigned long )((void const   *)"__ClassZ") == 1UL)) {
#line 883
            tmp___255 = 1;
          } else {
#line 883
            if (__s2_len___10 >= 4UL) {
#line 883
              tmp___255 = 1;
            } else {
#line 883
              tmp___255 = 0;
            }
          }
        } else {
#line 883
          tmp___255 = 0;
        }
      }
#line 883
      if (tmp___255) {
        {
#line 883
        tmp___247 = __dyc_funcallvar_42;
        }
      } else {
        {
#line 883
        tmp___252 = __dyc_funcallvar_43;
#line 883
        tmp___247 = tmp___252;
        }
      }
    } else {
      {
#line 883
      tmp___252 = __dyc_funcallvar_44;
#line 883
      tmp___247 = tmp___252;
      }
    }
#line 883
    tmp___237 = tmp___247;
  } else {
    {
#line 883
    tmp___237 = __dyc_funcallvar_45;
    }
  }
#line 883
  if (tmp___237 == 0) {
    {

#line 887
    tmp___215 = __dyc_funcallvar_46;

#line 888
    mangled += len;
    }
    goto __dyc_dummy_label;
  }
  goto __dyc_dummy_label;
  switch_14_10: /* CIL Label */ 
#line 894
  if (0) {
#line 894
    if (0) {
      {
#line 894
      tmp___295 = __dyc_funcallvar_47;
#line 894
      __s1_len___12 = (unsigned long )tmp___295;
#line 894
      tmp___296 = __dyc_funcallvar_48;
#line 894
      __s2_len___12 = (unsigned long )tmp___296;
      }
#line 894
      if (! ((unsigned long )((void const   *)(mangled + 1)) - (unsigned long )((void const   *)mangled) == 1UL)) {
        goto _L___26;
      } else {
#line 894
        if (__s1_len___12 >= 4UL) {
          _L___26: /* CIL Label */ 
#line 894
          if (! ((unsigned long )((void const   *)("__postblitMFZ" + 1)) - (unsigned long )((void const   *)"__postblitMFZ") == 1UL)) {
#line 894
            tmp___297 = 1;
          } else {
#line 894
            if (__s2_len___12 >= 4UL) {
#line 894
              tmp___297 = 1;
            } else {
#line 894
              tmp___297 = 0;
            }
          }
        } else {
#line 894
          tmp___297 = 0;
        }
      }
#line 894
      if (tmp___297) {
        {
#line 894
        tmp___289 = __dyc_funcallvar_49;
        }
      } else {
        {
#line 894
        tmp___294 = __dyc_funcallvar_50;
#line 894
        tmp___289 = tmp___294;
        }
      }
    } else {
      {
#line 894
      tmp___294 = __dyc_funcallvar_51;
#line 894
      tmp___289 = tmp___294;
      }
    }
#line 894
    tmp___279 = tmp___289;
  } else {
    {
#line 894
    tmp___279 = __dyc_funcallvar_52;
    }
  }
#line 894
  if (tmp___279 == 0) {
    {

#line 898
    mangled += len + 3L;
    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(tmp___45);
  __dyc_printpre_byte(tmp___46);
  __dyc_printpre_byte(__s1_len___2);
  __dyc_printpre_byte(__s2_len___2);
  __dyc_printpre_byte(__s1_len___4);
  __dyc_printpre_byte(__s2_len___4);
  __dyc_printpre_byte(__s1_len___6);
  __dyc_printpre_byte(__s2_len___6);
  __dyc_printpre_byte(tmp___215);
  __dyc_printpre_byte(__s1_len___10);
  __dyc_printpre_byte(__s2_len___10);
  __dyc_printpre_byte(__s1_len___12);
  __dyc_printpre_byte(__s2_len___12);
  __dyc_print_ptr__char(mangled);
}
}
