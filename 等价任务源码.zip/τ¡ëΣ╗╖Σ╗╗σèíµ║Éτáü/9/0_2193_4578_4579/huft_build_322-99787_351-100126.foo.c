#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned int i ;
  unsigned int j ;
  int l ;
  unsigned int *p ;
  struct __anonstruct_stk_24 *stk ;
  unsigned int *c ;
  unsigned int *v ;
  unsigned int *x ;
  struct huft **u ;
  int ret ;
  unsigned int *b ;
  unsigned int n ;
  struct huft **t ;
  int *m ;

  {
  stk = __dyc_read_ptr__comp_61__anonstruct_stk_24();
  b = __dyc_read_ptr__int();
  n = (unsigned int )__dyc_readpre_byte();
  t = __dyc_read_ptr__ptr__comp_59huft();
  m = (int *)__dyc_read_ptr__int();
  i = 0;
  j = 0;
  l = 0;
  p = 0;
  c = 0;
  v = 0;
  x = 0;
  u = 0;
  ret = 0;
#line 322
  if ((unsigned long )stk == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }
#line 325
  c = stk->c;
#line 326
  v = stk->v;
#line 327
  x = stk->x;
#line 328
  u = stk->u;

#line 332
  p = b;
#line 332
  i = n;
#line 333
  while (1) {
    while_0_continue: /* CIL Label */ ;
#line 336
    (*(c + *p)) ++;
#line 337
    p ++;
#line 333
    i --;
#line 333
    if (! i) {
      goto while_0_break;
    }
  }
  while_0_break: /* CIL Label */ ;
#line 339
  if (*(c + 0) == n) {
#line 341
    *t = (struct huft *)((void *)0);
#line 342
    *m = 0;
#line 343
    ret = 2;
    goto __dyc_dummy_label;
  }
#line 350
  l = *m;
#line 351
  j = 1U;
#line 351
  while (1) {
    while_1_continue: /* CIL Label */ ;
#line 351
    if (! (j <= 16U)) {
      goto __dyc_dummy_label;
    }
#line 352
    if (*(c + j)) {
      goto __dyc_dummy_label;
    }
#line 351
    j ++;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(l);
  __dyc_print_ptr__int(p);
  __dyc_print_ptr__int(v);
  __dyc_print_ptr__int(x);
  __dyc_print_ptr__ptr__comp_59huft(u);
  __dyc_printpre_byte(ret);
}
}
