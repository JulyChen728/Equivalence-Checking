#include <dycfoo.h>
#include "../inftrees.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned int len ;
  unsigned int min ;
  unsigned int max ;
  unsigned int root ;
  int left ;
  code this ;
  unsigned short count[16] ;
  code *tmp ;
  code *tmp___0 ;
  code **table ;
  unsigned int *bits ;

  {
  max = (unsigned int )__dyc_readpre_byte();
  root = (unsigned int )__dyc_readpre_byte();
  table = __dyc_read_ptr__ptr__typdef_code();
  bits = __dyc_read_ptr__int();
  len = 0;
  min = 0;
  left = 0;
  memset(& this, 0, sizeof(code ));
  tmp = 0;
  tmp___0 = 0;
#line 100
  while (1) {
    while_2_continue: /* CIL Label */ ;
#line 100
    if (! (max >= 1U)) {
      goto while_2_break;
    }
#line 101
    if ((int )count[max] != 0) {
      goto while_2_break;
    }
#line 100
    max --;
  }
  while_2_break: /* CIL Label */ ;
#line 102
  if (root > max) {
#line 102
    root = max;
  }
#line 103
  if (max == 0U) {
#line 104
    this.op = (unsigned char)64;
#line 105
    this.bits = (unsigned char)1;
#line 106
    this.val = (unsigned short)0;
#line 107
    tmp = *table;
#line 107
    (*table) ++;
#line 107
    *tmp = this;
#line 108
    tmp___0 = *table;
#line 108
    (*table) ++;
#line 108
    *tmp___0 = this;
#line 109
    *bits = 1U;
    goto __dyc_dummy_label;
  }
#line 112
  min = 1U;
#line 112
  while (1) {
    while_3_continue: /* CIL Label */ ;
#line 112
    if (! (min <= 15U)) {
      goto while_3_break;
    }
#line 113
    if ((int )count[min] != 0) {
      goto while_3_break;
    }
#line 112
    min ++;
  }
  while_3_break: /* CIL Label */ ;
#line 114
  if (root < min) {
#line 114
    root = min;
  }
#line 117
  left = 1;
#line 118
  len = 1U;
#line 118
  while (1) {
    while_4_continue: /* CIL Label */ ;
#line 118
    if (! (len <= 15U)) {
      goto __dyc_dummy_label;
    }
#line 119
    left <<= 1;
#line 120
    left -= (int )count[len];
#line 121
    if (left < 0) {
      goto __dyc_dummy_label;
    }
#line 118
    len ++;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(root);
  __dyc_printpre_byte(left);
}
}
