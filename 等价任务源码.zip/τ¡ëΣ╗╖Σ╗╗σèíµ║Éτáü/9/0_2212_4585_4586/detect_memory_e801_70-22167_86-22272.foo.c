#include <dycfoo.h>
#include "../memory.i.hd.c.h"
void __dyc_foo(void) 
{ struct boot_params boot_params ;
  u16 ax ;
  u16 bx ;
  u16 cx ;
  u16 dx ;
  u8 err ;

  {
  ax = (u16 )__dyc_readpre_byte();
  cx = (u16 )__dyc_readpre_byte();
  dx = (u16 )__dyc_readpre_byte();
  err = (u8 )__dyc_readpre_byte();
  memset(& boot_params, 0, sizeof(struct boot_params ));
  bx = 0;
#line 70
  if (err) {
    goto __dyc_dummy_label;
  }
#line 74
  if (cx) {
#line 75
    ax = cx;
#line 76
    bx = dx;
  } else {
#line 74
    if (dx) {
#line 75
      ax = cx;
#line 76
      bx = dx;
    }
  }
#line 79
  if ((int )ax > 15360) {
    goto __dyc_dummy_label;
  }
#line 86
  if ((int )ax == 15360) {
#line 86
    boot_params.alt_mem_k = (unsigned int )(((int )dx << 6) + (int )ax);
  } else {
#line 86
    boot_params.alt_mem_k = (unsigned int )ax;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_comp_35boot_params(boot_params);
  __dyc_printpre_byte(bx);
}
}
