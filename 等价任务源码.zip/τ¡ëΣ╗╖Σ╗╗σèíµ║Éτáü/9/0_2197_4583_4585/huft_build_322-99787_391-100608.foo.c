#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ int g ;
  unsigned int i ;
  unsigned int j ;
  int k ;
  int l ;
  unsigned int *p ;
  unsigned int *xp ;
  int y ;
  struct __anonstruct_stk_24 *stk ;
  unsigned int *c ;
  unsigned int *v ;
  unsigned int *x ;
  struct huft **u ;
  int ret ;
  unsigned int *tmp___0 ;
  unsigned int *tmp___1 ;
  unsigned int *b ;
  unsigned int n ;
  struct huft **t ;
  int *m ;

  {
  stk = __dyc_read_ptr__comp_61__anonstruct_stk_24();
  b = __dyc_read_ptr__int();
  n = (unsigned int )__dyc_readpre_byte();
  t = __dyc_read_ptr__ptr__comp_59huft();
  m = (int *)__dyc_read_ptr__int();
  g = 0;
  i = 0;
  j = 0;
  k = 0;
  l = 0;
  p = 0;
  xp = 0;
  y = 0;
  c = 0;
  v = 0;
  x = 0;
  u = 0;
  ret = 0;
  tmp___0 = 0;
  tmp___1 = 0;
#line 322
  if ((unsigned long )stk == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }
#line 325
  c = stk->c;
#line 326
  v = stk->v;
#line 327
  x = stk->x;
#line 328
  u = stk->u;

#line 332
  p = b;
#line 332
  i = n;
#line 333
  while (1) {
    while_0_continue: /* CIL Label */ ;
#line 336
    (*(c + *p)) ++;
#line 337
    p ++;
#line 333
    i --;
#line 333
    if (! i) {
      goto while_0_break;
    }
  }
  while_0_break: /* CIL Label */ ;
#line 339
  if (*(c + 0) == n) {
#line 341
    *t = (struct huft *)((void *)0);
#line 342
    *m = 0;
#line 343
    ret = 2;
    goto __dyc_dummy_label;
  }
#line 350
  l = *m;
#line 351
  j = 1U;
#line 351
  while (1) {
    while_1_continue: /* CIL Label */ ;
#line 351
    if (! (j <= 16U)) {
      goto while_1_break;
    }
#line 352
    if (*(c + j)) {
      goto while_1_break;
    }
#line 351
    j ++;
  }
  while_1_break: /* CIL Label */ ;
#line 354
  k = (int )j;
#line 355
  if ((unsigned int )l < j) {
#line 356
    l = (int )j;
  }
#line 357
  i = 16U;
#line 357
  while (1) {
    while_2_continue: /* CIL Label */ ;
#line 357
    if (! i) {
      goto while_2_break;
    }
#line 358
    if (*(c + i)) {
      goto while_2_break;
    }
#line 357
    i --;
  }
  while_2_break: /* CIL Label */ ;
#line 360
  g = (int )i;
#line 361
  if ((unsigned int )l > i) {
#line 362
    l = (int )i;
  }
#line 363
  *m = l;
#line 368
  y = 1 << j;
#line 368
  while (1) {
    while_3_continue: /* CIL Label */ ;
#line 368
    if (! (j < i)) {
      goto while_3_break;
    }
#line 369
    y = (int )((unsigned int )y - *(c + j));
#line 369
    if (y < 0) {
#line 370
      ret = 2;
      goto __dyc_dummy_label;
    }
#line 368
    j ++;
#line 368
    y <<= 1;
  }
  while_3_break: /* CIL Label */ ;
#line 373
  y = (int )((unsigned int )y - *(c + i));
#line 373
  if (y < 0) {
#line 374
    ret = 2;
    goto __dyc_dummy_label;
  }
#line 377
  *(c + i) += (unsigned int )y;
#line 382
  j = 0U;
#line 382
  *(x + 1) = j;
#line 383
  p = c + 1;
#line 383
  xp = x + 2;
#line 384
  while (1) {
    while_4_continue: /* CIL Label */ ;
#line 384
    i --;
#line 384
    if (! i) {
      goto while_4_break;
    }
#line 385
    tmp___0 = xp;
#line 385
    xp ++;
#line 385
    tmp___1 = p;
#line 385
    p ++;
#line 385
    j += *tmp___1;
#line 385
    *tmp___0 = j;
  }
  while_4_break: /* CIL Label */ ;
#line 391
  p = b;
#line 391
  i = 0U;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(g);
  __dyc_printpre_byte(i);
  __dyc_printpre_byte(k);
  __dyc_print_ptr__int(p);
  __dyc_print_ptr__int(xp);
  __dyc_print_ptr__int(v);
  __dyc_print_ptr__int(x);
  __dyc_print_ptr__ptr__comp_59huft(u);
  __dyc_printpre_byte(ret);
}
}
