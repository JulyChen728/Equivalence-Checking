#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ int i ;
  int bl ;
  int bd ;
  unsigned int *l ;
  int tmp___0 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;

  {
  l = __dyc_read_ptr__int();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  i = 0;
  bl = 0;
  bd = 0;
  tmp___0 = 0;
#line 749
  bl = 7;
#line 750
  i = __dyc_funcallvar_2;
#line 750
  if (i != 0) {
    {

    }
    goto __dyc_dummy_label;
  }
#line 756
  i = 0;
#line 756
  while (1) {
    while_33_continue: /* CIL Label */ ;
#line 756
    if (! (i < 30)) {
      goto while_33_break;
    }
#line 757
    *(l + i) = 5U;
#line 756
    i ++;
  }
  while_33_break: /* CIL Label */ ;
#line 758
  bd = 5;
#line 759
  i = __dyc_funcallvar_3;
#line 759
  if (i > 1) {
    {


    }
    goto __dyc_dummy_label;
  }
#line 770
  tmp___0 = __dyc_funcallvar_4;
#line 770
  if (tmp___0) {
    {

    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(bl);
  __dyc_printpre_byte(bd);
}
}
