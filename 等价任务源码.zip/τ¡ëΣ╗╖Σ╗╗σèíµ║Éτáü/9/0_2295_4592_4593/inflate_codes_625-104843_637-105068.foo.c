#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ uch *window ;
  unsigned int outcnt ;
  unsigned int e ;
  unsigned int d ;
  unsigned int w ;
  unsigned int tmp___26 ;
  unsigned int tmp___27 ;

  {
  window = __dyc_read_ptr__typdef_uch();
  e = (unsigned int )__dyc_readpre_byte();
  d = (unsigned int )__dyc_readpre_byte();
  w = (unsigned int )__dyc_readpre_byte();
  outcnt = 0;
  tmp___26 = 0;
  tmp___27 = 0;
#line 625
  if (w - d >= e) {
    {

#line 628
    w += e;
#line 629
    d += e;
    }
  } else {
    {
#line 633
    while (1) {
      while_24_continue: /* CIL Label */ ;
#line 634
      tmp___26 = w;
#line 634
      w ++;
#line 634
      tmp___27 = d;
#line 634
      d ++;
#line 634
      *(window + tmp___26) = *(window + tmp___27);
#line 633
      e --;
#line 633
      if (! e) {
        goto while_24_break;
      }
    }
    while_24_break: /* CIL Label */ ;
    }
  }
#line 637
  if (w == 2147483648U) {
    {
#line 639
    outcnt = w;

#line 640
    w = 0U;
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(outcnt);
  __dyc_printpre_byte(d);
  __dyc_printpre_byte(w);
}
}
