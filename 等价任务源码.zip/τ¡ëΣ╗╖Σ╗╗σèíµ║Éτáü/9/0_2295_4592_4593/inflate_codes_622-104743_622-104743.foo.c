#include <dycfoo.h>
#include "../misc_64.i.hd.c.h"
void __dyc_foo(void) 
{ uch *window ;
  unsigned int outcnt ;
  unsigned int e ;
  unsigned int n ;
  unsigned int d ;
  unsigned int w ;
  unsigned int tmp___25 ;
  unsigned int tmp___26 ;
  unsigned int tmp___27 ;

  {
  window = __dyc_read_ptr__typdef_uch();
  n = (unsigned int )__dyc_readpre_byte();
  d = (unsigned int )__dyc_readpre_byte();
  w = (unsigned int )__dyc_readpre_byte();
  outcnt = 0;
  e = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  tmp___27 = 0;
#line 622
  while (1) {
    while_23_continue: /* CIL Label */ ;
#line 623
    d &= 2147483647U;
#line 623
    if (d > w) {
#line 623
      tmp___25 = d;
    } else {
#line 623
      tmp___25 = w;
    }
#line 623
    e = 2147483648U - tmp___25;
#line 623
    if (e > n) {
#line 623
      e = n;
    } else {
#line 623
      e = e;
    }
#line 623
    n -= e;
#line 625
    if (w - d >= e) {
      {

#line 628
      w += e;
#line 629
      d += e;
      }
    } else {
      {
#line 633
      while (1) {
        while_24_continue: /* CIL Label */ ;
#line 634
        tmp___26 = w;
#line 634
        w ++;
#line 634
        tmp___27 = d;
#line 634
        d ++;
#line 634
        *(window + tmp___26) = *(window + tmp___27);
#line 633
        e --;
#line 633
        if (! e) {
          goto while_24_break;
        }
      }
      while_24_break: /* CIL Label */ ;
      }
    }
#line 637
    if (w == 2147483648U) {
      {
#line 639
      outcnt = w;

#line 640
      w = 0U;
      }
    }
#line 622
    if (! n) {
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(outcnt);
  __dyc_printpre_byte(d);
  __dyc_printpre_byte(w);
}
}
