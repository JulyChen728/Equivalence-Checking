#include <dycfoo.h>
#include "../edd.i.hd.c.h"
void __dyc_foo(void) 
{ struct boot_params boot_params ;
  int do_mbr ;
  int do_edd ;
  struct edd_info *edp ;
  u32 *mbrptr ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;

  {
  boot_params = __dyc_read_comp_35boot_params();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  do_mbr = 0;
  do_edd = 0;
  edp = 0;
  mbrptr = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
#line 130
  do_mbr = 1;
#line 131
  do_edd = 1;
#line 136
  tmp___2 = __dyc_funcallvar_1;
#line 136
  if (tmp___2 > 0) {
    {
#line 137
    tmp___0 = __dyc_funcallvar_2;
    }
#line 137
    if (tmp___0) {
      {
#line 137
      tmp___1 = __dyc_funcallvar_3;
      }
#line 137
      if (tmp___1) {
        {
#line 139
        tmp = __dyc_funcallvar_4;
        }
#line 139
        if (! tmp) {
#line 140
          do_edd = 0;
        }
      } else {
#line 138
        do_mbr = 0;
      }
    } else {
#line 138
      do_mbr = 0;
    }
  }
#line 143
  edp = boot_params.eddbuf;
#line 144
  mbrptr = boot_params.edd_mbr_sig_buffer;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(do_mbr);
  __dyc_printpre_byte(do_edd);
  __dyc_print_ptr__comp_23edd_info(edp);
  __dyc_print_ptr__typdef_u32(mbrptr);
}
}
