#include <dycfoo.h>
#include "../inftrees.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned short const   lbase[31] ;
  unsigned short const   lext[31] ;
  unsigned short const   dbase[32] ;
  unsigned short const   dext[32] ;
  unsigned short const   *base ;
  unsigned short const   *extra ;
  int end ;
  unsigned short *work ;

  {
  work = __dyc_read_ptr__short();
  base = 0;
  extra = 0;
  end = 0;
  switch_7_0: /* CIL Label */ 
#line 170
  extra = (unsigned short const   *)work;
#line 170
  base = extra;
#line 171
  end = 19;
  goto __dyc_dummy_label;
  switch_7_1: /* CIL Label */ 
#line 174
  base = lbase;
#line 175
  base -= 257;
#line 176
  extra = lext;
#line 177
  extra -= 257;
#line 178
  end = 256;
  goto __dyc_dummy_label;
  switch_7_default: /* CIL Label */ 
#line 181
  base = dbase;
#line 182
  extra = dext;
#line 183
  end = -1;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__short(base);
  __dyc_print_ptr__short(extra);
  __dyc_printpre_byte(end);
}
}
