#include <dycfoo.h>
#include "../cp-demangle.i.hd.c.h"
void __dyc_foo(void) 
{ int tmp___0 ;
  struct demangle_component *tmp___2 ;
  struct demangle_component *tmp___3 ;
  struct demangle_component *tmp___4 ;
  struct demangle_component *tmp___5 ;
  struct demangle_component *tmp___6 ;
  struct demangle_component *tmp___7 ;
  struct demangle_component *tmp___8 ;
  struct demangle_component *tmp___9 ;
  int tmp___10 ;
  struct demangle_component *tmp___11 ;
  struct demangle_component *tmp___12 ;
  int tmp___13 ;
  struct demangle_component *tmp___14 ;
  struct demangle_component *tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  struct demangle_component *tmp___18 ;
  struct demangle_component *tmp___19 ;
  struct demangle_component *derived_type ;
  int offset ;
  struct demangle_component *base_type ;
  int tmp___20 ;
  struct demangle_component *tmp___21 ;
  struct demangle_component *tmp___22 ;
  struct demangle_component *tmp___23 ;
  struct demangle_component *tmp___24 ;
  struct demangle_component *tmp___25 ;
  struct demangle_component *tmp___26 ;
  struct demangle_component *tmp___27 ;
  struct demangle_component *tmp___28 ;
  struct demangle_component *tmp___29 ;
  struct demangle_component *tmp___30 ;
  struct demangle_component *tmp___31 ;
  int tmp___33 ;
  char const   *tmp___34 ;
  struct demangle_component *tmp___35 ;
  struct demangle_component *tmp___36 ;
  struct demangle_component *name ;
  struct demangle_component *tmp___37 ;
  struct demangle_component *tmp___38 ;
  struct demangle_component *tmp___39 ;
  struct demangle_component *tmp___40 ;
  struct demangle_component *tmp___41 ;
  int tmp___43 ;
  char const   *tmp___44 ;
  struct demangle_component *tmp___45 ;
  struct demangle_component *tmp___46 ;
  struct demangle_component *tmp___47 ;
  struct demangle_component *tmp___48 ;
  struct demangle_component *tmp___49 ;
  int tmp___50 ;
  struct d_info *di ;
  struct demangle_component *__dyc_funcallvar_1 ;
  struct demangle_component *__dyc_funcallvar_2 ;
  struct demangle_component *__dyc_funcallvar_3 ;
  struct demangle_component *__dyc_funcallvar_4 ;
  struct demangle_component *__dyc_funcallvar_5 ;
  struct demangle_component *__dyc_funcallvar_6 ;
  struct demangle_component *__dyc_funcallvar_7 ;
  struct demangle_component *__dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  struct demangle_component *__dyc_funcallvar_10 ;
  struct demangle_component *__dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  struct demangle_component *__dyc_funcallvar_13 ;
  struct demangle_component *__dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  struct demangle_component *__dyc_funcallvar_17 ;
  struct demangle_component *__dyc_funcallvar_18 ;
  struct demangle_component *__dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  struct demangle_component *__dyc_funcallvar_21 ;
  struct demangle_component *__dyc_funcallvar_22 ;
  struct demangle_component *__dyc_funcallvar_23 ;
  struct demangle_component *__dyc_funcallvar_24 ;
  struct demangle_component *__dyc_funcallvar_25 ;
  struct demangle_component *__dyc_funcallvar_26 ;
  struct demangle_component *__dyc_funcallvar_27 ;
  struct demangle_component *__dyc_funcallvar_28 ;
  struct demangle_component *__dyc_funcallvar_29 ;
  struct demangle_component *__dyc_funcallvar_30 ;
  struct demangle_component *__dyc_funcallvar_31 ;
  struct demangle_component *__dyc_funcallvar_32 ;
  struct demangle_component *__dyc_funcallvar_33 ;
  struct demangle_component *__dyc_funcallvar_34 ;
  struct demangle_component *__dyc_funcallvar_35 ;
  struct demangle_component *__dyc_funcallvar_36 ;
  struct demangle_component *__dyc_funcallvar_37 ;
  struct demangle_component *__dyc_funcallvar_38 ;
  struct demangle_component *__dyc_funcallvar_39 ;
  struct demangle_component *__dyc_funcallvar_40 ;
  struct demangle_component *__dyc_funcallvar_41 ;
  struct demangle_component *__dyc_funcallvar_42 ;
  struct demangle_component *__dyc_funcallvar_43 ;
  struct demangle_component *__dyc_funcallvar_44 ;

  {
  tmp___0 = __dyc_readpre_byte();
  di = __dyc_read_ptr__comp_60d_info();
  __dyc_funcallvar_1 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_2 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_3 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_4 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_5 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_6 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_7 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_8 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_11 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_14 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_18 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_19 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_22 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_23 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_24 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_25 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_26 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_27 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_28 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_29 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_30 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_31 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_32 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_33 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_34 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_35 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_36 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_37 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_38 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_39 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_40 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_41 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_42 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_43 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_44 = __dyc_read_ptr__comp_46demangle_component();
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  tmp___17 = 0;
  tmp___18 = 0;
  tmp___19 = 0;
  derived_type = 0;
  offset = 0;
  base_type = 0;
  tmp___20 = 0;
  tmp___21 = 0;
  tmp___22 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  tmp___27 = 0;
  tmp___28 = 0;
  tmp___29 = 0;
  tmp___30 = 0;
  tmp___31 = 0;
  tmp___33 = 0;
  tmp___34 = 0;
  tmp___35 = 0;
  tmp___36 = 0;
  name = 0;
  tmp___37 = 0;
  tmp___38 = 0;
  tmp___39 = 0;
  tmp___40 = 0;
  tmp___41 = 0;
  tmp___43 = 0;
  tmp___44 = 0;
  tmp___45 = 0;
  tmp___46 = 0;
  tmp___47 = 0;
  tmp___48 = 0;
  tmp___49 = 0;
  tmp___50 = 0;
#line 2050
  if (tmp___0 == 86) {
    goto switch_16_86;
  } else {
#line 2054
    if (tmp___0 == 84) {
      goto switch_16_84;
    } else {
#line 2058
      if (tmp___0 == 73) {
        goto switch_16_73;
      } else {
#line 2061
        if (tmp___0 == 83) {
          goto switch_16_83;
        } else {
#line 2065
          if (tmp___0 == 104) {
            goto switch_16_104;
          } else {
#line 2071
            if (tmp___0 == 118) {
              goto switch_16_118;
            } else {
#line 2077
              if (tmp___0 == 99) {
                goto switch_16_99;
              } else {
#line 2085
                if (tmp___0 == 67) {
                  goto switch_16_67;
                } else {
#line 2105
                  if (tmp___0 == 70) {
                    goto switch_16_70;
                  } else {
#line 2108
                    if (tmp___0 == 74) {
                      goto switch_16_74;
                    } else {
#line 2112
                      if (tmp___0 == 72) {
                        goto switch_16_72;
                      } else {
#line 2116
                        if (tmp___0 == 87) {
                          goto switch_16_87;
                        } else {
#line 2120
                          if (tmp___0 == 65) {
                            goto switch_16_65;
                          } else {
                            {
                            goto switch_16_default;
#line 2048
                            if (0) {
                              switch_16_86: /* CIL Label */ 
                              {
#line 2051
                              di->expansion -= 5;
#line 2052
                              tmp___2 = __dyc_funcallvar_1;
#line 2052
                              tmp___3 = __dyc_funcallvar_2;
                              }
                              goto __dyc_dummy_label;
                              switch_16_84: /* CIL Label */ 
                              {
#line 2055
                              di->expansion -= 10;
#line 2056
                              tmp___4 = __dyc_funcallvar_3;
#line 2056
                              tmp___5 = __dyc_funcallvar_4;
                              }
                              goto __dyc_dummy_label;
                              switch_16_73: /* CIL Label */ 
                              {
#line 2059
                              tmp___6 = __dyc_funcallvar_5;
#line 2059
                              tmp___7 = __dyc_funcallvar_6;
                              }
                              goto __dyc_dummy_label;
                              switch_16_83: /* CIL Label */ 
                              {
#line 2062
                              tmp___8 = __dyc_funcallvar_7;
#line 2062
                              tmp___9 = __dyc_funcallvar_8;
                              }
                              goto __dyc_dummy_label;
                              switch_16_104: /* CIL Label */ 
                              {
#line 2066
                              tmp___10 = __dyc_funcallvar_9;
                              }
#line 2066
                              if (! tmp___10) {
                                goto __dyc_dummy_label;
                              }
                              {
#line 2068
                              tmp___11 = __dyc_funcallvar_10;
#line 2068
                              tmp___12 = __dyc_funcallvar_11;
                              }
                              goto __dyc_dummy_label;
                              switch_16_118: /* CIL Label */ 
                              {
#line 2072
                              tmp___13 = __dyc_funcallvar_12;
                              }
#line 2072
                              if (! tmp___13) {
                                goto __dyc_dummy_label;
                              }
                              {
#line 2074
                              tmp___14 = __dyc_funcallvar_13;
#line 2074
                              tmp___15 = __dyc_funcallvar_14;
                              }
                              goto __dyc_dummy_label;
                              switch_16_99: /* CIL Label */ 
                              {
#line 2078
                              tmp___16 = __dyc_funcallvar_15;
                              }
#line 2078
                              if (! tmp___16) {
                                goto __dyc_dummy_label;
                              }
                              {
#line 2080
                              tmp___17 = __dyc_funcallvar_16;
                              }
#line 2080
                              if (! tmp___17) {
                                goto __dyc_dummy_label;
                              }
                              {
#line 2082
                              tmp___18 = __dyc_funcallvar_17;
#line 2082
                              tmp___19 = __dyc_funcallvar_18;
                              }
                              goto __dyc_dummy_label;
                              switch_16_67: /* CIL Label */ 
                              {
#line 2091
                              derived_type = __dyc_funcallvar_19;
#line 2092
                              offset = __dyc_funcallvar_20;
                              }
#line 2093
                              if (offset < 0) {
                                goto __dyc_dummy_label;
                              }
#line 2095
                              if ((int const   )*(di->n) == 95) {
#line 2095
                                (di->n) ++;
#line 2095
                                tmp___20 = 1;
                              } else {
#line 2095
                                tmp___20 = 0;
                              }
#line 2095
                              if (! tmp___20) {
                                goto __dyc_dummy_label;
                              }
                              {
#line 2097
                              base_type = __dyc_funcallvar_21;
#line 2100
                              di->expansion += 5;
#line 2101
                              tmp___21 = __dyc_funcallvar_22;
                              }
                              goto __dyc_dummy_label;
                              switch_16_70: /* CIL Label */ 
                              {
#line 2106
                              tmp___22 = __dyc_funcallvar_23;
#line 2106
                              tmp___23 = __dyc_funcallvar_24;
                              }
                              goto __dyc_dummy_label;
                              switch_16_74: /* CIL Label */ 
                              {
#line 2109
                              tmp___24 = __dyc_funcallvar_25;
#line 2109
                              tmp___25 = __dyc_funcallvar_26;
                              }
                              goto __dyc_dummy_label;
                              switch_16_72: /* CIL Label */ 
                              {
#line 2113
                              tmp___26 = __dyc_funcallvar_27;
#line 2113
                              tmp___27 = __dyc_funcallvar_28;
                              }
                              goto __dyc_dummy_label;
                              switch_16_87: /* CIL Label */ 
                              {
#line 2117
                              tmp___28 = __dyc_funcallvar_29;
#line 2117
                              tmp___29 = __dyc_funcallvar_30;
                              }
                              goto __dyc_dummy_label;
                              switch_16_65: /* CIL Label */ 
                              {
#line 2121
                              tmp___30 = __dyc_funcallvar_31;
#line 2121
                              tmp___31 = __dyc_funcallvar_32;
                              }
                              goto __dyc_dummy_label;
                              switch_16_default: /* CIL Label */ ;
                              goto __dyc_dummy_label;
                            } else {
                              switch_16_break: /* CIL Label */ ;
                            }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
#line 2128
  if ((int const   )*(di->n) == 71) {
#line 2128
    (di->n) ++;
#line 2128
    tmp___50 = 1;
  } else {
#line 2128
    tmp___50 = 0;
  }
#line 2128
  if (tmp___50) {
#line 2130
    if ((int const   )*(di->n) == 0) {
#line 2130
      tmp___33 = '\000';
    } else {
#line 2130
      tmp___34 = di->n;
#line 2130
      (di->n) ++;
#line 2130
      tmp___33 = (int )*tmp___34;
    }
#line 2132
    if (tmp___33 == 86) {
      goto switch_17_86;
    } else {
#line 2136
      if (tmp___33 == 82) {
        goto switch_17_82;
      } else {
#line 2143
        if (tmp___33 == 65) {
          goto switch_17_65;
        } else {
#line 2147
          if (tmp___33 == 84) {
            goto switch_17_84;
          } else {
#line 2164
            if (tmp___33 == 114) {
              goto switch_17_114;
            } else {
              {
              goto switch_17_default;
#line 2130
              if (0) {
                switch_17_86: /* CIL Label */ 
                {
#line 2133
                tmp___35 = __dyc_funcallvar_33;
#line 2133
                tmp___36 = __dyc_funcallvar_34;
                }
                goto __dyc_dummy_label;
                switch_17_82: /* CIL Label */ 
                {
#line 2138
                tmp___37 = __dyc_funcallvar_35;
#line 2138
                name = tmp___37;
#line 2139
                tmp___38 = __dyc_funcallvar_36;
#line 2139
                tmp___39 = __dyc_funcallvar_37;
                }
                goto __dyc_dummy_label;
                switch_17_65: /* CIL Label */ 
                {
#line 2144
                tmp___40 = __dyc_funcallvar_38;
#line 2144
                tmp___41 = __dyc_funcallvar_39;
                }
                goto __dyc_dummy_label;
                switch_17_84: /* CIL Label */ 
#line 2148
                if ((int const   )*(di->n) == 0) {
#line 2148
                  tmp___43 = '\000';
                } else {
#line 2148
                  tmp___44 = di->n;
#line 2148
                  (di->n) ++;
#line 2148
                  tmp___43 = (int )*tmp___44;
                }
#line 2150
                if (tmp___43 == 110) {
                  goto switch_18_110;
                } else {
#line 2159
                  if (tmp___43 == 116) {
                    goto switch_18_116;
                  } else {
                    {
                    goto switch_18_default;
#line 2148
                    if (0) {
                      switch_18_110: /* CIL Label */ 
                      {
#line 2151
                      tmp___45 = __dyc_funcallvar_40;
#line 2151
                      tmp___46 = __dyc_funcallvar_41;
                      }
                      goto __dyc_dummy_label;
                      switch_18_default: /* CIL Label */ ;
                      switch_18_116: /* CIL Label */ 
                      {
#line 2160
                      tmp___47 = __dyc_funcallvar_42;
#line 2160
                      tmp___48 = __dyc_funcallvar_43;
                      }
                      goto __dyc_dummy_label;
                    } else {
                      switch_18_break: /* CIL Label */ ;
                    }
                    }
                  }
                }
                switch_17_114: /* CIL Label */ 
                {
#line 2165
                tmp___49 = __dyc_funcallvar_44;
                }
                goto __dyc_dummy_label;
                switch_17_default: /* CIL Label */ ;
                goto __dyc_dummy_label;
              } else {
                switch_17_break: /* CIL Label */ ;
              }
              }
            }
          }
        }
      }
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__comp_46demangle_component(tmp___2);
  __dyc_print_ptr__comp_46demangle_component(tmp___3);
  __dyc_print_ptr__comp_46demangle_component(tmp___4);
  __dyc_print_ptr__comp_46demangle_component(tmp___5);
  __dyc_print_ptr__comp_46demangle_component(tmp___6);
  __dyc_print_ptr__comp_46demangle_component(tmp___7);
  __dyc_print_ptr__comp_46demangle_component(tmp___8);
  __dyc_print_ptr__comp_46demangle_component(tmp___9);
  __dyc_print_ptr__comp_46demangle_component(tmp___11);
  __dyc_print_ptr__comp_46demangle_component(tmp___12);
  __dyc_print_ptr__comp_46demangle_component(tmp___14);
  __dyc_print_ptr__comp_46demangle_component(tmp___15);
  __dyc_print_ptr__comp_46demangle_component(tmp___18);
  __dyc_print_ptr__comp_46demangle_component(tmp___19);
  __dyc_print_ptr__comp_46demangle_component(derived_type);
  __dyc_print_ptr__comp_46demangle_component(base_type);
  __dyc_print_ptr__comp_46demangle_component(tmp___21);
  __dyc_print_ptr__comp_46demangle_component(tmp___22);
  __dyc_print_ptr__comp_46demangle_component(tmp___23);
  __dyc_print_ptr__comp_46demangle_component(tmp___24);
  __dyc_print_ptr__comp_46demangle_component(tmp___25);
  __dyc_print_ptr__comp_46demangle_component(tmp___26);
  __dyc_print_ptr__comp_46demangle_component(tmp___27);
  __dyc_print_ptr__comp_46demangle_component(tmp___28);
  __dyc_print_ptr__comp_46demangle_component(tmp___29);
  __dyc_print_ptr__comp_46demangle_component(tmp___30);
  __dyc_print_ptr__comp_46demangle_component(tmp___31);
  __dyc_print_ptr__comp_46demangle_component(tmp___35);
  __dyc_print_ptr__comp_46demangle_component(tmp___36);
  __dyc_print_ptr__comp_46demangle_component(name);
  __dyc_print_ptr__comp_46demangle_component(tmp___38);
  __dyc_print_ptr__comp_46demangle_component(tmp___39);
  __dyc_print_ptr__comp_46demangle_component(tmp___40);
  __dyc_print_ptr__comp_46demangle_component(tmp___41);
  __dyc_print_ptr__comp_46demangle_component(tmp___45);
  __dyc_print_ptr__comp_46demangle_component(tmp___46);
  __dyc_print_ptr__comp_46demangle_component(tmp___47);
  __dyc_print_ptr__comp_46demangle_component(tmp___48);
  __dyc_print_ptr__comp_46demangle_component(tmp___49);
}
}
