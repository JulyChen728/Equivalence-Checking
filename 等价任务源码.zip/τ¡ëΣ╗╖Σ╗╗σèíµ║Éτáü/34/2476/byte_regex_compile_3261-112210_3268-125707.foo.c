#include <dycfoo.h>
#include "../regex.i.hd.c.h"
void __dyc_foo(void) 
{ char str[7] ;
  boolean is_lower ;
  int tmp___151 ;
  boolean is_print ;
  size_t __s1_len___6 ;
  size_t __s2_len___6 ;
  int tmp___169 ;
  int tmp___174 ;
  int tmp___175 ;
  int tmp___176 ;
  int tmp___177 ;
  boolean is_punct ;
  size_t __s1_len___7 ;
  size_t __s2_len___7 ;
  int tmp___187 ;
  int tmp___192 ;
  int tmp___193 ;
  int tmp___194 ;
  int tmp___195 ;
  boolean is_space ;
  size_t __s1_len___8 ;
  size_t __s2_len___8 ;
  int tmp___205 ;
  int tmp___210 ;
  int tmp___211 ;
  int tmp___212 ;
  int tmp___213 ;
  boolean is_upper ;
  size_t __s1_len___9 ;
  size_t __s2_len___9 ;
  int tmp___223 ;
  int tmp___228 ;
  int tmp___229 ;
  int tmp___230 ;
  int tmp___231 ;
  boolean is_xdigit ;
  size_t __s1_len___10 ;
  size_t __s2_len___10 ;
  int tmp___241 ;
  int tmp___246 ;
  int tmp___247 ;
  int tmp___248 ;
  int tmp___249 ;
  size_t __s1_len___11 ;
  size_t __s2_len___11 ;
  int tmp___259 ;
  int tmp___264 ;
  int tmp___265 ;
  int tmp___266 ;
  int tmp___267 ;
  int __dyc_funcallvar_52 ;
  int __dyc_funcallvar_53 ;
  int __dyc_funcallvar_54 ;
  int __dyc_funcallvar_55 ;
  int __dyc_funcallvar_56 ;
  int __dyc_funcallvar_57 ;
  int __dyc_funcallvar_58 ;
  int __dyc_funcallvar_59 ;
  int __dyc_funcallvar_60 ;
  int __dyc_funcallvar_61 ;
  int __dyc_funcallvar_62 ;
  int __dyc_funcallvar_63 ;
  int __dyc_funcallvar_64 ;
  int __dyc_funcallvar_65 ;
  int __dyc_funcallvar_66 ;
  int __dyc_funcallvar_67 ;
  int __dyc_funcallvar_68 ;
  int __dyc_funcallvar_69 ;
  int __dyc_funcallvar_70 ;
  int __dyc_funcallvar_71 ;
  int __dyc_funcallvar_72 ;
  int __dyc_funcallvar_73 ;
  int __dyc_funcallvar_74 ;
  int __dyc_funcallvar_75 ;
  int __dyc_funcallvar_76 ;
  int __dyc_funcallvar_77 ;
  int __dyc_funcallvar_78 ;
  int __dyc_funcallvar_79 ;
  int __dyc_funcallvar_80 ;
  int __dyc_funcallvar_81 ;

  {
  tmp___151 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  __dyc_funcallvar_53 = __dyc_readpre_byte();
  __dyc_funcallvar_54 = __dyc_readpre_byte();
  __dyc_funcallvar_55 = __dyc_readpre_byte();
  __dyc_funcallvar_56 = __dyc_readpre_byte();
  __dyc_funcallvar_57 = __dyc_readpre_byte();
  __dyc_funcallvar_58 = __dyc_readpre_byte();
  __dyc_funcallvar_59 = __dyc_readpre_byte();
  __dyc_funcallvar_60 = __dyc_readpre_byte();
  __dyc_funcallvar_61 = __dyc_readpre_byte();
  __dyc_funcallvar_62 = __dyc_readpre_byte();
  __dyc_funcallvar_63 = __dyc_readpre_byte();
  __dyc_funcallvar_64 = __dyc_readpre_byte();
  __dyc_funcallvar_65 = __dyc_readpre_byte();
  __dyc_funcallvar_66 = __dyc_readpre_byte();
  __dyc_funcallvar_67 = __dyc_readpre_byte();
  __dyc_funcallvar_68 = __dyc_readpre_byte();
  __dyc_funcallvar_69 = __dyc_readpre_byte();
  __dyc_funcallvar_70 = __dyc_readpre_byte();
  __dyc_funcallvar_71 = __dyc_readpre_byte();
  __dyc_funcallvar_72 = __dyc_readpre_byte();
  __dyc_funcallvar_73 = __dyc_readpre_byte();
  __dyc_funcallvar_74 = __dyc_readpre_byte();
  __dyc_funcallvar_75 = __dyc_readpre_byte();
  __dyc_funcallvar_76 = __dyc_readpre_byte();
  __dyc_funcallvar_77 = __dyc_readpre_byte();
  __dyc_funcallvar_78 = __dyc_readpre_byte();
  __dyc_funcallvar_79 = __dyc_readpre_byte();
  __dyc_funcallvar_80 = __dyc_readpre_byte();
  __dyc_funcallvar_81 = __dyc_readpre_byte();
  is_lower = 0;
  is_print = 0;
  __s1_len___6 = 0;
  __s2_len___6 = 0;
  tmp___169 = 0;
  tmp___174 = 0;
  tmp___175 = 0;
  tmp___176 = 0;
  tmp___177 = 0;
  is_punct = 0;
  __s1_len___7 = 0;
  __s2_len___7 = 0;
  tmp___187 = 0;
  tmp___192 = 0;
  tmp___193 = 0;
  tmp___194 = 0;
  tmp___195 = 0;
  is_space = 0;
  __s1_len___8 = 0;
  __s2_len___8 = 0;
  tmp___205 = 0;
  tmp___210 = 0;
  tmp___211 = 0;
  tmp___212 = 0;
  tmp___213 = 0;
  is_upper = 0;
  __s1_len___9 = 0;
  __s2_len___9 = 0;
  tmp___223 = 0;
  tmp___228 = 0;
  tmp___229 = 0;
  tmp___230 = 0;
  tmp___231 = 0;
  is_xdigit = 0;
  __s1_len___10 = 0;
  __s2_len___10 = 0;
  tmp___241 = 0;
  tmp___246 = 0;
  tmp___247 = 0;
  tmp___248 = 0;
  tmp___249 = 0;
  __s1_len___11 = 0;
  __s2_len___11 = 0;
  tmp___259 = 0;
  tmp___264 = 0;
  tmp___265 = 0;
  tmp___266 = 0;
  tmp___267 = 0;
#line 3261
  is_lower = (boolean )(tmp___151 == 0);
#line 3262
  if (0) {
    {
#line 3262
    tmp___175 = __dyc_funcallvar_52;
#line 3262
    __s1_len___6 = (unsigned long )tmp___175;
#line 3262
    tmp___176 = __dyc_funcallvar_53;
#line 3262
    __s2_len___6 = (unsigned long )tmp___176;
    }
#line 3262
    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
      goto _L___18;
    } else {
#line 3262
      if (__s1_len___6 >= 4UL) {
        _L___18: /* CIL Label */ 
#line 3262
        if (! ((unsigned long )((void const   *)("print" + 1)) - (unsigned long )((void const   *)"print") == 1UL)) {
#line 3262
          tmp___177 = 1;
        } else {
#line 3262
          if (__s2_len___6 >= 4UL) {
#line 3262
            tmp___177 = 1;
          } else {
#line 3262
            tmp___177 = 0;
          }
        }
      } else {
#line 3262
        tmp___177 = 0;
      }
    }
#line 3262
    if (tmp___177) {
      {
#line 3262
      tmp___169 = __dyc_funcallvar_54;
      }
    } else {
      {
#line 3262
      tmp___174 = __dyc_funcallvar_55;
#line 3262
      tmp___169 = tmp___174;
      }
    }
  } else {
    {
#line 3262
    tmp___174 = __dyc_funcallvar_56;
#line 3262
    tmp___169 = tmp___174;
    }
  }
#line 3262
  is_print = (boolean )(tmp___169 == 0);
#line 3263
  if (0) {
    {
#line 3263
    tmp___193 = __dyc_funcallvar_57;
#line 3263
    __s1_len___7 = (unsigned long )tmp___193;
#line 3263
    tmp___194 = __dyc_funcallvar_58;
#line 3263
    __s2_len___7 = (unsigned long )tmp___194;
    }
#line 3263
    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
      goto _L___20;
    } else {
#line 3263
      if (__s1_len___7 >= 4UL) {
        _L___20: /* CIL Label */ 
#line 3263
        if (! ((unsigned long )((void const   *)("punct" + 1)) - (unsigned long )((void const   *)"punct") == 1UL)) {
#line 3263
          tmp___195 = 1;
        } else {
#line 3263
          if (__s2_len___7 >= 4UL) {
#line 3263
            tmp___195 = 1;
          } else {
#line 3263
            tmp___195 = 0;
          }
        }
      } else {
#line 3263
        tmp___195 = 0;
      }
    }
#line 3263
    if (tmp___195) {
      {
#line 3263
      tmp___187 = __dyc_funcallvar_59;
      }
    } else {
      {
#line 3263
      tmp___192 = __dyc_funcallvar_60;
#line 3263
      tmp___187 = tmp___192;
      }
    }
  } else {
    {
#line 3263
    tmp___192 = __dyc_funcallvar_61;
#line 3263
    tmp___187 = tmp___192;
    }
  }
#line 3263
  is_punct = (boolean )(tmp___187 == 0);
#line 3264
  if (0) {
    {
#line 3264
    tmp___211 = __dyc_funcallvar_62;
#line 3264
    __s1_len___8 = (unsigned long )tmp___211;
#line 3264
    tmp___212 = __dyc_funcallvar_63;
#line 3264
    __s2_len___8 = (unsigned long )tmp___212;
    }
#line 3264
    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
      goto _L___22;
    } else {
#line 3264
      if (__s1_len___8 >= 4UL) {
        _L___22: /* CIL Label */ 
#line 3264
        if (! ((unsigned long )((void const   *)("space" + 1)) - (unsigned long )((void const   *)"space") == 1UL)) {
#line 3264
          tmp___213 = 1;
        } else {
#line 3264
          if (__s2_len___8 >= 4UL) {
#line 3264
            tmp___213 = 1;
          } else {
#line 3264
            tmp___213 = 0;
          }
        }
      } else {
#line 3264
        tmp___213 = 0;
      }
    }
#line 3264
    if (tmp___213) {
      {
#line 3264
      tmp___205 = __dyc_funcallvar_64;
      }
    } else {
      {
#line 3264
      tmp___210 = __dyc_funcallvar_65;
#line 3264
      tmp___205 = tmp___210;
      }
    }
  } else {
    {
#line 3264
    tmp___210 = __dyc_funcallvar_66;
#line 3264
    tmp___205 = tmp___210;
    }
  }
#line 3264
  is_space = (boolean )(tmp___205 == 0);
#line 3265
  if (0) {
    {
#line 3265
    tmp___229 = __dyc_funcallvar_67;
#line 3265
    __s1_len___9 = (unsigned long )tmp___229;
#line 3265
    tmp___230 = __dyc_funcallvar_68;
#line 3265
    __s2_len___9 = (unsigned long )tmp___230;
    }
#line 3265
    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
      goto _L___24;
    } else {
#line 3265
      if (__s1_len___9 >= 4UL) {
        _L___24: /* CIL Label */ 
#line 3265
        if (! ((unsigned long )((void const   *)("upper" + 1)) - (unsigned long )((void const   *)"upper") == 1UL)) {
#line 3265
          tmp___231 = 1;
        } else {
#line 3265
          if (__s2_len___9 >= 4UL) {
#line 3265
            tmp___231 = 1;
          } else {
#line 3265
            tmp___231 = 0;
          }
        }
      } else {
#line 3265
        tmp___231 = 0;
      }
    }
#line 3265
    if (tmp___231) {
      {
#line 3265
      tmp___223 = __dyc_funcallvar_69;
      }
    } else {
      {
#line 3265
      tmp___228 = __dyc_funcallvar_70;
#line 3265
      tmp___223 = tmp___228;
      }
    }
  } else {
    {
#line 3265
    tmp___228 = __dyc_funcallvar_71;
#line 3265
    tmp___223 = tmp___228;
    }
  }
#line 3265
  is_upper = (boolean )(tmp___223 == 0);
#line 3266
  if (0) {
    {
#line 3266
    tmp___247 = __dyc_funcallvar_72;
#line 3266
    __s1_len___10 = (unsigned long )tmp___247;
#line 3266
    tmp___248 = __dyc_funcallvar_73;
#line 3266
    __s2_len___10 = (unsigned long )tmp___248;
    }
#line 3266
    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
      goto _L___26;
    } else {
#line 3266
      if (__s1_len___10 >= 4UL) {
        _L___26: /* CIL Label */ 
#line 3266
        if (! ((unsigned long )((void const   *)("xdigit" + 1)) - (unsigned long )((void const   *)"xdigit") == 1UL)) {
#line 3266
          tmp___249 = 1;
        } else {
#line 3266
          if (__s2_len___10 >= 4UL) {
#line 3266
            tmp___249 = 1;
          } else {
#line 3266
            tmp___249 = 0;
          }
        }
      } else {
#line 3266
        tmp___249 = 0;
      }
    }
#line 3266
    if (tmp___249) {
      {
#line 3266
      tmp___241 = __dyc_funcallvar_74;
      }
    } else {
      {
#line 3266
      tmp___246 = __dyc_funcallvar_75;
#line 3266
      tmp___241 = tmp___246;
      }
    }
  } else {
    {
#line 3266
    tmp___246 = __dyc_funcallvar_76;
#line 3266
    tmp___241 = tmp___246;
    }
  }
#line 3266
  is_xdigit = (boolean )(tmp___241 == 0);
#line 3268
  if (0) {
    {
#line 3268
    tmp___265 = __dyc_funcallvar_77;
#line 3268
    __s1_len___11 = (unsigned long )tmp___265;
#line 3268
    tmp___266 = __dyc_funcallvar_78;
#line 3268
    __s2_len___11 = (unsigned long )tmp___266;
    }
#line 3268
    if (! ((unsigned long )((void const   *)(str + 1)) - (unsigned long )((void const   *)(str)) == 1UL)) {
      goto _L___28;
    } else {
#line 3268
      if (__s1_len___11 >= 4UL) {
        _L___28: /* CIL Label */ 
#line 3268
        if (! ((unsigned long )((void const   *)("alpha" + 1)) - (unsigned long )((void const   *)"alpha") == 1UL)) {
#line 3268
          tmp___267 = 1;
        } else {
#line 3268
          if (__s2_len___11 >= 4UL) {
#line 3268
            tmp___267 = 1;
          } else {
#line 3268
            tmp___267 = 0;
          }
        }
      } else {
#line 3268
        tmp___267 = 0;
      }
    }
#line 3268
    if (tmp___267) {
      {
#line 3268
      tmp___259 = __dyc_funcallvar_79;
      }
    } else {
      {
#line 3268
      tmp___264 = __dyc_funcallvar_80;
#line 3268
      tmp___259 = tmp___264;
      }
    }
  } else {
    {
#line 3268
    tmp___264 = __dyc_funcallvar_81;
#line 3268
    tmp___259 = tmp___264;
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(is_lower);
  __dyc_printpre_byte(is_print);
  __dyc_printpre_byte(__s1_len___6);
  __dyc_printpre_byte(__s2_len___6);
  __dyc_printpre_byte(is_punct);
  __dyc_printpre_byte(__s1_len___7);
  __dyc_printpre_byte(__s2_len___7);
  __dyc_printpre_byte(is_space);
  __dyc_printpre_byte(__s1_len___8);
  __dyc_printpre_byte(__s2_len___8);
  __dyc_printpre_byte(is_upper);
  __dyc_printpre_byte(__s1_len___9);
  __dyc_printpre_byte(__s2_len___9);
  __dyc_printpre_byte(is_xdigit);
  __dyc_printpre_byte(__s1_len___10);
  __dyc_printpre_byte(__s2_len___10);
  __dyc_printpre_byte(__s1_len___11);
  __dyc_printpre_byte(__s2_len___11);
  __dyc_printpre_byte(tmp___259);
}
}
