#include <dycfoo.h>
#include "../simple-object-elf.i.hd.c.h"
void __dyc_foo(void) 
{ struct simple_object_elf_write *eow ;
  unsigned char ei_class ;
  size_t shdr_size ;
  unsigned int shnum ;
  unsigned char *shdrs ;
  size_t name_size ;
  unsigned char *names ;
  unsigned int i ;
  int changed ;
  int *pfnret ;
  char const   **pfnname ;
  unsigned int new_i ;
  unsigned int *sh_map ;
  unsigned int first_shndx ;
  unsigned int *symtab_indices_shndx ;
  void *tmp___7 ;
  int tmp___8 ;
  void *tmp___9 ;
  void *tmp___10 ;
  void *tmp___11 ;
  unsigned char *shdr ;
  unsigned int sh_name ;
  unsigned int sh_type ;
  char const   *name ;
  char *ret ;
  unsigned int sh_link ;
  unsigned char *shdr___0 ;
  unsigned int sh_type___0 ;
  unsigned int sh_info ;
  unsigned int sh_link___0 ;
  off_t offset ;
  off_t length ;
  unsigned int entsize ;
  ulong_type tmp___26 ;
  unsigned char *ent ;
  unsigned char *buf ;
  int keep ;
  ulong_type tmp___29 ;
  ulong_type tmp___30 ;
  ulong_type tmp___33 ;
  ulong_type tmp___34 ;
  void *tmp___35 ;
  int tmp___36 ;
  unsigned int sec ;
  unsigned int tmp___37 ;
  int tmp___38 ;
  int tmp___39 ;
  void *tmp___40 ;
  unsigned int tmp___41 ;
  void *tmp___42 ;
  int *err ;
  int __dyc_funcallvar_8 ;
  void *__dyc_funcallvar_9 ;
  void *__dyc_funcallvar_10 ;
  void *__dyc_funcallvar_11 ;
  unsigned int __dyc_funcallvar_12 ;
  unsigned int __dyc_funcallvar_13 ;
  char *__dyc_funcallvar_14 ;
  unsigned int __dyc_funcallvar_15 ;
  unsigned int __dyc_funcallvar_16 ;
  unsigned int __dyc_funcallvar_17 ;
  unsigned int __dyc_funcallvar_18 ;
  unsigned int __dyc_funcallvar_19 ;
  unsigned int __dyc_funcallvar_20 ;
  unsigned int __dyc_funcallvar_21 ;
  unsigned int __dyc_funcallvar_22 ;
  unsigned int __dyc_funcallvar_23 ;
  unsigned int __dyc_funcallvar_24 ;
  ulong_type __dyc_funcallvar_25 ;
  ulong_type __dyc_funcallvar_26 ;
  ulong_type __dyc_funcallvar_27 ;
  ulong_type __dyc_funcallvar_28 ;
  ulong_type __dyc_funcallvar_29 ;
  ulong_type __dyc_funcallvar_30 ;
  void *__dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  unsigned int __dyc_funcallvar_33 ;
  void *__dyc_funcallvar_34 ;
  void *__dyc_funcallvar_35 ;

  {
  eow = __dyc_read_ptr__comp_62simple_object_elf_write();
  ei_class = (unsigned char )__dyc_readpre_byte();
  shdr_size = (size_t )__dyc_readpre_byte();
  shnum = (unsigned int )__dyc_readpre_byte();
  shdrs = (unsigned char *)__dyc_read_ptr__char();
  name_size = (size_t )__dyc_readpre_byte();
  first_shndx = (unsigned int )__dyc_readpre_byte();
  tmp___7 = __dyc_read_ptr__void();
  err = __dyc_read_ptr__int();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_read_ptr__void();
  __dyc_funcallvar_10 = __dyc_read_ptr__void();
  __dyc_funcallvar_11 = __dyc_read_ptr__void();
  __dyc_funcallvar_12 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_13 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_read_ptr__char();
  __dyc_funcallvar_15 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_16 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_17 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_18 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_19 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_20 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_21 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_22 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_23 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_24 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_25 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_26 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_27 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_28 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_29 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_30 = (ulong_type )__dyc_readpre_byte();
  __dyc_funcallvar_31 = __dyc_read_ptr__void();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_read_ptr__void();
  __dyc_funcallvar_35 = __dyc_read_ptr__void();
  names = 0;
  i = 0;
  changed = 0;
  pfnret = 0;
  pfnname = 0;
  new_i = 0;
  sh_map = 0;
  symtab_indices_shndx = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  shdr = 0;
  sh_name = 0;
  sh_type = 0;
  name = 0;
  ret = 0;
  sh_link = 0;
  shdr___0 = 0;
  sh_type___0 = 0;
  sh_info = 0;
  sh_link___0 = 0;
  offset = 0;
  length = 0;
  entsize = 0;
  tmp___26 = 0;
  ent = 0;
  buf = 0;
  keep = 0;
  tmp___29 = 0;
  tmp___30 = 0;
  tmp___33 = 0;
  tmp___34 = 0;
  tmp___35 = 0;
  tmp___36 = 0;
  sec = 0;
  tmp___37 = 0;
  tmp___38 = 0;
  tmp___39 = 0;
  tmp___40 = 0;
  tmp___41 = 0;
  tmp___42 = 0;
#line 1141
  names = (unsigned char *)tmp___7;
#line 1142
  tmp___8 = __dyc_funcallvar_8;
#line 1142
  if (! tmp___8) {
    {


    }
    goto __dyc_dummy_label;
  }
#line 1151
  tmp___9 = __dyc_funcallvar_9;
#line 1151
  pfnret = (int *)tmp___9;
#line 1152
  tmp___10 = __dyc_funcallvar_10;
#line 1152
  pfnname = (char const   **)tmp___10;
#line 1155
  tmp___11 = __dyc_funcallvar_11;
#line 1155
  symtab_indices_shndx = (unsigned int *)tmp___11;
#line 1159
  i = 1U;
#line 1159
  while (1) {
    while_9_continue: /* CIL Label */ ;
#line 1159
    if (! (i < shnum)) {
      goto while_9_break;
    }
#line 1166
    shdr = shdrs + (size_t )(i - 1U) * shdr_size;
#line 1167
    if ((int )ei_class == 1) {
      {
#line 1167
      sh_name = __dyc_funcallvar_12;
      }
    } else {
      {
#line 1167
      sh_name = __dyc_funcallvar_13;
      }
    }
#line 1169
    if ((size_t )sh_name >= name_size) {
      {
#line 1171
      *err = 0;


      }
      goto __dyc_dummy_label;
    }
    {
#line 1177
    name = (char const   *)names + sh_name;
#line 1179
    ret = __dyc_funcallvar_14;
    }
#line 1180
    if ((unsigned long )ret == (unsigned long )((void *)0)) {
#line 1180
      *(pfnret + (i - 1U)) = -1;
    } else {
#line 1180
      *(pfnret + (i - 1U)) = 0;
    }
#line 1181
    if ((unsigned long )ret == (unsigned long )((void *)0)) {
#line 1181
      *(pfnname + (i - 1U)) = name;
    } else {
#line 1181
      *(pfnname + (i - 1U)) = (char const   *)ret;
    }
#line 1182
    if (first_shndx == 0U) {
#line 1182
      if (*(pfnret + (i - 1U)) == 0) {
#line 1184
        first_shndx = i;
      }
    }
#line 1187
    if ((int )ei_class == 1) {
      {
#line 1187
      sh_type = __dyc_funcallvar_15;
      }
    } else {
      {
#line 1187
      sh_type = __dyc_funcallvar_16;
      }
    }
#line 1189
    if (sh_type == 18U) {
#line 1192
      if ((int )ei_class == 1) {
        {
#line 1192
        sh_link = __dyc_funcallvar_17;
        }
      } else {
        {
#line 1192
        sh_link = __dyc_funcallvar_18;
        }
      }
#line 1194
      *(symtab_indices_shndx + (sh_link - 1U)) = i - 1U;
#line 1199
      *(pfnret + (i - 1U)) = -1;
    }
#line 1159
    i ++;
  }
  while_9_break: /* CIL Label */ ;
#line 1205
  while (1) {
    while_10_continue: /* CIL Label */ ;
#line 1207
    changed = 0;
#line 1208
    i = 1U;
    {
#line 1208
    while (1) {
      while_11_continue: /* CIL Label */ ;
#line 1208
      if (! (i < shnum)) {
        goto while_11_break;
      }
#line 1215
      shdr___0 = shdrs + (size_t )(i - 1U) * shdr_size;
#line 1216
      if ((int )ei_class == 1) {
        {
#line 1216
        sh_type___0 = __dyc_funcallvar_19;
        }
      } else {
        {
#line 1216
        sh_type___0 = __dyc_funcallvar_20;
        }
      }
#line 1218
      if ((int )ei_class == 1) {
        {
#line 1218
        sh_info = __dyc_funcallvar_21;
        }
      } else {
        {
#line 1218
        sh_info = __dyc_funcallvar_22;
        }
      }
#line 1220
      if ((int )ei_class == 1) {
        {
#line 1220
        sh_link___0 = __dyc_funcallvar_23;
        }
      } else {
        {
#line 1220
        sh_link___0 = __dyc_funcallvar_24;
        }
      }
#line 1222
      if (sh_type___0 == 17U) {
#line 1225
        if ((int )ei_class == 1) {
          {
#line 1225
          tmp___26 = __dyc_funcallvar_25;
          }
        } else {
          {
#line 1225
          tmp___26 = __dyc_funcallvar_26;
          }
        }
#line 1225
        entsize = (unsigned int )tmp___26;
#line 1229
        keep = 0;
#line 1230
        if ((int )ei_class == 1) {
          {
#line 1230
          tmp___29 = __dyc_funcallvar_27;
#line 1230
          offset = (long )tmp___29;
          }
        } else {
          {
#line 1230
          tmp___30 = __dyc_funcallvar_28;
#line 1230
          offset = (long )tmp___30;
          }
        }
#line 1232
        if ((int )ei_class == 1) {
          {
#line 1232
          tmp___33 = __dyc_funcallvar_29;
#line 1232
          length = (long )tmp___33;
          }
        } else {
          {
#line 1232
          tmp___34 = __dyc_funcallvar_30;
#line 1232
          length = (long )tmp___34;
          }
        }
        {
#line 1234
        tmp___35 = __dyc_funcallvar_31;
#line 1234
        buf = (unsigned char *)tmp___35;
#line 1235
        tmp___36 = __dyc_funcallvar_32;
        }
#line 1235
        if (! tmp___36) {
          {



          }
          goto __dyc_dummy_label;
        }
#line 1244
        ent = buf + entsize;
        {
#line 1244
        while (1) {
          while_12_continue: /* CIL Label */ ;
#line 1244
          if (! ((unsigned long )ent < (unsigned long )(buf + length))) {
            goto while_12_break;
          }
          {
#line 1246
          tmp___37 = __dyc_funcallvar_33;
#line 1246
          sec = tmp___37;
          }
#line 1247
          if (*(pfnret + (sec - 1U)) == 0) {
#line 1248
            keep = 1;
          }
#line 1244
          ent += entsize;
        }
        while_12_break: /* CIL Label */ ;
        }
#line 1250
        if (keep) {
#line 1252
          if (*(pfnret + (sh_link___0 - 1U)) == -1) {
#line 1252
            tmp___38 = 1;
          } else {
#line 1252
            if (*(pfnret + (i - 1U)) == -1) {
#line 1252
              tmp___38 = 1;
            } else {
#line 1252
              tmp___38 = 0;
            }
          }
#line 1252
          changed |= tmp___38;
#line 1254
          *(pfnret + (sh_link___0 - 1U)) = 0;
#line 1255
          *(pfnret + (i - 1U)) = 0;
        }
      }
#line 1258
      if (sh_type___0 == 4U) {
        goto _L;
      } else {
#line 1258
        if (sh_type___0 == 9U) {
          _L: /* CIL Label */ 
#line 1262
          if (*(pfnret + (sh_info - 1U)) == 0) {
#line 1264
            if (*(pfnret + (sh_link___0 - 1U)) == -1) {
#line 1264
              tmp___39 = 1;
            } else {
#line 1264
              if (*(pfnret + (i - 1U)) == -1) {
#line 1264
                tmp___39 = 1;
              } else {
#line 1264
                tmp___39 = 0;
              }
            }
#line 1264
            changed |= tmp___39;
#line 1266
            *(pfnret + (sh_link___0 - 1U)) = 0;
#line 1267
            *(pfnret + (i - 1U)) = 0;
          }
        }
      }
#line 1270
      if (sh_type___0 == 2U) {
#line 1273
        if (*(pfnret + (i - 1U)) == 0) {
#line 1275
          changed |= *(pfnret + (sh_link___0 - 1U)) == -1;
#line 1276
          *(pfnret + (sh_link___0 - 1U)) = 0;
        }
      }
#line 1208
      i ++;
    }
    while_11_break: /* CIL Label */ ;
    }
#line 1205
    if (! changed) {
      goto while_10_break;
    }
  }
  while_10_break: /* CIL Label */ ;
#line 1284
  tmp___40 = __dyc_funcallvar_34;
#line 1284
  sh_map = (unsigned int *)tmp___40;
#line 1285
  *(sh_map + 0) = 0U;
#line 1286
  new_i = 1U;
#line 1287
  i = 1U;
#line 1287
  while (1) {
    while_13_continue: /* CIL Label */ ;
#line 1287
    if (! (i < shnum)) {
      goto while_13_break;
    }
#line 1289
    if (*(pfnret + (i - 1U)) == -1) {
#line 1290
      *(sh_map + i) = 0U;
    } else {
#line 1292
      tmp___41 = new_i;
#line 1292
      new_i ++;
#line 1292
      *(sh_map + i) = tmp___41;
    }
#line 1287
    i ++;
  }
  while_13_break: /* CIL Label */ ;
#line 1294
  if (new_i - 1U >= 65280U) {
#line 1296
    *err = 95;
    goto __dyc_dummy_label;
  }
#line 1299
  tmp___42 = __dyc_funcallvar_35;
#line 1299
  eow->shdrs = (unsigned char *)tmp___42;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__char(names);
  __dyc_printpre_byte(changed);
  __dyc_print_ptr__int(pfnret);
  __dyc_print_ptr__ptr__char(pfnname);
  __dyc_printpre_byte(first_shndx);
  __dyc_print_ptr__int(symtab_indices_shndx);
  __dyc_print_ptr__char(shdr);
  __dyc_print_ptr__char(name);
  __dyc_print_ptr__char(shdr___0);
  __dyc_printpre_byte(sh_info);
  __dyc_printpre_byte(sh_link___0);
  __dyc_printpre_byte(offset);
  __dyc_printpre_byte(length);
  __dyc_printpre_byte(entsize);
  __dyc_print_ptr__char(buf);
  __dyc_printpre_byte(keep);
}
}
