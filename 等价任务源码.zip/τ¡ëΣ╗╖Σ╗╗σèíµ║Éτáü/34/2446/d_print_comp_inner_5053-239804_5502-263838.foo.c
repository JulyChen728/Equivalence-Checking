#include <dycfoo.h>
#include "../cp-demangle.i.hd.c.h"
void __dyc_foo(void) 
{ struct demangle_builtin_type_info  const  cplus_demangle_builtin_types[34] ;
  struct demangle_component *mod_inner ;
  struct d_print_template *saved_templates ;
  int need_template_restore ;
  struct d_print_mod *pdpm ;
  struct demangle_component *sub ;
  struct d_saved_scope *scope ;
  struct d_saved_scope *tmp___47 ;
  struct demangle_component *a___0 ;
  int tmp___48 ;
  struct d_component_stack  const  *dcse ;
  int found_self_or_parent ;
  struct d_print_mod dpm ;
  struct d_print_mod dpm___0 ;
  struct d_print_mod *hold_modifiers___0 ;
  struct d_print_mod adpm___0[4] ;
  unsigned int i___0 ;
  struct d_print_mod *pdpm___0 ;
  struct d_print_mod dpm___1 ;
  size_t len ;
  unsigned long flush_count ;
  struct demangle_component *type ;
  struct demangle_component *list ;
  struct demangle_operator_info  const  *op ;
  int len___0 ;
  struct demangle_component *op___0 ;
  struct demangle_component *operand ;
  char const   *code ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___58 ;
  int tmp___63 ;
  int tmp___64 ;
  int tmp___65 ;
  int tmp___66 ;
  struct demangle_component *a___1 ;
  struct demangle_component *tmp___67 ;
  int len___1 ;
  int tmp___68 ;
  int len___2 ;
  int tmp___69 ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___79 ;
  int tmp___84 ;
  int tmp___85 ;
  int tmp___86 ;
  int tmp___87 ;
  size_t __s1_len___3 ;
  size_t __s2_len___3 ;
  int tmp___97 ;
  int tmp___102 ;
  int tmp___103 ;
  int tmp___104 ;
  int tmp___105 ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___115 ;
  int tmp___120 ;
  int tmp___121 ;
  int tmp___122 ;
  int tmp___123 ;
  size_t __s1_len___5 ;
  size_t __s2_len___5 ;
  int tmp___133 ;
  int tmp___138 ;
  int tmp___139 ;
  int tmp___140 ;
  int tmp___141 ;
  int tmp___142 ;
  int tmp___143 ;
  struct demangle_component  const  *func ;
  size_t __s1_len___6 ;
  size_t __s2_len___6 ;
  int tmp___153 ;
  int tmp___158 ;
  int tmp___159 ;
  int tmp___160 ;
  int tmp___161 ;
  struct d_print_info *dpi ;
  int options ;
  struct demangle_component *dc ;
  struct d_saved_scope *__dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  struct demangle_component *__dyc_funcallvar_16 ;
  struct demangle_component *__dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;
  struct demangle_component *__dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;
  int __dyc_funcallvar_30 ;
  int __dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  int __dyc_funcallvar_33 ;
  int __dyc_funcallvar_34 ;
  int __dyc_funcallvar_35 ;
  int __dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  int __dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;
  int __dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  int __dyc_funcallvar_50 ;
  int __dyc_funcallvar_51 ;
  int __dyc_funcallvar_52 ;

  {
  mod_inner = __dyc_read_ptr__comp_46demangle_component();
  saved_templates = __dyc_read_ptr__comp_62d_print_template();
  need_template_restore = __dyc_readpre_byte();
  pdpm = __dyc_read_ptr__comp_63d_print_mod();
  dpi = __dyc_read_ptr__comp_68d_print_info();
  options = __dyc_readpre_byte();
  dc = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_14 = __dyc_read_ptr__comp_66d_saved_scope();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_17 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  __dyc_funcallvar_31 = __dyc_readpre_byte();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_readpre_byte();
  __dyc_funcallvar_36 = __dyc_readpre_byte();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_readpre_byte();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = __dyc_readpre_byte();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_readpre_byte();
  __dyc_funcallvar_51 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  sub = 0;
  scope = 0;
  tmp___47 = 0;
  a___0 = 0;
  tmp___48 = 0;
  dcse = 0;
  found_self_or_parent = 0;
  memset(& dpm, 0, sizeof(struct d_print_mod ));
  memset(& dpm___0, 0, sizeof(struct d_print_mod ));
  hold_modifiers___0 = 0;
  i___0 = 0;
  pdpm___0 = 0;
  memset(& dpm___1, 0, sizeof(struct d_print_mod ));
  len = 0;
  flush_count = 0;
  type = 0;
  list = 0;
  op = 0;
  len___0 = 0;
  op___0 = 0;
  operand = 0;
  code = 0;
  __s1_len___1 = 0;
  __s2_len___1 = 0;
  tmp___58 = 0;
  tmp___63 = 0;
  tmp___64 = 0;
  tmp___65 = 0;
  tmp___66 = 0;
  a___1 = 0;
  tmp___67 = 0;
  len___1 = 0;
  tmp___68 = 0;
  len___2 = 0;
  tmp___69 = 0;
  __s1_len___2 = 0;
  __s2_len___2 = 0;
  tmp___79 = 0;
  tmp___84 = 0;
  tmp___85 = 0;
  tmp___86 = 0;
  tmp___87 = 0;
  __s1_len___3 = 0;
  __s2_len___3 = 0;
  tmp___97 = 0;
  tmp___102 = 0;
  tmp___103 = 0;
  tmp___104 = 0;
  tmp___105 = 0;
  __s1_len___4 = 0;
  __s2_len___4 = 0;
  tmp___115 = 0;
  tmp___120 = 0;
  tmp___121 = 0;
  tmp___122 = 0;
  tmp___123 = 0;
  __s1_len___5 = 0;
  __s2_len___5 = 0;
  tmp___133 = 0;
  tmp___138 = 0;
  tmp___139 = 0;
  tmp___140 = 0;
  tmp___141 = 0;
  tmp___142 = 0;
  tmp___143 = 0;
  func = 0;
  __s1_len___6 = 0;
  __s2_len___6 = 0;
  tmp___153 = 0;
  tmp___158 = 0;
  tmp___159 = 0;
  tmp___160 = 0;
  tmp___161 = 0;
#line 5053
  while (1) {
    while_54_continue: /* CIL Label */ ;
#line 5053
    if (! ((unsigned long )pdpm != (unsigned long )((void *)0))) {
      goto while_54_break;
    }
#line 5055
    if (! pdpm->printed) {
#line 5057
      if ((int )(pdpm->mod)->type != 25) {
#line 5057
        if ((int )(pdpm->mod)->type != 26) {
#line 5057
          if ((int )(pdpm->mod)->type != 27) {
            goto while_54_break;
          }
        }
      }
#line 5061
      if ((int )(pdpm->mod)->type == (int )dc->type) {
        {

        }
        goto __dyc_dummy_label;
      }
    }
#line 5053
    pdpm = pdpm->next;
  }
  while_54_break: /* CIL Label */ ;
  goto modifier;
  switch_50_35: /* CIL Label */ 
  switch_50_36: /* CIL Label */ 
#line 5075
  sub = dc->u.s_binary.left;
#line 5076
  if (! dpi->is_lambda_arg) {
#line 5076
    if ((int )sub->type == 5) {
      {
#line 5079
      tmp___47 = __dyc_funcallvar_14;
#line 5079
      scope = tmp___47;
      }
#line 5082
      if ((unsigned long )scope == (unsigned long )((void *)0)) {
        {

#line 5089
        tmp___48 = __dyc_funcallvar_15;
        }
#line 5089
        if (tmp___48) {
          goto __dyc_dummy_label;
        }
      } else {
#line 5095
        found_self_or_parent = 0;
#line 5100
        dcse = dpi->component_stack;
        {
#line 5100
        while (1) {
          while_55_continue: /* CIL Label */ ;
#line 5100
          if (! ((unsigned long )dcse != (unsigned long )((void *)0))) {
            goto while_55_break;
          }
#line 5103
          if ((unsigned long )dcse->dc == (unsigned long )sub) {
#line 5107
            found_self_or_parent = 1;
            goto while_55_break;
          } else {
#line 5103
            if ((unsigned long )dcse->dc == (unsigned long )dc) {
#line 5103
              if ((unsigned long )dcse != (unsigned long )dpi->component_stack) {
#line 5107
                found_self_or_parent = 1;
                goto while_55_break;
              }
            }
          }
#line 5100
          dcse = (struct d_component_stack  const  *)dcse->parent;
        }
        while_55_break: /* CIL Label */ ;
        }
#line 5112
        if (! found_self_or_parent) {
#line 5114
          saved_templates = dpi->templates;
#line 5115
          dpi->templates = scope->templates;
#line 5116
          need_template_restore = 1;
        }
      }
      {
#line 5120
      a___0 = __dyc_funcallvar_16;
      }
#line 5121
      if (a___0) {
#line 5121
        if ((int )a___0->type == 47) {
          {
#line 5122
          a___0 = __dyc_funcallvar_17;
          }
        }
      }
#line 5124
      if ((unsigned long )a___0 == (unsigned long )((void *)0)) {
#line 5126
        if (need_template_restore) {
#line 5127
          dpi->templates = saved_templates;
        }
        {

        }
        goto __dyc_dummy_label;
      }
#line 5133
      sub = a___0;
    }
  }
#line 5136
  if ((int )sub->type == 35) {
#line 5138
    dc = sub;
  } else {
#line 5136
    if ((int )sub->type == (int )dc->type) {
#line 5138
      dc = sub;
    } else {
#line 5139
      if ((int )sub->type == 36) {
#line 5140
        mod_inner = sub->u.s_binary.left;
      }
    }
  }
  modifier: 
  switch_50_33: /* CIL Label */ 
  switch_50_34: /* CIL Label */ 
  switch_50_37: /* CIL Label */ 
  switch_50_38: /* CIL Label */ 
  switch_50_28: /* CIL Label */ 
  switch_50_29: /* CIL Label */ 
  switch_50_30: /* CIL Label */ 
  switch_50_31: /* CIL Label */ 
  switch_50_32: /* CIL Label */ 
  switch_50_77: /* CIL Label */ 
  switch_50_79: /* CIL Label */ 
  switch_50_80: /* CIL Label */ 
#line 5154
  dpm.next = dpi->modifiers;
#line 5155
  dpi->modifiers = & dpm;
#line 5156
  dpm.mod = dc;
#line 5157
  dpm.printed = 0;
#line 5158
  dpm.templates = dpi->templates;
#line 5160
  if (! mod_inner) {
#line 5161
    mod_inner = dc->u.s_binary.left;
  }

#line 5167
  if (! dpm.printed) {
    {

    }
  }
#line 5170
  dpi->modifiers = dpm.next;
#line 5172
  if (need_template_restore) {
#line 5173
    dpi->templates = saved_templates;
  }
  goto __dyc_dummy_label;
  switch_50_39: /* CIL Label */ 
#line 5179
  if ((options & (1 << 2)) == 0) {
    {

    }
  } else {
    {

    }
  }
  goto __dyc_dummy_label;

  goto __dyc_dummy_label;
  switch_50_41: /* CIL Label */ 
#line 5193
  if ((options & (1 << 5)) != 0) {
    {

    }
  }
#line 5199
  if ((unsigned long )dc->u.s_binary.left != (unsigned long )((void *)0)) {
#line 5199
    if ((options & (1 << 5)) != 0) {
      {

      }
    } else {
      goto _L___6;
    }
  } else {
    _L___6: /* CIL Label */ 
#line 5202
    if ((unsigned long )dc->u.s_binary.left != (unsigned long )((void *)0)) {
#line 5202
      if ((options & (1 << 6)) == 0) {
        {
#line 5208
        dpm___0.next = dpi->modifiers;
#line 5209
        dpi->modifiers = & dpm___0;
#line 5210
        dpm___0.mod = dc;
#line 5211
        dpm___0.printed = 0;
#line 5212
        dpm___0.templates = dpi->templates;

#line 5217
        dpi->modifiers = dpm___0.next;
        }
#line 5219
        if (dpm___0.printed) {
          goto __dyc_dummy_label;
        }
#line 5224
        if ((options & (1 << 5)) == 0) {
          {

          }
        }
      }
    }
  }
#line 5228
  if ((options & (1 << 5)) == 0) {
    {

    }
  }
  goto __dyc_dummy_label;
  switch_50_42: /* CIL Label */ 
#line 5251
  hold_modifiers___0 = dpi->modifiers;
#line 5253
  adpm___0[0].next = hold_modifiers___0;
#line 5254
  dpi->modifiers = adpm___0;
#line 5255
  adpm___0[0].mod = dc;
#line 5256
  adpm___0[0].printed = 0;
#line 5257
  adpm___0[0].templates = dpi->templates;
#line 5259
  i___0 = 1U;
#line 5260
  pdpm___0 = hold_modifiers___0;
#line 5261
  while (1) {
    while_56_continue: /* CIL Label */ ;
#line 5261
    if ((unsigned long )pdpm___0 != (unsigned long )((void *)0)) {
#line 5261
      if (! ((int )(pdpm___0->mod)->type == 25)) {
#line 5261
        if (! ((int )(pdpm___0->mod)->type == 26)) {
#line 5261
          if (! ((int )(pdpm___0->mod)->type == 27)) {
            goto while_56_break;
          }
        }
      }
    } else {
      goto while_56_break;
    }
#line 5266
    if (! pdpm___0->printed) {
#line 5268
      if ((unsigned long )i___0 >= sizeof(struct d_print_mod [4]) / sizeof(struct d_print_mod )) {
        {

        }
        goto __dyc_dummy_label;
      }
#line 5274
      adpm___0[i___0] = *pdpm___0;
#line 5275
      adpm___0[i___0].next = dpi->modifiers;
#line 5276
      dpi->modifiers = & adpm___0[i___0];
#line 5277
      pdpm___0->printed = 1;
#line 5278
      i___0 ++;
    }
#line 5281
    pdpm___0 = pdpm___0->next;
  }
  while_56_break: /* CIL Label */ ;

#line 5286
  dpi->modifiers = hold_modifiers___0;
#line 5288
  if (adpm___0[0].printed) {
    goto __dyc_dummy_label;
  }
#line 5291
  while (1) {
    while_57_continue: /* CIL Label */ ;
#line 5291
    if (! (i___0 > 1U)) {
      goto while_57_break;
    }
    {
#line 5293
    i___0 --;

    }
  }
  while_57_break: /* CIL Label */ ;

  goto __dyc_dummy_label;
#line 5307
  dpm___1.next = dpi->modifiers;
#line 5308
  dpi->modifiers = & dpm___1;
#line 5309
  dpm___1.mod = dc;
#line 5310
  dpm___1.printed = 0;
#line 5311
  dpm___1.templates = dpi->templates;

#line 5317
  if (! dpm___1.printed) {
    {

    }
  }
#line 5320
  dpi->modifiers = dpm___1.next;
  goto __dyc_dummy_label;
  switch_50_44: /* CIL Label */ 
#line 5326
  if (dc->u.s_fixed.sat) {
    {

    }
  }
#line 5329
  if ((unsigned long )(dc->u.s_fixed.length)->u.s_builtin.type != (unsigned long )(& cplus_demangle_builtin_types[8])) {
    {


    }
  }
#line 5335
  if (dc->u.s_fixed.accum) {
    {

    }
  } else {
    {

    }
  }
  goto __dyc_dummy_label;
  switch_50_46: /* CIL Label */ 
  switch_50_47: /* CIL Label */ 
#line 5343
  if ((unsigned long )dc->u.s_binary.left != (unsigned long )((void *)0)) {
    {

    }
  }
#line 5345
  if ((unsigned long )dc->u.s_binary.right != (unsigned long )((void *)0)) {
#line 5351
    if (dpi->len >= sizeof(char [256]) - 2UL) {
      {

      }
    }
    {

#line 5354
    len = dpi->len;
#line 5355
    flush_count = dpi->flush_count;

    }
#line 5359
    if (dpi->flush_count == flush_count) {
#line 5359
      if (dpi->len == len) {
#line 5360
        dpi->len -= 2UL;
      }
    }
  }
  goto __dyc_dummy_label;
  switch_50_49: /* CIL Label */ 
#line 5366
  type = dc->u.s_binary.left;
#line 5367
  list = dc->u.s_binary.right;
#line 5369
  if (type) {
    {

    }
  }



  goto __dyc_dummy_label;
#line 5379
  op = dc->u.s_operator.op;
#line 5380
  len___0 = (int )op->len;

#line 5384
  if ((int const   )*(op->name + 0) >= 97) {
#line 5384
    if ((int const   )*(op->name + 0) <= 122) {
      {

      }
    }
  }
#line 5387
  if ((int const   )*(op->name + (len___0 - 1)) == 32) {
#line 5388
    len___0 --;
  }

  goto __dyc_dummy_label;


  goto __dyc_dummy_label;


  goto __dyc_dummy_label;

  goto __dyc_dummy_label;
  switch_50_55: /* CIL Label */ 
#line 5409
  op___0 = dc->u.s_binary.left;
#line 5410
  operand = dc->u.s_binary.right;
#line 5411
  code = (char const   *)((void *)0);
#line 5413
  if ((int )op___0->type == 50) {
#line 5415
    code = (char const   *)(op___0->u.s_operator.op)->code;
#line 5416
    if (0) {
      {
#line 5416
      tmp___64 = __dyc_funcallvar_18;
#line 5416
      __s1_len___1 = (unsigned long )tmp___64;
#line 5416
      tmp___65 = __dyc_funcallvar_19;
#line 5416
      __s2_len___1 = (unsigned long )tmp___65;
      }
#line 5416
      if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
        goto _L___8;
      } else {
#line 5416
        if (__s1_len___1 >= 4UL) {
          _L___8: /* CIL Label */ 
#line 5416
          if (! ((unsigned long )((void const   *)("ad" + 1)) - (unsigned long )((void const   *)"ad") == 1UL)) {
#line 5416
            tmp___66 = 1;
          } else {
#line 5416
            if (__s2_len___1 >= 4UL) {
#line 5416
              tmp___66 = 1;
            } else {
#line 5416
              tmp___66 = 0;
            }
          }
        } else {
#line 5416
          tmp___66 = 0;
        }
      }
#line 5416
      if (tmp___66) {
        {
#line 5416
        tmp___58 = __dyc_funcallvar_20;
        }
      } else {
        {
#line 5416
        tmp___63 = __dyc_funcallvar_21;
#line 5416
        tmp___58 = tmp___63;
        }
      }
    } else {
      {
#line 5416
      tmp___63 = __dyc_funcallvar_22;
#line 5416
      tmp___58 = tmp___63;
      }
    }
#line 5416
    if (! tmp___58) {
#line 5420
      if ((int )operand->type == 3) {
#line 5420
        if ((int )(operand->u.s_binary.left)->type == 1) {
#line 5420
          if ((int )(operand->u.s_binary.right)->type == 41) {
#line 5423
            operand = operand->u.s_binary.left;
          }
        }
      }
    }
#line 5425
    if ((int )operand->type == 57) {
      {
#line 5428
      operand = operand->u.s_binary.left;


      }
      goto __dyc_dummy_label;
    }
  }
#line 5436
  if (code) {
#line 5436
    if (0) {
      {
#line 5436
      tmp___103 = __dyc_funcallvar_23;
#line 5436
      __s1_len___3 = (unsigned long )tmp___103;
#line 5436
      tmp___104 = __dyc_funcallvar_24;
#line 5436
      __s2_len___3 = (unsigned long )tmp___104;
      }
#line 5436
      if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
        goto _L___12;
      } else {
#line 5436
        if (__s1_len___3 >= 4UL) {
          _L___12: /* CIL Label */ 
#line 5436
          if (! ((unsigned long )((void const   *)("sZ" + 1)) - (unsigned long )((void const   *)"sZ") == 1UL)) {
#line 5436
            tmp___105 = 1;
          } else {
#line 5436
            if (__s2_len___3 >= 4UL) {
#line 5436
              tmp___105 = 1;
            } else {
#line 5436
              tmp___105 = 0;
            }
          }
        } else {
#line 5436
          tmp___105 = 0;
        }
      }
#line 5436
      if (tmp___105) {
        {
#line 5436
        tmp___97 = __dyc_funcallvar_25;
        }
      } else {
        {
#line 5436
        tmp___102 = __dyc_funcallvar_26;
#line 5436
        tmp___97 = tmp___102;
        }
      }
    } else {
      {
#line 5436
      tmp___102 = __dyc_funcallvar_27;
#line 5436
      tmp___97 = tmp___102;
      }
    }
#line 5436
    if (tmp___97) {
      goto _L___13;
    } else {
      {
#line 5438
      tmp___67 = __dyc_funcallvar_28;
#line 5438
      a___1 = tmp___67;
#line 5439
      tmp___68 = __dyc_funcallvar_29;
#line 5439
      len___1 = tmp___68;

      }
      goto __dyc_dummy_label;
    }
  } else {
    _L___13: /* CIL Label */ 
#line 5443
    if (code) {
#line 5443
      if (0) {
        {
#line 5443
        tmp___85 = __dyc_funcallvar_30;
#line 5443
        __s1_len___2 = (unsigned long )tmp___85;
#line 5443
        tmp___86 = __dyc_funcallvar_31;
#line 5443
        __s2_len___2 = (unsigned long )tmp___86;
        }
#line 5443
        if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
          goto _L___10;
        } else {
#line 5443
          if (__s1_len___2 >= 4UL) {
            _L___10: /* CIL Label */ 
#line 5443
            if (! ((unsigned long )((void const   *)("sP" + 1)) - (unsigned long )((void const   *)"sP") == 1UL)) {
#line 5443
              tmp___87 = 1;
            } else {
#line 5443
              if (__s2_len___2 >= 4UL) {
#line 5443
                tmp___87 = 1;
              } else {
#line 5443
                tmp___87 = 0;
              }
            }
          } else {
#line 5443
            tmp___87 = 0;
          }
        }
#line 5443
        if (tmp___87) {
          {
#line 5443
          tmp___79 = __dyc_funcallvar_32;
          }
        } else {
          {
#line 5443
          tmp___84 = __dyc_funcallvar_33;
#line 5443
          tmp___79 = tmp___84;
          }
        }
      } else {
        {
#line 5443
        tmp___84 = __dyc_funcallvar_34;
#line 5443
        tmp___79 = tmp___84;
        }
      }
#line 5443
      if (! tmp___79) {
        {
#line 5445
        tmp___69 = __dyc_funcallvar_35;
#line 5445
        len___2 = tmp___69;

        }
        goto __dyc_dummy_label;
      }
    }
  }
#line 5450
  if ((int )op___0->type != 52) {
    {

    }
  } else {
    {



    }
  }
#line 5458
  if (code) {
#line 5458
    if (0) {
      {
#line 5458
      tmp___139 = __dyc_funcallvar_36;
#line 5458
      __s1_len___5 = (unsigned long )tmp___139;
#line 5458
      tmp___140 = __dyc_funcallvar_37;
#line 5458
      __s2_len___5 = (unsigned long )tmp___140;
      }
#line 5458
      if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
        goto _L___17;
      } else {
#line 5458
        if (__s1_len___5 >= 4UL) {
          _L___17: /* CIL Label */ 
#line 5458
          if (! ((unsigned long )((void const   *)("gs" + 1)) - (unsigned long )((void const   *)"gs") == 1UL)) {
#line 5458
            tmp___141 = 1;
          } else {
#line 5458
            if (__s2_len___5 >= 4UL) {
#line 5458
              tmp___141 = 1;
            } else {
#line 5458
              tmp___141 = 0;
            }
          }
        } else {
#line 5458
          tmp___141 = 0;
        }
      }
#line 5458
      if (tmp___141) {
        {
#line 5458
        tmp___133 = __dyc_funcallvar_38;
        }
      } else {
        {
#line 5458
        tmp___138 = __dyc_funcallvar_39;
#line 5458
        tmp___133 = tmp___138;
        }
      }
    } else {
      {
#line 5458
      tmp___138 = __dyc_funcallvar_40;
#line 5458
      tmp___133 = tmp___138;
      }
    }
#line 5458
    if (tmp___133) {
      goto _L___18;
    } else {
      {

      }
    }
  } else {
    _L___18: /* CIL Label */ 
#line 5461
    if (code) {
#line 5461
      if (0) {
        {
#line 5461
        tmp___121 = __dyc_funcallvar_41;
#line 5461
        __s1_len___4 = (unsigned long )tmp___121;
#line 5461
        tmp___122 = __dyc_funcallvar_42;
#line 5461
        __s2_len___4 = (unsigned long )tmp___122;
        }
#line 5461
        if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
          goto _L___15;
        } else {
#line 5461
          if (__s1_len___4 >= 4UL) {
            _L___15: /* CIL Label */ 
#line 5461
            if (! ((unsigned long )((void const   *)("st" + 1)) - (unsigned long )((void const   *)"st") == 1UL)) {
#line 5461
              tmp___123 = 1;
            } else {
#line 5461
              if (__s2_len___4 >= 4UL) {
#line 5461
                tmp___123 = 1;
              } else {
#line 5461
                tmp___123 = 0;
              }
            }
          } else {
#line 5461
            tmp___123 = 0;
          }
        }
#line 5461
        if (tmp___123) {
          {
#line 5461
          tmp___115 = __dyc_funcallvar_43;
          }
        } else {
          {
#line 5461
          tmp___120 = __dyc_funcallvar_44;
#line 5461
          tmp___115 = tmp___120;
          }
        }
      } else {
        {
#line 5461
        tmp___120 = __dyc_funcallvar_45;
#line 5461
        tmp___115 = tmp___120;
        }
      }
#line 5461
      if (tmp___115) {
        {

        }
      } else {
        {



        }
      }
    } else {
      {

      }
    }
  }
  goto __dyc_dummy_label;
  switch_50_56: /* CIL Label */ 
#line 5474
  if ((int )(dc->u.s_binary.right)->type != 57) {
    {

    }
    goto __dyc_dummy_label;
  }
#line 5480
  tmp___142 = __dyc_funcallvar_46;
#line 5480
  if (tmp___142) {
    {






    }
    goto __dyc_dummy_label;
  }
#line 5491
  tmp___143 = __dyc_funcallvar_47;
#line 5491
  if (tmp___143) {
    goto __dyc_dummy_label;
  }
#line 5497
  if ((int )(dc->u.s_binary.left)->type == 50) {
#line 5497
    if (((dc->u.s_binary.left)->u.s_operator.op)->len == 1) {
#line 5497
      if ((int const   )*(((dc->u.s_binary.left)->u.s_operator.op)->name + 0) == 62) {
        {

        }
      }
    }
  }
#line 5502
  if (0) {
    {
#line 5502
    tmp___159 = __dyc_funcallvar_48;
#line 5502
    __s1_len___6 = (unsigned long )tmp___159;
#line 5502
    tmp___160 = __dyc_funcallvar_49;
#line 5502
    __s2_len___6 = (unsigned long )tmp___160;
    }
#line 5502
    if (! ((unsigned long )((void const   *)(((dc->u.s_binary.left)->u.s_operator.op)->code + 1)) - (unsigned long )((void const   *)((dc->u.s_binary.left)->u.s_operator.op)->code) == 1UL)) {
      goto _L___20;
    } else {
#line 5502
      if (__s1_len___6 >= 4UL) {
        _L___20: /* CIL Label */ 
#line 5502
        if (! ((unsigned long )((void const   *)("cl" + 1)) - (unsigned long )((void const   *)"cl") == 1UL)) {
#line 5502
          tmp___161 = 1;
        } else {
#line 5502
          if (__s2_len___6 >= 4UL) {
#line 5502
            tmp___161 = 1;
          } else {
#line 5502
            tmp___161 = 0;
          }
        }
      } else {
#line 5502
        tmp___161 = 0;
      }
    }
#line 5502
    if (tmp___161) {
      {
#line 5502
      tmp___153 = __dyc_funcallvar_50;
      }
    } else {
      {
#line 5502
      tmp___158 = __dyc_funcallvar_51;
#line 5502
      tmp___153 = tmp___158;
      }
    }
  } else {
    {
#line 5502
    tmp___158 = __dyc_funcallvar_52;
#line 5502
    tmp___153 = tmp___158;
    }
  }
#line 5502
  if (tmp___153 == 0) {
#line 5502
    if ((int )((dc->u.s_binary.right)->u.s_binary.left)->type == 3) {
#line 5509
      func = (struct demangle_component  const  *)(dc->u.s_binary.right)->u.s_binary.left;
#line 5511
      if ((int )(func->u.s_binary.right)->type != 41) {
        {

        }
      }
      {

      }
    } else {
      {

      }
    }
  } else {
    {

    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__comp_46demangle_component(mod_inner);
  __dyc_print_ptr__comp_62d_print_template(saved_templates);
  __dyc_printpre_byte(i___0);
  __dyc_printpre_byte(len);
  __dyc_print_ptr__comp_46demangle_component(list);
  __dyc_printpre_byte(len___0);
  __dyc_print_ptr__comp_46demangle_component(operand);
  __dyc_print_ptr__char(code);
  __dyc_printpre_byte(__s1_len___1);
  __dyc_printpre_byte(__s2_len___1);
  __dyc_print_ptr__comp_46demangle_component(a___1);
  __dyc_printpre_byte(len___1);
  __dyc_printpre_byte(len___2);
  __dyc_printpre_byte(__s1_len___2);
  __dyc_printpre_byte(__s2_len___2);
  __dyc_printpre_byte(__s1_len___3);
  __dyc_printpre_byte(__s2_len___3);
  __dyc_printpre_byte(__s1_len___4);
  __dyc_printpre_byte(__s2_len___4);
  __dyc_printpre_byte(__s1_len___5);
  __dyc_printpre_byte(__s2_len___5);
  __dyc_printpre_byte(__s1_len___6);
  __dyc_printpre_byte(__s2_len___6);
}
}
