#include <dycfoo.h>
#include "../dotdot.i.hd.c.h"
void __dyc_foo(void) 
{ char *clone ;
  size_t clen ;
  char *out ;
  char *outptr ;
  char *tmp___1 ;
  char *tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int __dyc_funcallvar_12 ;

  {
  clone = __dyc_read_ptr__char();
  clen = (size_t )__dyc_readpre_byte();
  out = __dyc_read_ptr__char();
  outptr = __dyc_read_ptr__char();
  tmp___3 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___4 = 0;
#line 150
  if (tmp___3) {
    {
#line 150
    tmp___4 = __dyc_funcallvar_12;
    }
#line 150
    if (tmp___4) {
      {
#line 161
      while (1) {
        while_1_continue: /* CIL Label */ ;
#line 162
        tmp___1 = outptr;
#line 162
        outptr ++;
#line 162
        tmp___2 = clone;
#line 162
        clone ++;
#line 162
        *tmp___1 = *tmp___2;
#line 163
        clen --;
#line 161
        if (*clone) {
#line 161
          if (! ((int )*clone != 47)) {
            goto while_1_break;
          }
        } else {
          goto while_1_break;
        }
      }
      while_1_break: /* CIL Label */ ;
      }
#line 165
      *outptr = (char)0;
    } else {
#line 151
      *clone = (char)0;
#line 152
      *out = (char)0;
    }
  } else {
#line 151
    *clone = (char)0;
#line 152
    *out = (char)0;
  }
#line 135
  *(clone + 2) = (char )'/';
#line 136
  clone += 2;
#line 137
  clen -= 2UL;
#line 139
  while (1) {
    while_2_continue: /* CIL Label */ ;
#line 139
    if (! ((unsigned long )outptr > (unsigned long )out)) {
      goto __dyc_dummy_label;
    }
#line 140
    outptr --;
#line 141
    if ((int )*outptr == 47) {
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__char(clone);
  __dyc_printpre_byte(clen);
}
}
