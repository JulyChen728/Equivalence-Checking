#include <dycfoo.h>
#include "../hash.i.hd.c.h"
void __dyc_foo(void) 
{ struct Curl_llist_element *le ;
  struct Curl_llist_element *lnext ;
  struct Curl_llist *list ;
  int i ;
  struct Curl_hash_element *he ;
  int tmp ;
  struct Curl_hash *h ;
  int (*comp)(void * , void * ) ;
  int __dyc_funcallvar_1 ;

  {
  i = __dyc_readpre_byte();
  h = __dyc_read_ptr__comp_79Curl_hash();
  comp = (int (*)(void * , void * ))__dyc_read_ptr__fun_name_is_not_here();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  le = 0;
  lnext = 0;
  list = 0;
  he = 0;
  tmp = 0;
#line 242
  list = h->table + i;
#line 243
  le = list->head;
#line 244
  while (1) {
    while_7_continue: /* CIL Label */ ;
#line 244
    if (! le) {
      goto while_7_break;
    }
#line 245
    he = (struct Curl_hash_element *)le->ptr;
#line 246
    lnext = le->next;
#line 248
    if (! comp) {
      {

#line 250
      (h->size) --;
      }
    } else {
      {
#line 248
      tmp = __dyc_funcallvar_1;
      }
#line 248
      if (tmp) {
        {

#line 250
        (h->size) --;
        }
      }
    }
#line 252
    le = lnext;
  }
  while_7_break: /* CIL Label */ ;
#line 241
  i ++;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_printpre_byte(i);
  __dyc_print_ptr__comp_80Curl_hash_element(he);
}
}
