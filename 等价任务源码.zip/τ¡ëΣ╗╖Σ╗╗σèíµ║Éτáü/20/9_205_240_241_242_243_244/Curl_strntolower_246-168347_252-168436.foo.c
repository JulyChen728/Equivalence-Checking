#include <dycfoo.h>
#include "../strcase.i.hd.c.h"
void __dyc_foo(void) 
{ char *tmp ;
  char const   *tmp___0 ;
  char *dest ;
  char const   *src ;
  size_t n ;
  char __dyc_funcallvar_1 ;

  {
  dest = __dyc_read_ptr__char();
  src = (char const   *)__dyc_read_ptr__char();
  n = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_1 = (char )__dyc_readpre_byte();
  tmp = 0;
  tmp___0 = 0;
#line 246
  if (n < 1UL) {
    goto __dyc_dummy_label;
  }
#line 249
  while (1) {
    while_3_continue: /* CIL Label */ ;
    {
#line 250
    tmp = dest;
#line 250
    dest ++;
#line 250
    *tmp = __dyc_funcallvar_1;
#line 249
    tmp___0 = src;
#line 249
    src ++;
    }
#line 249
    if (*tmp___0) {
#line 249
      n --;
#line 249
      if (! n) {
        goto while_3_break;
      }
    } else {
      goto while_3_break;
    }
  }
  while_3_break: /* CIL Label */ ;
  goto __dyc_dummy_label;
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__char(dest);
  __dyc_print_ptr__char(src);
}
}
