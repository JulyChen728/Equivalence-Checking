#include <dycfoo.h>
#include "../socketpair.i.hd.c.h"
void __dyc_foo(void) 
{ union __anonunion_a_74 a ;
  curl_socket_t listener ;
  curl_socklen_t addrlen ;
  struct pollfd pfd[1] ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  curl_socket_t *socks ;
  int __dyc_funcallvar_1 ;
  uint32_t __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;

  {
  addrlen = (curl_socklen_t )__dyc_readpre_byte();
  socks = (curl_socket_t *)__dyc_read_ptr__typdef_curl_socket_t();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  memset(& a, 0, sizeof(union __anonunion_a_74 ));
  listener = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
#line 75
  listener = __dyc_funcallvar_1;
#line 76
  if (listener == -1) {
    goto __dyc_dummy_label;
  }

#line 80
  a.inaddr.sin_family = (unsigned short)2;
#line 81
  a.inaddr.sin_addr.s_addr = __dyc_funcallvar_2;
#line 82
  a.inaddr.sin_port = (unsigned short)0;
#line 84
  *(socks + 1) = -1;
#line 84
  *(socks + 0) = *(socks + 1);
#line 86
  tmp = __dyc_funcallvar_3;
#line 86
  if (tmp == -1) {
    goto __dyc_dummy_label;
  }
#line 89
  tmp___0 = __dyc_funcallvar_4;
#line 89
  if (tmp___0 == -1) {
    goto __dyc_dummy_label;
  }
#line 91
  tmp___1 = __dyc_funcallvar_5;
#line 91
  if (tmp___1 == -1) {
    goto __dyc_dummy_label;
  } else {
#line 91
    if (addrlen < (curl_socklen_t )((int )sizeof(struct sockaddr_in ))) {
      goto __dyc_dummy_label;
    }
  }
#line 94
  tmp___2 = __dyc_funcallvar_6;
#line 94
  if (tmp___2 == -1) {
    goto __dyc_dummy_label;
  }
#line 96
  *(socks + 0) = __dyc_funcallvar_7;
#line 97
  if (*(socks + 0) == -1) {
    goto __dyc_dummy_label;
  }
#line 99
  tmp___3 = __dyc_funcallvar_8;
#line 99
  if (tmp___3 == -1) {
    goto __dyc_dummy_label;
  }
#line 103
  tmp___4 = __dyc_funcallvar_9;
#line 103
  if (tmp___4 < 0) {
    goto __dyc_dummy_label;
  }
#line 105
  pfd[0].fd = listener;
#line 106
  pfd[0].events = (short)1;
#line 107
  pfd[0].revents = (short)0;

#line 109
  *(socks + 1) = __dyc_funcallvar_10;
#line 110
  if (*(socks + 1) == -1) {
    goto __dyc_dummy_label;
  }
#line 114
  addrlen = (unsigned int )sizeof(struct sockaddr_in );
#line 115
  tmp___5 = __dyc_funcallvar_11;
#line 115
  if (tmp___5 == -1) {
    goto __dyc_dummy_label;
  } else {
#line 115
    if (addrlen < (curl_socklen_t )((int )sizeof(struct sockaddr_in ))) {
      goto __dyc_dummy_label;
    }
  }
#line 118
  addrlen = (unsigned int )sizeof(struct sockaddr_in );
#line 119
  tmp___6 = __dyc_funcallvar_12;
#line 119
  if (! (tmp___6 == -1)) {
#line 119
    if (addrlen < (curl_socklen_t )((int )sizeof(struct sockaddr_in ))) {
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_comp_100__anonunion_a_74(a);
  __dyc_printpre_byte(addrlen);
}
}
