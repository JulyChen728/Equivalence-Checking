#include <dycfoo.h>
#include "../inet_ntop.i.hd.c.h"
void __dyc_foo(void) 
{ struct __anonstruct_best_74 best ;
  struct __anonstruct_best_74 cur ;
  unsigned long words[8] ;
  int i ;

  {

  memset(& best, 0, sizeof(struct __anonstruct_best_74 ));
  memset(& cur, 0, sizeof(struct __anonstruct_best_74 ));
  i = 0;
#line 103
  best.base = -1L;
#line 104
  cur.base = -1L;
#line 105
  best.len = 0L;
#line 106
  cur.len = 0L;
#line 108
  i = 0;
#line 108
  while (1) {
    while_2_continue: /* CIL Label */ ;
#line 108
    if (! (i < 8)) {
      goto __dyc_dummy_label;
    }
#line 109
    if (words[i] == 0UL) {
#line 110
      if (cur.base == -1L) {
#line 111
        cur.base = (long )i;
#line 111
        cur.len = 1L;
      } else {
#line 113
        (cur.len) ++;
      }
    } else {
#line 115
      if (cur.base != -1L) {
#line 116
        if (best.base == -1L) {
#line 117
          best = cur;
        } else {
#line 116
          if (cur.len > best.len) {
#line 117
            best = cur;
          }
        }
#line 118
        cur.base = -1L;
      }
    }
#line 108
    i ++;
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_comp_92__anonstruct_best_74(best);
  __dyc_print_comp_92__anonstruct_best_74(cur);
}
}
