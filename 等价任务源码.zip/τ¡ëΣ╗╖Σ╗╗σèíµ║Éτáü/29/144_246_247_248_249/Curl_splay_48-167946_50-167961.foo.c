#include <dycfoo.h>
#include "../splay.i.hd.c.h"
void __dyc_foo(void) 
{ struct Curl_tree N ;
  struct Curl_tree *l ;
  struct Curl_tree *r ;
  struct Curl_tree *y ;
  long comp ;
  int tmp___3 ;
  int tmp___11 ;
  int tmp___19 ;
  struct curltime i ;
  struct Curl_tree *t ;

  {
  i = __dyc_read_comp_77curltime();
  t = __dyc_read_ptr__comp_78Curl_tree();
  memset(& N, 0, sizeof(struct Curl_tree ));
  l = 0;
  r = 0;
  y = 0;
  comp = 0;
  tmp___3 = 0;
  tmp___11 = 0;
  tmp___19 = 0;
#line 47
  N.larger = (struct Curl_tree *)((void *)0);
#line 47
  N.smaller = N.larger;
#line 48
  r = & N;
#line 48
  l = r;
#line 50
  while (1) {
    while_0_continue: /* CIL Label */ ;
#line 51
    if (i.tv_sec < t->key.tv_sec) {
#line 51
      tmp___3 = -1;
    } else {
#line 51
      if (i.tv_sec > t->key.tv_sec) {
#line 51
        tmp___3 = 1;
      } else {
#line 51
        if (i.tv_usec < t->key.tv_usec) {
#line 51
          tmp___3 = -1;
        } else {
#line 51
          if (i.tv_usec > t->key.tv_usec) {
#line 51
            tmp___3 = 1;
          } else {
#line 51
            tmp___3 = 0;
          }
        }
      }
    }
#line 51
    comp = (long )tmp___3;
#line 52
    if (comp < 0L) {
#line 53
      if (! t->smaller) {
        goto __dyc_dummy_label;
      }
#line 55
      if (i.tv_sec < (t->smaller)->key.tv_sec) {
#line 55
        tmp___11 = -1;
      } else {
#line 55
        if (i.tv_sec > (t->smaller)->key.tv_sec) {
#line 55
          tmp___11 = 1;
        } else {
#line 55
          if (i.tv_usec < (t->smaller)->key.tv_usec) {
#line 55
            tmp___11 = -1;
          } else {
#line 55
            if (i.tv_usec > (t->smaller)->key.tv_usec) {
#line 55
              tmp___11 = 1;
            } else {
#line 55
              tmp___11 = 0;
            }
          }
        }
      }
#line 55
      if (tmp___11 < 0) {
#line 56
        y = t->smaller;
#line 57
        t->smaller = y->larger;
#line 58
        y->larger = t;
#line 59
        t = y;
#line 60
        if (! t->smaller) {
          goto __dyc_dummy_label;
        }
      }
#line 63
      r->smaller = t;
#line 64
      r = t;
#line 65
      t = t->smaller;
    } else {
#line 67
      if (comp > 0L) {
#line 68
        if (! t->larger) {
          goto __dyc_dummy_label;
        }
#line 70
        if (i.tv_sec < (t->larger)->key.tv_sec) {
#line 70
          tmp___19 = -1;
        } else {
#line 70
          if (i.tv_sec > (t->larger)->key.tv_sec) {
#line 70
            tmp___19 = 1;
          } else {
#line 70
            if (i.tv_usec < (t->larger)->key.tv_usec) {
#line 70
              tmp___19 = -1;
            } else {
#line 70
              if (i.tv_usec > (t->larger)->key.tv_usec) {
#line 70
                tmp___19 = 1;
              } else {
#line 70
                tmp___19 = 0;
              }
            }
          }
        }
#line 70
        if (tmp___19 > 0) {
#line 71
          y = t->larger;
#line 72
          t->larger = y->smaller;
#line 73
          y->smaller = t;
#line 74
          t = y;
#line 75
          if (! t->larger) {
            goto __dyc_dummy_label;
          }
        }
#line 78
        l->larger = t;
#line 79
        l = t;
#line 80
        t = t->larger;
      } else {
        goto __dyc_dummy_label;
      }
    }
  }
  __dyc_dummy_label: /* CIL Label */ ;
  __dyc_print_ptr__comp_78Curl_tree(l);
  __dyc_print_ptr__comp_78Curl_tree(r);
}
}
